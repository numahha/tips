# ORBSLAM2forWindowsお勉強
* [ORBSLAM2forWindowsリポジトリ](https://github.com/phdsky/ORBSLAM24Windows)

## orbslam2 インストール
### 事前インストール
* OpenCV
[リリースページ](https://opencv.org/releases/)からwindows版をダウンロード。バージョン3.1.14で動作確認。[インストールの雰囲気](https://www.kkaneko.jp/tools/win/opencv43.html)。この動作確認時はディレクトリを`C:\opencv`に設定。PATHの追加を忘れないこと。

* cmake
[公式ページ](https://cmake.org/download/)からダウンロード。この動作確認時はcmake-3.20.1-windows-x86_64.msi。[インストールの雰囲気](https://www.kkaneko.jp/tools/win/cmake.html)。

* visual studio 2019
[公式ページ](https://visualstudio.microsoft.com/ja//)からコミュニティ版をダウンロード。Visual studio installerを起動。「C++によるデスクトップ開発」を選択。言語パックで英語を選択すること。

* git
[公式ページ](https://git-scm.com/downloads)からダウンロード。

* 解凍ソフト
[Lhaplus](https://forest.watch.impress.co.jp/library/software/lhaplus/)だと、ベンチマークデータ（後述）の解凍がうまくいかなかった。
[7-zip](https://sevenzip.osdn.jp/download.html)だと、ベンチマークデータの解凍までうまくいった。


### 本体（+α）インストール
* リポジトリの入手
[Githubのページ](https://github.com/phdsky/ORBSLAM24Windows)からダウンロードしてきて解凍。この動作確認時は解凍先を`C:\git\ORBSLAM24Windows`とした。

* DBoW2, g2o, pangolin
cmake-guiのアプリを起動し、[GithubページのREADME](https://github.com/phdsky/ORBSLAM24Windows/blob/master/README.md)に沿ってすすめる。この3つについては、そのまま成功する？（←後で確認●●●）
※ もしpangolinのインストールで詰まったら https://blog.goo.ne.jp/yoossh/e/0a7de7d292b32acf7e6cabeb4681c9d7 みたいにすればうまくいくと思う（←後で確認●●●）。

* orbslam2
1. cmake-guiのアプリを起動し、[GithubページのREADME](https://github.com/phdsky/ORBSLAM24Windows/blob/master/README.md)の5まですすめる。
2. 各プロジェクトについて、右クリック→Propaties→c/c++→Preprocessor→Preprocessor Definitionsと辿り、COMPILEDWITHC11を追加して、apply→OKとする。
3. ALL_BUILDをリビルド。

### 動作確認

[GithubページのREADME](https://github.com/phdsky/ORBSLAM24Windows/blob/master/README.md)の例題を試してみる。
1. freiburg2_deskのデータを、[TUMのページ](https://vision.in.tum.de/data/datasets/rgbd-dataset/download)からダウンロード。
2. 解凍して適当なところに保存。この動作確認時は`C:\dataset\rgbd_dataset_freiburg2_desk`にする。
3. ORBSLAM24WINDOWSのリポジトリ（この動作時は`C:\git\ORBSLAM24Windows`）の中にある`Vocabulary\ORBvoc.txt.tar.gz`を解凍
4. orbslam2のソリューション（上述のインストールで触ったやつ）を立ち上げる。
5. `mono_tum`のプロジェクトを右クリック→set as startup projectとする。
6.  `mono_tum`のプロジェクトを右クリック→Property→Config Property→Debug→Command Augmentsと辿り、下記を追加
`C:\git\ORBSLAM24Windows\Vocabulary\ORBvoc.txt C:\git\ORBSLAM24Windows\Examples\Monocular\TUM1.yaml C:\dataset\rgbd_dataset_freiburg2_desk`
7.  `mono_tum`のプロジェクトをリビルド
8. 上のバーから、Debug→Start without debuggingで実行。

以降、`mono_tum`のプロジェクトを我々用に使う前提で話をすすめる。

## 入力関係
### カメラ・パラメータ
ORBSLAM2の`mono_tum`を使うにあたり、単眼カメラのパラメータ（OpenCV用）を与える必要がある。具体例は、`ORBSLAM24Windows\Examples\Monocular\TUM1.yaml`を参照。この内、キャリブレーションで与える必要があるのは、`fx` `fy` `cx` `cy` `k1` `k2` `p1` `p2` `k3`である。

[キャリブレーションのチュートリアル](https://docs.opencv.org/master/dc/dbb/tutorial_py_calibration.html)によると、これらパラメータの内容は以下である。
* `fx` `fy` `cx` `cy` ... カメラ行列の成分
* `k1` `k2` `p1` `p2` `k3` ... 歪み係数

[関数ドキュメント](https://docs.opencv.org/master/d9/d0c/group__calib3d.html#ga3207604e4b1a1758aa66acb6ed5aa65d)によると、Pythonで`calibrateCamera()`を呼んだ時の2,3番目の返り値が、それぞれ、カメラ行列と歪み係数である。これらをyamlファイルの中に書き込めばOK。

コードは遅いので改善の余地あり？

yamlファイルを作った後、上述の動作確認時に設定した`C:\git\ORBSLAM24Windows\Examples\Monocular\TUM1.yaml`を変更すれば完了。

### 動画データ
`ORBSLAM24Windows\Examples\Monocular\mono_tum.cc`を見たところ、`mono_tum`の動作確認（上述）において使ったデータは、以下である。
* `C:\dataset\rgbd_dataset_freiburg2_desk\rgb\*.png` ... 動画をpngにバラしたもの。
* `C:\dataset\rgbd_dataset_freiburg2_desk\rgb.txt`... タイムスタンプとpngファイル名の対応関係のリスト

そのため、動画を撮った後、pngに分解してタイムスタンプとの対応リストを作ればOK。

データを作った後、上述の動作確認時に設定した`C:\dataset\rgbd_dataset_freiburg2_desk`を変更すれば完了。

## 出力関係
`ORBSLAM24Windows\build\our`以下に出力されるようにした（`our`ディレクトリを事前に作っておく必要あり）。

### Map Viewerウィンドウ（3次元描画）
* `MapPoints_blackpoint_XXX.txt` `RefMapPoints_redpoint_XXX.txt` ... 黒点と赤点（MAP点・参照MAP点）をx,y,z\nのように出力する。
* `KeyFrame_bluebox_XXX.txt` ... 青四角（キーフレーム）を描画するための[モデルビュー変換行列](http://wisdom.sakura.ne.jp/system/opengl/gl11.html)をa1,a2,...,a16\nのように出力する。
* `CurrentCamera_greanbox_XXX.txt` ... 緑四角（現在のカメラ）を描画するためのモデルビュー変換行列を出力する。
* `CovGraph_greenline_XXX.txt` `SpanTree_greenline_XXX.txt` `Loops_greenline_xxx.txt` ...  緑線（Covisibility Graph・Spanning tree・Loops）を描画するための端点を、それぞれ、x1,y1,z1,x2,y2,z2\nのように出力する。
<img width="757.125" alt="mapviewer.png (40.4 kB)" src="https://img.esa.io/uploads/production/attachments/15545/2021/04/23/102139/39c76d8c-c6e5-41e2-a6e8-87fe82c7b8de.png">


### Current Frameウィンドウ（2次元描画）
* `Initializing_greenline_XXX.txt` ... 初期化が終わる前に表示される緑線の端点を、x1,y1,x2,y2\nのように出力。
*  `Tracking_MapPoint_greenpoint_XXX.txt` ... MapPointを示す緑四角の中心を、x,y\nのように出力。
* `Tracking_VisualOdometryMapPoint_redpoint_XXX.txt`... 初期化後のvisual odometry MapPointを示す赤四角の中心を、x,y\nのように出力。
<img width="1101.375" alt="cameraframe.png (905.9 kB)" src="https://img.esa.io/uploads/production/attachments/15545/2021/04/23/102139/838cab34-44f0-4793-ba73-4dfed2998afc.png">

### 時刻
上述の`XXX`は、描画を行った回数に関する通し番号である。この通し番号とカメラフレームの時刻との対応関係を `timestamp.txt`として出力する。


### ソースコード改造概要
* `ORBSLAM24Windows/include/System.h`にタイムスタンプの追加（とりあえず`our_timestamp`という名前にした）。
* `ORBSLAM24Windows/src/System.cc`の中の`System::TrackMonocular()`で、タイムスタンプの更新。
* `ORBSLAM24Windows/src/Viewer.cc`の中の`Viewer::Run()`で、ファイル番号ータイムスタンプ関係のリストを書き出し。
* `ORBSLAM24Windows/src/Viewer.cc`の中の`Viewer::Run()`で、follow cameraの初期設定を変更。
* `ORBSLAM24Windows/src/MapDrawer.cc`の中の`MapDrawer::Draで、wMapPoints()`と`MapDrawer::DrawKeyFrames()`と`MapDrawer::DrawCurrentCamera()`で、描画情報を書き出し。
* `ORBSLAM24Windows/src/FrameDrawer.cc`の中の`FrameDrawer::DrawFrame()`で、描画情報を書き出し。


## 理論の参考文献
* [Matlab: Monocular Visual Simultaneous Localization and Mapping ](https://jp.mathworks.com/help/vision/ug/monocular-visual-simultaneous-localization-and-mapping.html?lang=en)
