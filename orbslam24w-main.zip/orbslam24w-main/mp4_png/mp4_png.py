import cv2
import os

def save_all_frames(video_path, dir_path, basename, ext='png'):
    cap = cv2.VideoCapture(video_path)

    if not cap.isOpened():
        return
    fps = cap.get(cv2.CAP_PROP_FPS)


    file = open('rgb.txt', 'w')
    file.write("# color images\n")
    file.write("# file: "+str(video_path)+"\n")
    file.write("# timestamp filename\n")


    os.makedirs(dir_path, exist_ok=True)
    #base_path = os.path.join(dir_path, basename)
    base_path = dir_path + "/" + basename



    n = 0

    timestamp = 0.0

    while True:
        ret, frame = cap.read()
        if ret:
            img_filename = '{}_{}.{}'.format(base_path,timestamp,ext)
            cv2.imwrite(img_filename, frame)
            file.write(str(timestamp)+" "+img_filename+"\n")
            timestamp += 1./fps
            n += 1
        else:
            break
    file.close()
    return

save_all_frames('WIN_20210421_17_44_36_Pro.mp4', 'rgb', 'sample')
