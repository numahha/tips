import numpy as np
import cv2
import glob

import tkinter as tk
TkRoot = tk.Tk()
display_width = TkRoot.winfo_screenwidth()
display_height = TkRoot.winfo_screenheight()

square_size = 2.2
pattern_size = (7, 10)

cv2.namedWindow('image_window', cv2.WINDOW_NORMAL)

#objp = np.zeros((6*7,3), np.float32)
objp = np.zeros((np.prod(pattern_size),3), np.float32)
#objp[:,:2] = np.mgrid[0:7,0:6].T.reshape(-1,2)
objp[:,:2] = np.indices(pattern_size).T.reshape(-1, 2)
objp *= square_size
# Arrays to store object points and image points from all the images.
objpoints = [] # 3d point in real world space
imgpoints = [] # 2d points in image plane.
images = glob.glob('*.jpg')
for fname in images:
    print(fname)
    img = cv2.imread(fname)

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # Find the chess board corners
    #ret, corners = cv2.findChessboardCorners(gray, (7,6), None)
    ret, corners = cv2.findChessboardCorners(gray, pattern_size)
    # If found, add object points, image points (after refining them)
    if ret == True:
        objpoints.append(objp)
        criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)
        corners2 = cv2.cornerSubPix(gray,corners, (20,20), (-1,-1), criteria)
        imgpoints.append(corners)
        # Draw and display the corners
        #cv2.drawChessboardCorners(img, (7,6), corners2, ret)
        cv2.drawChessboardCorners(img, pattern_size, corners2, ret)
        h, w = img.shape[:2]

        if (display_width/w) > (display_height/h):
            scale = display_height/h
        else:
            scale = display_width/w
        #size = (int(orgHeight/resize_param), int(orgWidth/resize_param))
        cv2.resizeWindow('image_window', int(0.8*scale*w), int(0.8*scale*h)) # resize window
        cv2.imshow('image_window', img)

        cv2.waitKey(1000)
cv2.destroyAllWindows()

ret, mtx, dist, rvecs, tvecs = cv2.calibrateCamera(objpoints, imgpoints, gray.shape[::-1], None, None)
print("mtx",mtx)
print("dist",dist)
"""
img = cv2.imread('left12.jpg')
h,  w = img.shape[:2]
newcameramtx, roi = cv2.getOptimalNewCameraMatrix(mtx, dist, (w,h), 1, (w,h))

# undistort
dst = cv2.undistort(img, mtx, dist, None, newcameramtx)
# crop the image
x, y, w, h = roi
dst = dst[y:y+h, x:x+w]
cv2.imwrite('calibresult.png', dst)

# undistort
mapx, mapy = cv2.initUndistortRectifyMap(mtx, dist, None, newcameramtx, (w,h), 5)
dst = cv2.remap(img, mapx, mapy, cv2.INTER_LINEAR)
# crop the image
x, y, w, h = roi
dst = dst[y:y+h, x:x+w]
cv2.imwrite('calibresult.png', dst)

mean_error = 0
for i in range(len(objpoints)):
    imgpoints2, _ = cv2.projectPoints(objpoints[i], rvecs[i], tvecs[i], mtx, dist)
    error = cv2.norm(imgpoints[i],imgpoints2, cv2.NORM_L2)/len(imgpoints2)
    mean_error += error

print("total error: ", mean_error/len(objpoints))
"""
