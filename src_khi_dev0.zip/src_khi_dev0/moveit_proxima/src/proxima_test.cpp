#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit/plan_execution/plan_execution.h>
#include <random>
//#include <moveit_msgs/DisplayRobotState.h>
//#include <moveit_msgs/DisplayTrajectory.h>

//#include <moveit_msgs/AttachedCollisionObject.h>
//#include <moveit_msgs/CollisionObject.h>


/*
killall -9 gzserver
roslaunch khi_rs_gazebo rs007l_world.launch
roslaunch khi_rs007l_moveit_config moveit_planning_execution.launch sim:=true
rosrun moveit_proxima proxima_test
*/



// 
// 

int main(int argc, char** argv)
{
  std::random_device rnd;
  std::mt19937 mt(rnd());
  std::normal_distribution<> norm(0., 1.);
  //ros::init(argc, argv, "move_group_interface_tutorial");
  ros::init(argc, argv, "proxima_demo");
  ros::NodeHandle node_handle;
  ros::AsyncSpinner spinner(1);
  spinner.start();

  static const std::string PLANNING_GROUP = "manipulator";
  moveit::planning_interface::MoveGroupInterface move_group(PLANNING_GROUP);
  moveit::planning_interface::PlanningSceneInterface planning_scene_interface;

  const robot_state::JointModelGroup* joint_model_group =
      move_group.getCurrentState()->getJointModelGroup(PLANNING_GROUP);


  ROS_INFO_NAMED("proxima_test", "Planning frame: %s", move_group.getPlanningFrame().c_str());
  ROS_INFO_NAMED("proxima_test", "End effector link: %s", move_group.getEndEffectorLink().c_str());
  ROS_INFO_NAMED("proxima_test", "Available Planning Groups:");
  std::copy(move_group.getJointModelGroupNames().begin(), move_group.getJointModelGroupNames().end(),
            std::ostream_iterator<std::string>(std::cout, ", "));

  geometry_msgs::Pose target_pose1;
  bool success;
  moveit::core::RobotStatePtr current_state;
  std::vector<double> joint_group_positions;
  moveit::planning_interface::MoveGroupInterface::Plan my_plan;


  current_state = move_group.getCurrentState();
  current_state->copyJointGroupPositions(joint_model_group, joint_group_positions);

  //joint_group_positions[0] = 0. + 0.00*norm(mt);  // radians
  //joint_group_positions[1] = -0.1 + 0.00*norm(mt);  // radians
  //joint_group_positions[2] = 0.1 + 0.00*norm(mt);  // radians
  //joint_group_positions[3] = -1.*3.14 + 0.0*norm(mt);  // radians
  //joint_group_positions[4] = -0.5*3.14 + 0.0*norm(mt);  // radians
  //joint_group_positions[5] = 0. + 0.0*norm(mt);  // radians


  joint_group_positions[0] = -0.6;  // radians
  joint_group_positions[1] = 0.49;  // radians
  joint_group_positions[2] = -1.3;  // radians
  joint_group_positions[3] = 2.8;  // radians
  joint_group_positions[4] = -0.9;  // radians
  joint_group_positions[5] = -0.0*3.14;  // radians
  //double scl = -0.01;
  //joint_group_positions[0] += scl*5.7;  // radians
  //joint_group_positions[3] += scl*14.9;  // radians
  //joint_group_positions[5] += scl*10.8;  // radians

  move_group.setJointValueTarget(joint_group_positions);

  success = (move_group.plan(my_plan) == moveit::planning_interface::MoveItErrorCode::SUCCESS);
  ROS_INFO_NAMED("proxima_test", "Planning 1 %s", success ? "" : "FAILED");
  move_group.execute(my_plan);
  //moveit::MoveGroupExecuteService hoge;
  //plan_execution::PlanExecution::executeAndMonitor(my_plan, true);








  ros::WallDuration(1.0).sleep();


  // dispaly planning result
  std::cout << my_plan.trajectory_.joint_trajectory.header.seq << std::endl;
  std::cout << my_plan.trajectory_.joint_trajectory.header.stamp.sec << std::endl;
  std::cout << my_plan.trajectory_.joint_trajectory.header.stamp.nsec << std::endl;
  ROS_INFO_NAMED( "proxima_test", "Planning 1 %s", success ? "" : "FAILED" );
  ROS_INFO_NAMED( "proxima_test", "Planning Result");
  for(int i=0; i<my_plan.trajectory_.joint_trajectory.points.size(); i++){
    std::cout << my_plan.trajectory_.joint_trajectory.points[i].positions[3]     << ","
              << my_plan.trajectory_.joint_trajectory.points[i].velocities[3]    << ","
              << my_plan.trajectory_.joint_trajectory.points[i].accelerations[3] << ","
              //<< my_plan.trajectory_.joint_trajectory.points[i].effort[0] << "," // stop by core dump
              << my_plan.trajectory_.joint_trajectory.points[i].time_from_start
              << std::endl;
  }

  ROS_INFO_NAMED( "proxima_test", "Execution Result");
  std::cout << (move_group.getMoveGroupClient()).getResult()->planning_time << std::endl;
  std::cout << (move_group.getMoveGroupClient()).getResult()->trajectory_start.joint_state.position[3] << std::endl;
  std::cout << (move_group.getMoveGroupClient()).getResult()->trajectory_start.joint_state.velocity[3] << std::endl;
  //std::cout << (move_group.getMoveGroupClient()).getResult()->trajectory_start.joint_state.effort[0] << std::endl;
  std::cout << (move_group.getMoveGroupClient()).getResult()->planned_trajectory.joint_trajectory.points.size() << std::endl;
  std::cout << (move_group.getMoveGroupClient()).getResult()->executed_trajectory.joint_trajectory.points.size() << std::endl;

  for(int i=0; i<(move_group.getMoveGroupClient()).getResult()->executed_trajectory.joint_trajectory.points.size(); i++){
    std::cout << (move_group.getMoveGroupClient()).getResult()->executed_trajectory.joint_trajectory.points[i].positions[3]     << ","
              << (move_group.getMoveGroupClient()).getResult()->executed_trajectory.joint_trajectory.points[i].velocities[3]    << ","
              << (move_group.getMoveGroupClient()).getResult()->executed_trajectory.joint_trajectory.points[i].accelerations[3] << ","
              << (move_group.getMoveGroupClient()).getResult()->executed_trajectory.joint_trajectory.points[i].effort[3] << "," // stop by core dump
              << (move_group.getMoveGroupClient()).getResult()->executed_trajectory.joint_trajectory.points[i].time_from_start
              << std::endl;
  }









  current_state = move_group.getCurrentState();  
  current_state->copyJointGroupPositions(joint_model_group, joint_group_positions);



  joint_group_positions[0] = 0.6;  // radians
  joint_group_positions[1] = 0.49;  // radians
  joint_group_positions[2] = -1.3;  // radians
  joint_group_positions[3] = -2.8;  // radians
  joint_group_positions[4] = -0.9;  // radians
  joint_group_positions[5] = 0.5*3.14;  // radians

  move_group.setJointValueTarget(joint_group_positions);

  success = (move_group.plan(my_plan) == moveit::planning_interface::MoveItErrorCode::SUCCESS);

  move_group.execute(my_plan);
/*
  for(int i=0; i<my_plan.executed_trajectory_.joint_trajectory.points.size(); i++){
    std::cout << my_plan.executed_trajectory_.joint_trajectory.points[i].positions[0]     << ","
              << my_plan.executed_trajectory_.joint_trajectory.points[i].velocities[0]    << ","
              << my_plan.executed_trajectory_.joint_trajectory.points[i].accelerations[0] << ","
              << my_plan.executed_trajectory_.joint_trajectory.points[i].effort[0] << "," // stop by core dump
              << my_plan.executed_trajectory_.joint_trajectory.points[i].time_from_start
              << std::endl;
  }
*/
  // move_group.impl_->execute_action_client_; // impl_ is private

  ros::shutdown();
  return 0;
}

