import autograd.numpy as np
from autograd import grad, hessian
from scipy.spatial.transform import Rotation
from scipy.optimize import minimize
from numpy.linalg import svd



theta=np.pi * np.array([0.0, 0.0, 0.0, 0.0,0.0,0.0])

def fk(theta):
    #axis_len = 0.02
    #origin_list=[]
    #x_list=[]
    #y_list=[]
    #z_list=[]

    # base_link
    np_mat_base_i = np.eye(4)
    #origin_list = (np_mat_base_i @ np.array([0,0,0,1])       )[np.newaxis]
    #x_list      = (np_mat_base_i @ np.array([axis_len,0,0,1]))[np.newaxis]
    #y_list      = (np_mat_base_i @ np.array([0,axis_len,0,1]))[np.newaxis]
    #z_list      = (np_mat_base_i @ np.array([0,0,axis_len,1]))[np.newaxis]

    # link1
    temp_mat = np.eye(4)
    temp_mat[2,3] = 0.36
    np_mat_base_i = np_mat_base_i @ temp_mat
    #temp_mat = np.eye(4)
    #temp_mat[:3,:3] = np.array([[np.cos(-theta[0]), -np.sin(-theta[0]), 0],
    #                            [np.sin(-theta[0]),  np.cos(-theta[0]), 0],
    #                            [               0,                 0, 1]])
    temp_mat = np.array([[np.cos(-theta[0]), -np.sin(-theta[0]), 0, 0],
                         [np.sin(-theta[0]),  np.cos(-theta[0]), 0, 0],
                         [               0,                   0, 1, 0],
                         [               0,                   0, 0, 1]])
    np_mat_base_i = np_mat_base_i @ temp_mat
    #origin_list = np.concatenate([  origin_list, (np_mat_base_i @ np.array([0,0,0,1])       )[np.newaxis]  ])
    #x_list      = np.concatenate([  x_list,      (np_mat_base_i @ np.array([axis_len,0,0,1]))[np.newaxis]  ])
    #y_list      = np.concatenate([  y_list,      (np_mat_base_i @ np.array([0,axis_len,0,1]))[np.newaxis]  ])
    #z_list      = np.concatenate([  z_list,      (np_mat_base_i @ np.array([0,0,axis_len,1]))[np.newaxis]  ])

    # link2
    #temp_mat = np.eye(4)
    #temp_mat[:3,:3] = np.array([[np.cos(-0.5*np.pi), 0, np.sin(-0.5*np.pi)],
    #                           [0,  1          , 0],
    #                           [-np.sin(-0.5*np.pi), 0, np.cos(-0.5*np.pi)]])
    temp_mat = np.array([[np.cos(-0.5*np.pi), 0, np.sin(-0.5*np.pi),0],
                         [0,  1          , 0,0],
                         [-np.sin(-0.5*np.pi), 0, np.cos(-0.5*np.pi),0],
                         [0,  0          , 0,1]])
    np_mat_base_i = np_mat_base_i @ temp_mat
    #temp_mat = np.eye(4)
    #temp_mat[:3,:3] = np.array([[np.cos(theta[1]), -np.sin(theta[1]), 0],
    #                            [np.sin(theta[1]),  np.cos(theta[1]), 0],
    #                            [               0,                 0, 1]])
    temp_mat = np.array([[np.cos(theta[1]), -np.sin(theta[1]), 0,0],
                         [np.sin(theta[1]),  np.cos(theta[1]), 0,0],
                         [               0,                 0, 1,0],
                         [               0,                 0, 0,1]])

    np_mat_base_i = np_mat_base_i @ temp_mat
    #origin_list = np.concatenate([  origin_list, (np_mat_base_i @ np.array([0,0,0,1])       )[np.newaxis]  ])
    #x_list      = np.concatenate([  x_list,      (np_mat_base_i @ np.array([axis_len,0,0,1]))[np.newaxis]  ])
    #y_list      = np.concatenate([  y_list,      (np_mat_base_i @ np.array([0,axis_len,0,1]))[np.newaxis]  ])
    #z_list      = np.concatenate([  z_list,      (np_mat_base_i @ np.array([0,0,axis_len,1]))[np.newaxis]  ])

    # link3
    temp_mat = np.eye(4)
    temp_mat[0,3] = 0.455
    np_mat_base_i = np_mat_base_i @ temp_mat
    temp_mat = np.eye(4)
    #temp_mat[:3,:3] = np.array([[np.cos(-theta[2]), -np.sin(-theta[2]), 0],
    #                            [np.sin(-theta[2]),  np.cos(-theta[2]), 0],
    #                            [               0,                 0, 1]])
    temp_mat = np.array([[np.cos(-theta[2]), -np.sin(-theta[2]), 0,0],
                         [np.sin(-theta[2]),  np.cos(-theta[2]), 0,0],
                         [               0,                 0, 1,0],
                         [               0,                 0, 0,1]])

    np_mat_base_i = np_mat_base_i @ temp_mat
    #origin_list = np.concatenate([  origin_list, (np_mat_base_i @ np.array([0,0,0,1])       )[np.newaxis]  ])
    #x_list      = np.concatenate([  x_list,      (np_mat_base_i @ np.array([axis_len,0,0,1]))[np.newaxis]  ])
    #y_list      = np.concatenate([  y_list,      (np_mat_base_i @ np.array([0,axis_len,0,1]))[np.newaxis]  ])
    #z_list      = np.concatenate([  z_list,      (np_mat_base_i @ np.array([0,0,axis_len,1]))[np.newaxis]  ])

    # link4
    temp_mat = np.eye(4)
    temp_mat[0,3] = 0.0925
    np_mat_base_i = np_mat_base_i @ temp_mat
    #temp_mat = np.eye(4)
    #temp_mat[:3,:3] = np.array([[np.cos(0.5*np.pi), 0, np.sin(0.5*np.pi)],
    #                           [0,  1          , 0],
    #                           [-np.sin(0.5*np.pi), 0, np.cos(0.5*np.pi)]])
    temp_mat = np.array([[np.cos(0.5*np.pi), 0, np.sin(0.5*np.pi),0],
                         [0,  1          , 0,0],
                         [-np.sin(0.5*np.pi), 0, np.cos(0.5*np.pi),0],
                         [0,  0          , 0,1]])
    np_mat_base_i = np_mat_base_i @ temp_mat
    temp_mat = np.eye(4)
    #temp_mat[:3,:3] = np.array([[np.cos(theta[3]), -np.sin(theta[3]), 0],
    #                            [np.sin(theta[3]),  np.cos(theta[3]), 0],
    #                            [               0,                 0, 1]])
    temp_mat = np.array([[np.cos(theta[3]), -np.sin(theta[3]), 0,0],
                         [np.sin(theta[3]),  np.cos(theta[3]), 0,0],
                         [               0,                 0, 1,0],
                         [               0,                 0, 0,1]])
    np_mat_base_i = np_mat_base_i @ temp_mat
    #origin_list = np.concatenate([  origin_list, (np_mat_base_i @ np.array([0,0,0,1])       )[np.newaxis]  ])
    #x_list      = np.concatenate([  x_list,      (np_mat_base_i @ np.array([axis_len,0,0,1]))[np.newaxis]  ])
    #y_list      = np.concatenate([  y_list,      (np_mat_base_i @ np.array([0,axis_len,0,1]))[np.newaxis]  ])
    #z_list      = np.concatenate([  z_list,      (np_mat_base_i @ np.array([0,0,axis_len,1]))[np.newaxis]  ])

    # link5
    temp_mat = np.eye(4)
    temp_mat[2,3] = 0.3825
    np_mat_base_i = np_mat_base_i @ temp_mat
    #temp_mat = np.eye(4)
    #temp_mat[:3,:3] = np.array([[np.cos(-0.5*np.pi), 0, np.sin(-0.5*np.pi)],
    #                           [0,  1          , 0],
    #                           [-np.sin(-0.5*np.pi), 0, np.cos(-0.5*np.pi)]])
    temp_mat = np.array([[np.cos(-0.5*np.pi), 0, np.sin(-0.5*np.pi),0],
                         [0,  1          , 0,0],
                         [-np.sin(-0.5*np.pi), 0, np.cos(-0.5*np.pi),0],
                         [0,  0          , 0,1]])

    np_mat_base_i = np_mat_base_i @ temp_mat
    #temp_mat = np.eye(4)
    #temp_mat[:3,:3] = np.array([[np.cos(-theta[4]), -np.sin(-theta[4]), 0],
    #                            [np.sin(-theta[4]),  np.cos(-theta[4]), 0],
    #                            [               0,                 0, 1]])
    temp_mat = np.array([[np.cos(-theta[4]), -np.sin(-theta[4]), 0,0],
                         [np.sin(-theta[4]),  np.cos(-theta[4]), 0,0],
                         [               0,                 0, 1,0],
                         [               0,                 0, 0,1]])

    np_mat_base_i = np_mat_base_i @ temp_mat
    #origin_list = np.concatenate([  origin_list, (np_mat_base_i @ np.array([0,0,0,1])       )[np.newaxis]  ])
    #x_list      = np.concatenate([  x_list,      (np_mat_base_i @ np.array([axis_len,0,0,1]))[np.newaxis]  ])
    #y_list      = np.concatenate([  y_list,      (np_mat_base_i @ np.array([0,axis_len,0,1]))[np.newaxis]  ])
    #z_list      = np.concatenate([  z_list,      (np_mat_base_i @ np.array([0,0,axis_len,1]))[np.newaxis]  ])

    # link6
    temp_mat = np.eye(4)
    temp_mat[0,3] = 0.078
    np_mat_base_i = np_mat_base_i @ temp_mat
    #temp_mat = np.eye(4)
    #temp_mat[:3,:3] = np.array([[np.cos(0.5*np.pi), 0, np.sin(0.5*np.pi)],
    #                           [0,  1          , 0],
    #                           [-np.sin(0.5*np.pi), 0, np.cos(0.5*np.pi)]])
    temp_mat = np.array([[np.cos(0.5*np.pi), 0, np.sin(0.5*np.pi),0],
                         [0,  1          , 0,0],
                         [-np.sin(0.5*np.pi), 0, np.cos(0.5*np.pi),0],
                         [0,  0          , 0,1]])

    np_mat_base_i = np_mat_base_i @ temp_mat
    #temp_mat = np.eye(4)
    #temp_mat[:3,:3] = np.array([[np.cos(theta[5]), -np.sin(theta[5]), 0],
    #                            [np.sin(theta[5]),  np.cos(theta[5]), 0],
    #                            [               0,                 0, 1]])
    temp_mat = np.array([[np.cos(theta[5]), -np.sin(theta[5]), 0,0],
                         [np.sin(theta[5]),  np.cos(theta[5]), 0,0],
                         [               0,                 0, 1,0],
                         [               0,                 0, 0,1]])

    np_mat_base_i = np_mat_base_i @ temp_mat
    #origin_list = np.concatenate([  origin_list, (np_mat_base_i @ np.array([0,0,0,1])       )[np.newaxis]  ])
    #x_list      = np.concatenate([  x_list,      (np_mat_base_i @ np.array([axis_len,0,0,1]))[np.newaxis]  ])
    #y_list      = np.concatenate([  y_list,      (np_mat_base_i @ np.array([0,axis_len,0,1]))[np.newaxis]  ])
    #z_list      = np.concatenate([  z_list,      (np_mat_base_i @ np.array([0,0,axis_len,1]))[np.newaxis]  ])

    # iron_head
    temp_mat = np.eye(4)
    temp_mat[2,3] = 0.5
    np_mat_base_i = np_mat_base_i @ temp_mat
    #origin_list = np.concatenate([  origin_list, (np_mat_base_i @ np.array([0,0,0,1])       )[np.newaxis]  ])
    #x_list      = np.concatenate([  x_list,      (np_mat_base_i @ np.array([axis_len,0,0,1]))[np.newaxis]  ])
    #y_list      = np.concatenate([  y_list,      (np_mat_base_i @ np.array([0,axis_len,0,1]))[np.newaxis]  ])
    #z_list      = np.concatenate([  z_list,      (np_mat_base_i @ np.array([0,0,axis_len,1]))[np.newaxis]  ])

    """
    import matplotlib.pyplot as plt
    from mpl_toolkits.mplot3d import Axes3D
    fig = plt.figure()
    ax = Axes3D(fig)
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_zlabel("Z")
    for i in range(len(x_list)):
        ax.plot([origin_list[i,0],x_list[i,0]], [origin_list[i,1],x_list[i,1]], [origin_list[i,2],x_list[i,2]], color='r')
        ax.plot([origin_list[i,0],y_list[i,0]], [origin_list[i,1],y_list[i,1]], [origin_list[i,2],y_list[i,2]], color='g')
        ax.plot([origin_list[i,0],z_list[i,0]], [origin_list[i,1],z_list[i,1]], [origin_list[i,2],z_list[i,2]], color='b')

    # keep xyz-scales being the same
    Xmin = min([origin_list[:,0].min(), x_list[:,0].min(), y_list[:,0].min(), z_list[:,0].min()])
    Xmax = max([origin_list[:,0].max(), x_list[:,0].max(), y_list[:,0].max(), z_list[:,0].max()])
    Ymin = min([origin_list[:,1].min(), x_list[:,1].min(), y_list[:,1].min(), z_list[:,1].min()])
    Ymax = max([origin_list[:,1].max(), x_list[:,1].max(), y_list[:,1].max(), z_list[:,1].max()])
    Zmin = min([origin_list[:,2].min(), x_list[:,2].min(), y_list[:,2].min(), z_list[:,2].min()])
    Zmax = max([origin_list[:,2].max(), x_list[:,2].max(), y_list[:,2].max(), z_list[:,2].max()])
    max_range = np.array([Xmax-Xmin, Ymax-Ymin, Zmax-Zmin]).max() * 0.5
    mid_x = (Xmax+Xmin) * 0.5
    mid_y = (Ymax+Ymin) * 0.5
    mid_z = (Zmax+Zmin) * 0.5
    ax.set_xlim(mid_x - max_range, mid_x + max_range)
    ax.set_ylim(mid_y - max_range, mid_y + max_range)
    ax.set_zlim(mid_z - max_range, mid_z + max_range)
    plt.show()
    """
    return np_mat_base_i#[0,:2]#[3,:3]


def getJ(theta):
    def jx(theta):
        return fk(theta)[0,3]
    def jy(theta):
        return fk(theta)[1,3]
    def jz(theta):
        return fk(theta)[2,3]
    def jroll(theta):
        r = fk(theta)[:3,:3]
        return np.arctan2(r[2,1],r[2,2])
    def jpitch(theta):
        r = fk(theta)[:3,:3]
        return np.arcsin(-r[2,0])
    def jyaw(theta):
        r = fk(theta)[:3,:3]
        return np.arctan2(r[1,0],r[0,0])

    ret = []
    ret.append(grad(jx)(theta))
    ret.append(grad(jy)(theta))
    ret.append(grad(jz)(theta))
    ret.append(grad(jroll)(theta))
    ret.append(grad(jpitch)(theta))
    ret.append(grad(jyaw)(theta))
    return np.array(ret)

theta=np.pi * np.array([0.0, 0.5, -1.3, 0.0, -0.9, 0.5*np.pi])

temp_jac = np.linalg.inv(getJ(theta))
dx = np.array([1,0,0,0,0,0])
print(temp_jac @ dx)


