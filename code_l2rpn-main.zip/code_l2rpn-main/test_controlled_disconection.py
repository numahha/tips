import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import collections
import grid2op
print("grid2op.__version__",grid2op.__version__)

# Backend class to use
try:
    from lightsim2grid.LightSimBackend import LightSimBackend
    backend = LightSimBackend()
    print("backend is LightSimBackend")
except ModuleNotFoundError:
    from grid2op.Backend import PandaPowerBackend
    backend = PandaPowerBackend()
    print("backend is PandaPowerBackend")

from grid2op.Runner import Runner
from grid2op.Parameters import Parameters

from grid2op.Agent.BaseAgent import BaseAgent
import re
from grid2op.Action import DontAct

from grid2op.Reward import GameplayReward
env = grid2op.make("l2rpn_icaps_2021_small",
                   #reward_class=GameplayReward,
                   opponent_action_class=DontAct,
                   #opponent_init_budget=0.,
                   backend=backend,
                   difficulty="0")
env.seed(0)
from grid2op.PlotGrid import PlotMatplot
plot_helper = PlotMatplot(env.observation_space, line_id=False)
total_episode = len(env.chronics_handler.subpaths)

do_nothing = env.action_space()



print("dir(env.)",dir(env))

for i in range(total_episode):
#for i in range(10):
    probas = np.zeros(total_episode)
    probas[i%total_episode]=1
    ###################################
    _ = env.chronics_handler.sample_next_chronics(probas)  # this is added
    ###################################
    obs = env.reset()
    #print("env._time_next_maintenance",env._time_next_maintenance)
    #print("env._duration_next_maintenance",env._duration_next_maintenance)
    #print("env._maintenance",env._maintenance)
    #print("dir(env.chronics_handler)",dir(env.chronics_handler))
    #print("dir(env.chronics_handler._real_data)",dir(env.chronics_handler._real_data))
    #print("type(env.chronics_handler._real_data)",type(env.chronics_handler._real_data))
    #print("dir(env.chronics_handler._real_data.data)",dir(env.chronics_handler._real_data.data))
    #print("type(env.chronics_handler._real_data.data)",type(env.chronics_handler._real_data.data))
    #print("env.chronics_handler._real_data.data.line_to_maintenance",env.chronics_handler._real_data.data.line_to_maintenance)
    #print(i,"np.count_nonzero(env.chronics_handler._real_data.data.maintenance)/96",np.count_nonzero(env.chronics_handler._real_data.data.maintenance)/96)
    env.chronics_handler._real_data.data.maintenance = np.zeros(env.chronics_handler._real_data.data.maintenance.shape, dtype=bool)    

    env._time_next_maintenance[0] = -1
    temp = obs.time_next_maintenance
    l = collections.Counter(temp).most_common()[1:]
    print("episode",i,"time_next_maintenance",l)
    for t in range(10000):
        obs, reward, done, info = env.step(do_nothing)
        disconnected_line = np.where(obs.line_status==False)[0]
        if len(disconnected_line)>0:
            print("t",t, disconnected_line)
            print("obs.time_next_maintenance",obs.time_next_maintenance)
            _ = plot_helper.plot_obs(obs)
            plt.show()
        if done:
            break


