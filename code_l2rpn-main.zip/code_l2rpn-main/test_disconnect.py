import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import grid2op
print("grid2op.__version__",grid2op.__version__)

# Backend class to use
try:
    from lightsim2grid.LightSimBackend import LightSimBackend
    backend = LightSimBackend()
    print("backend is LightSimBackend")
except ModuleNotFoundError:
    from grid2op.Backend import PandaPowerBackend
    backend = PandaPowerBackend()
    print("backend is PandaPowerBackend")

from grid2op.Runner import Runner
from grid2op.Parameters import Parameters

from grid2op.Agent.BaseAgent import BaseAgent
import re


from grid2op.Reward import GameplayReward
env = grid2op.make("l2rpn_icaps_2021_small",
                   #reward_class=GameplayReward,
                   backend=backend,
                   difficulty="0")
from grid2op.PlotGrid import PlotMatplot
plot_helper = PlotMatplot(env.observation_space, line_id=False)

n_line = env.reset().time_next_maintenance.shape[0]
print("n_line",n_line)

line_list = [0,9,13,14,18,23,27,39,45,56]

"""
for i in range(len(line_list)):
    done_list = []
    for j in range(i+1,len(line_list)):
        obs = env.reset()
        act = env.action_space({"set_line_status": [(line_list[i], -1)]})
        obs, reward, done, info = env.step(act)
        if done is False:
            act = env.action_space({"set_line_status": [(line_list[j], -1)]})
            obs, reward, done, info = env.step(act)

        print(line_list[i],line_list[j],done)
        fig = plot_helper.plot_obs(obs)
        plt.savefig("fig_"+str(line_list[i])+"_"+str(line_list[j])+".png")
        plt.close()
        done_list.append([line_list[j],done])
    done_list = np.array(done_list, np.int32)
    np.savetxt("done_nplist1_"+str(line_list[i])+".dat", done_list, fmt='%d')
"""


for i in range(len(line_list)):
    done_list = []
    for j in range(i+1,len(line_list)):
        for k in range(j+1,len(line_list)):
            obs = env.reset()
            act = env.action_space({"set_line_status": [(line_list[i], -1)]})
            obs, reward, done, info = env.step(act)
            if done is False:
                act = env.action_space({"set_line_status": [(line_list[j], -1)]})
                obs, reward, done, info = env.step(act)
                if done is False:
                    act = env.action_space({"set_line_status": [(line_list[k], -1)]})
                    obs, reward, done, info = env.step(act)

            print(line_list[i],line_list[j],line_list[k],done)
            fig = plot_helper.plot_obs(obs)
            plt.savefig("fig2_"+str(line_list[i])+"_"+str(line_list[j])+"_"+str(line_list[k])+".png")
            plt.close()
            done_list.append([line_list[j],line_list[k],done])
    done_list = np.array(done_list, np.int32)
    np.savetxt("done_nplist2_"+str(line_list[i])+".dat", done_list, fmt='%d')

