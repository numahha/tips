import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import grid2op
print("grid2op.__version__",grid2op.__version__)

# Backend class to use
try:
    from lightsim2grid.LightSimBackend import LightSimBackend
    backend = LightSimBackend()
except ModuleNotFoundError:
    from grid2op.Backend import PandaPowerBackend
    backend = PandaPowerBackend()

from grid2op.Runner import Runner
from grid2op.Parameters import Parameters

from grid2op.Agent.BaseAgent import BaseAgent
import re


from grid2op.Reward import GameplayReward
env = grid2op.make("l2rpn_icaps_2021_small",
                   #reward_class=GameplayReward,
                   backend=backend,
                   difficulty="competition")
from grid2op.PlotGrid import PlotMatplot
plot_helper = PlotMatplot(env.observation_space, line_id=False)
obs = env.reset()


fig = plot_helper.plot_obs(obs)


modify_bus = np.full(shape=3, dtype=bool, fill_value=True)

act = env.action_space()

#act.redispatch = [(0, 1.39)]
act.redispatch = [(0, 1.41)]

print("act.to_vect()",act.to_vect())
print ('env.action_space.gen_redispatchable',env.action_space.gen_redispatchable)
print ('env.action_space.gen_pmin',env.action_space.gen_pmin)
print ('env.action_space.gen_pmax',env.action_space.gen_pmax)
print ('env.action_space.gen_max_ramp_down',env.action_space.gen_max_ramp_down)
print ('env.action_space.gen_max_ramp_up',env.action_space.gen_max_ramp_up)



obs, reward, done, info = env.step(act)
print("obs.topo_vect",obs.topo_vect)
fig = plot_helper.plot_obs(obs)
print("reward",reward)
plt.show()
obs = env.reset()
