import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import grid2op
print("grid2op.__version__",grid2op.__version__)

# Backend class to use
try:
    from lightsim2grid.LightSimBackend import LightSimBackend
    backend = LightSimBackend()
except ModuleNotFoundError:
    from grid2op.Backend import PandaPowerBackend
    backend = PandaPowerBackend()

from grid2op.Runner import Runner
from grid2op.Parameters import Parameters

from grid2op.Agent.BaseAgent import BaseAgent
import re


#from grid2op.Reward import L2RPNReward
env = grid2op.make("l2rpn_icaps_2021_small",
                   backend=backend,
                   difficulty="competition")

from grid2op.PlotGrid import PlotMatplot
plot_helper = PlotMatplot(env.observation_space, line_id=False)

obs = env.reset()

print("obs.to_vect().shape =",obs.to_vect().shape[0])
print("act.to_vect().shape =",env.action_space().to_vect().shape[0])

print("n_line =",obs.rho.shape[0])
print("n_gen =",obs.gen_p.shape[0])
print("n_load =",obs.load_p.shape[0])
print("n_sub =",obs.time_before_cooldown_sub.shape[0])
print("n_storage =",obs.storage_charge.shape[0])

print("topo_vect =",obs.topo_vect,"len", obs.topo_vect.shape[0])
print("last_alarm =",obs.last_alarm,"len", obs.last_alarm.shape[0])

print ('env.action_space.sub_info',env.action_space.sub_info,"len",env.action_space.sub_info.shape[0],"sum",env.action_space.sub_info.sum())
print ('env.action_space.load_to_subid',env.action_space.load_to_subid,"len",env.action_space.load_to_subid.shape[0])
print ('env.action_space.gen_to_subid',env.action_space.gen_to_subid,"len",env.action_space.gen_to_subid.shape[0])
print ('env.action_space.line_or_to_subid',env.action_space.line_or_to_subid,"len",env.action_space.line_or_to_subid.shape[0])
print ('env.action_space.line_ex_to_subid',env.action_space.line_ex_to_subid,"len",env.action_space.line_ex_to_subid.shape[0])
print ('env.action_space.storage_to_subid',env.action_space.storage_to_subid,"len",env.action_space.storage_to_subid.shape[0])


#temp_sum = 0
#for i in range(len(env.action_space.sub_info)):
#    temp = 2**env.action_space.sub_info[i]
#    temp_sum += temp
#    print(i,temp)
#print("|A|",temp_sum)

fig = plot_helper.plot_obs(obs)
plt.show()
#from grid2op.Agent import DoNothingAgent
#my_agent = DoNothingAgent(env.action_space)
