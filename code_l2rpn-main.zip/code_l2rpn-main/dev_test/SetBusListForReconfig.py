import numpy as np


class SetBusListForReconfig():
    def __init__(self,env):
        self.n_sub = env.n_sub
        self.sub_info = env.sub_info[:]

        self.sub_sum_info = [0]
        temp=0
        for i in range(1,env.n_sub):
            self.sub_sum_info.append( temp + env.sub_info[i-1] )
            temp += env.sub_info[i-1]

        temp = [ np.zeros(env.sub_info[i].sum(),dtype=bool) for i in range(env.n_sub) ]
        for i in range(env.n_line):
            temp[env.line_or_to_subid[i]][env.line_or_to_sub_pos[i]] = True
            temp[env.line_ex_to_subid[i]][env.line_ex_to_sub_pos[i]] = True
        self.line_num = []
        for i in range(env.n_sub):
            self.line_num.append(np.where(temp[i]==True)[0].shape[0])


    def get_setbuslist(self, obs, sub_id, topo_id):
        if (topo_id < 2**(self.sub_info[sub_id]-1)):

            # topo_idに対応するリストの作成
            temp = topo_id
            nume = 2**(self.sub_info[sub_id]-2)
            a = []
            while True:
                q, temp = divmod(temp, nume)
                if q==1:
                    a.append(2)
                else:
                    a.append(1)
                nume //= 2
                if len(a) == (self.sub_info[sub_id]-1):
                    break

            # 即死指示の判定            
            if (2 not in a[: self.line_num[sub_id]-1]) and (2 in a[self.line_num[sub_id]-1 :]):
                return []


            # 変化のない指示の削除
            current_topo = obs.topo_vect[self.sub_sum_info[sub_id]+1 : self.sub_sum_info[sub_id] + self.sub_info[sub_id]]
            res = []
            for i in range(len(a)):
                if current_topo[i] !=a[i]:
                    res.append((self.sub_sum_info[sub_id]+1+i, a[i]))


            # 遮断電線に関する指示の削除
            #disconnected_line = np.where(obs.line_status==False)[0]

            return res

        else:
            return []










import pandas as pd
import matplotlib.pyplot as plt
import collections
import grid2op
print("grid2op.__version__",grid2op.__version__)


try:
    from lightsim2grid.LightSimBackend import LightSimBackend
    backend = LightSimBackend()
    print("backend is LightSimBackend")
except ModuleNotFoundError:
    from grid2op.Backend import PandaPowerBackend
    backend = PandaPowerBackend()
    print("backend is PandaPowerBackend")

import re
from grid2op.Action import DontAct

line_list = [0,9,13,14,18,23,27,39,45,56]

env = grid2op.make("l2rpn_icaps_2021_small",
                   opponent_action_class=DontAct,
                   backend=backend,
                   difficulty="0")
env.seed(0)
from grid2op.PlotGrid import PlotMatplot
plot_helper = PlotMatplot(env.observation_space, line_id=False)

do_nothing = env.action_space()


#sub_info_list = [ env.sub_info[i] for i in range(env.n_sub) ]
#sub_sum_info_list = [0]
#temp=0
#for i in range(1,env.n_sub):    
#    sub_sum_info_list.append( temp + env.sub_info[i-1] )
#    temp += env.sub_info[i-1]


obs = env.reset()
env.chronics_handler._real_data.data.maintenance = np.zeros(env.chronics_handler._real_data.data.maintenance.shape, dtype=bool)    
obs = env.reset()
act = env.action_space()
act.line_set_status = [(56, -1)]

obs, reward, done, info = env.step(act)




test = SetBusListForReconfig(env)
for i in range(32):
    print(test.get_setbuslist(obs, 1, i))

        #    res = [(i,1) for i in range(1,self.sub_info[sub_id])]
        #    return None

    #"""
    #def possible_topo_id(obs, sub_id):

"""
for i in range(total_episode):
#for i in range(10):
    probas = np.zeros(total_episode)
    probas[i%total_episode]=1
    _ = env.chronics_handler.sample_next_chronics(probas)  # this is added
    act = env.action_space()
    #act.set_bus = [(0, 2)]
    #act.set_bus = [(1, 2)]
    #act.set_bus = [(2, 2)]

    sub_id = 26

    #temp = []
    #temp += [(sub_sum_info_list[sub_id]+0, 2)]
    #temp += [(sub_sum_info_list[sub_id]+1, 2)]
    #temp += [(sub_sum_info_list[sub_id]+2, 2)]
    #temp += [(sub_sum_info_list[sub_id]+3, 2)]
    #temp += [(sub_sum_info_list[sub_id]+4, 2)]
    #temp += [(sub_sum_info_list[sub_id]+5, 2)]

    #act.set_bus = temp
    #act.set_bus = [(sub_sum_info_list[sub_id]+0, 2)]
    #act.set_bus = [(sub_sum_info_list[sub_id]+1, 2)]
    #act.set_bus = [(sub_sum_info_list[sub_id]+2, 2)]
    #act.set_bus = [(sub_sum_info_list[sub_id]+3, 2)]
    #act.set_bus = [(sub_sum_info_list[sub_id]+4, 2)]
    #act.set_bus = [(sub_sum_info_list[sub_id]+5, 2)]

    for j in range(env.sub_info[sub_id]):
        act.set_bus = [(sub_sum_info_list[sub_id]+0, 2)]


    #act.set_bus = [(1, 2)]
    #act.set_bus = [(2, 2)]
    #target_topology = 2*np.ones(env.sub_info[sub_id], dtype=np.int32)
    #target_topology
    #reconfig_sub = env.action_space({"set_bus": {"substations_id": [(sub_id, target_topology)] } })

    obs, reward, done, info = env.step(act)
    #act = env.action_space({"set_line_status": [(39, -1)]})
    #obs, reward, done, info = env.step(act)
    #act = env.action_space({"set_line_status": [(27, -1)]})
    #obs, reward, done, info = env.step(act)



    fig = plot_helper.plot_obs(obs)
    #plt.savefig("fig2_"+str(line_list[i])+"_"+str(line_list[j])+"_"+str(line_list[k])+".png")
    plt.show()
    exit()


    print(i)
    rho_list = []
    while True:
        rho_list.append(obs.rho)
        obs, reward, done, info = env.step(do_nothing)
        if done:
            break
    rho_list = np.array(rho_list)
    np.savetxt("rho_record_"+str(i)+".csv",rho_list)
    for j in range(rho_list.shape[1]):
        plt.plot(rho_list[:,j])
    plt.savefig("rho_record_"+str(i)+".png")
    plt.close()
"""
