import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import grid2op
print("grid2op.__version__",grid2op.__version__)

# Backend class to use
try:
    from lightsim2grid.LightSimBackend import LightSimBackend
    backend = LightSimBackend()
except ModuleNotFoundError:
    from grid2op.Backend import PandaPowerBackend
    backend = PandaPowerBackend()

from grid2op.Runner import Runner
from grid2op.Parameters import Parameters

from grid2op.Agent.BaseAgent import BaseAgent
import re


from grid2op.Reward import GameplayReward
env = grid2op.make("l2rpn_icaps_2021_small",
                   #reward_class=GameplayReward,
                   backend=backend,
                   difficulty="competition")
from grid2op.PlotGrid import PlotMatplot
plot_helper = PlotMatplot(env.observation_space, line_id=False)
obs = env.reset()


fig = plot_helper.plot_obs(obs)


modify_bus = np.full(shape=3, dtype=bool, fill_value=True)

#act = env.action_space({"change_bus": {"substations_id": [(0, modify_bus)]}})

act = env.action_space()
act.set_bus = [(0, 2)]
act.set_bus = [(1, 2)]
act.set_bus = [(2, 2)]

#act = env.action_space()
#act.change_bus = [0]
#act.change_bus = [1]
#act.change_bus = [2]

print("act.to_vect()",act.to_vect())

obs, reward, done, info = env.step(act)
print("obs.topo_vect",obs.topo_vect)
fig = plot_helper.plot_obs(obs)
print("reward",reward)
plt.show()
obs = env.reset()
