import numpy as np
import matplotlib
import grid2op
import re
import matplotlib.pyplot as plt
assert grid2op.__version__ >= "1.1.0", "You need grid2op at least 1.1.0 to compete in this track."
from grid2op.PlotGrid import PlotMatplot
env_opp = grid2op.make("l2rpn_icaps_2021_small", difficulty="0")
env_opp.seed(3)  # for reproducible experiments
obs = env_opp.reset()
plot_helper_opp = PlotMatplot(env_opp.observation_space, width=1920,height=1080, line_id=False)
#_ = plot_helper_opp.plot_layout()



line_id_opp = 56
reconnect_action_opp = env_opp.action_space({"set_line_status": [(line_id_opp, +1)]})
do_nothing_opp = env_opp.action_space()
_ = plot_helper_opp.plot_obs(obs)
print("obs.time_next_maintenance",obs.time_next_maintenance)
print("obs.line_status",obs.line_status)
plt.show()




for i in range(5):
    obs, reward, done, info = env_opp.step(do_nothing_opp)
_ = plot_helper_opp.plot_obs(obs)
print("obs.time_next_maintenance",obs.time_next_maintenance)
print("obs.line_status",obs.line_status)
plt.show()



obs, reward, done, info = env_opp.step(do_nothing_opp)
print("obs.time_next_maintenance",obs.time_next_maintenance)
_ = plot_helper_opp.plot_obs(obs)
print("obs.line_status",obs.line_status)
plt.show()
print("The flow on this powerline is {:.1f}%"\
      "".format(100*obs.rho[line_id_opp]))
print("This powerline is unavailable for {} time steps".format(obs.time_before_cooldown_line[line_id_opp]))
print("I can also spot an attack by looking at the \"info\" dictionnary, that tells me that an attack is taking " \
      "place on powerline: {}, and this attack will last {} time steps (in total, it started this time step "\
      "so it will be over in 47 = 48 - 1 time steps)." \
      "".format(np.where(info["opponent_attack_line"])[0], info["opponent_attack_duration"]))


obs, reward, done, info = env_opp.step(do_nothing_opp)
_ = plot_helper_opp.plot_obs(obs)
print("obs.time_next_maintenance",obs.time_next_maintenance)
print("obs.line_status",obs.line_status)
plt.show()
print("The powerline will be unavailble for again {} time steps."\
      "".format(obs.time_before_cooldown_line[line_id_opp]))





obs, reward, done, info = env_opp.step(reconnect_action_opp)
print("Can i act on the powerline: {}".format(obs.time_before_cooldown_line[line_id_opp] == 0))
print("In how many time I will be able to reconnect it: {}".format(obs.time_before_cooldown_line[line_id_opp]))
print("Is the powerline connected: {}".format(obs.line_status[line_id_opp]))
print("The flow on it is {:.1f}A".format(obs.a_or[line_id_opp]))
_ = plot_helper_opp.plot_obs(obs)
print("obs.time_next_maintenance",obs.time_next_maintenance)
print("obs.line_status",obs.line_status)
plt.show()
