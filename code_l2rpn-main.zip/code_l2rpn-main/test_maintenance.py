import numpy as np
import re
import grid2op
import collections
env = grid2op.make("l2rpn_icaps_2021_small",difficulty="0")
#env.seed(0)  # for reproducible experiments

###################################
# total number of episode
total_episode = len(env.chronics_handler.subpaths)
print("total_episode",total_episode)

print("dir(env)",dir(env))
#print("dir(env.chronics_handler)",dir(env.chronics_handler))


maintenance_set_list = []


for i in range(total_episode):
#for i in range(10):
    probas = np.zeros(total_episode)
    probas[-(i%total_episode)]=1
    ###################################
    _ = env.chronics_handler.sample_next_chronics(probas)  # this is added
    ###################################
    obs = env.reset()
    temp = obs.time_next_maintenance
    l = collections.Counter(temp).most_common()[1:]
    #print(obs.duration_next_maintenance)

    if len(l)>1:
        min_interval = 10000
        for i2 in range(len(l)):
            for i3 in range(i2+1,len(l)):
                min_interval = min(min_interval, (abs(l[i2][0] - l[i3][0])))
        print(i,env.chronics_handler.get_name(),l,min_interval)
        if min_interval<96:
            exit()
    else:
        print(i,env.chronics_handler.get_name(),l)
    #print("env.chronics_handler._real_data.data.line_to_maintenance",env.chronics_handler._real_data.data.line_to_maintenance)
    #print("env.chronics_handler._real_data.data.maintenance_starting_hour",env.chronics_handler._real_data.data.maintenance_starting_hour)
    #print("env.chronics_handler._real_data.data.maintenance_ending_hour",env.chronics_handler._real_data.data.maintenance_ending_hour)
    print(i,"np.count_nonzero(env.chronics_handler._real_data.data.maintenance)/96",np.count_nonzero(env.chronics_handler._real_data.data.maintenance)/96)
    #print("env.chronics_handler._real_data.data.maintenance.shape",env.chronics_handler._real_data.data.maintenance.shape)
    #print("env.chronics_handler._real_data.data.",env.chronics_handler._real_data.data.)
    #print("env.chronics_handler._real_data.data.",env.chronics_handler._real_data.data.)
    #print("env.chronics_handler._real_data.data.",env.chronics_handler._real_data.data.)


    for j,k in l:
        key = np.where(temp==j)[0]
        if len(key)==1:
            maintenance_set_list.append((key[0]))
        elif len(key)==2:
            maintenance_set_list.append((key.min(),key.max()))
        else:
            print("len(key) =",len(key))
            exit()

print("len",len(maintenance_set_list))
print("counter",collections.Counter(maintenance_set_list).most_common())
