# ROS1 (melodic, Ubuntu 18)

## 環境設定
* [Install ROS1](http://wiki.ros.org/melodic/Installation/Ubuntu)
* [Install gazebo and ros_control](http://wiki.ros.org/ros_control)

Recommendedの方法をそのままやればOK．

## 概要

この例題のために必要なROS 1の知識をまとめた．
指示通りにコマンドを叩けば，動くように作ってある．

* step1 ... ROS1で運動学
* step2 ... ROS1で動力学シミュレーション（制御なし）
* step3 ... ROS1で動力学シミュレーション（制御あり・公式プラグイン）
* step4-6 ... ROS1で動力学シミュレーション（制御あり・自作プラグイン）
* step7 ... ROS1とハードウェア制御プログラムの統合
* step8 ... ROS1でリアルタイム制御


## メモ

* ROSを使いたい一番の動機は，プログラムを開発した時に，シミュレーション検証->実機実装がスムーズにいくと思ったため．
* 付属的な動機は，画像解析周りのライブラリが充実していると思ったため（現時点では要らないが将来的には欲しい）．
* 当初はROS2での開発を考えていたが，ros2_controlが不透明なので，先にROS1で作ることにした．
