Step 2
======

gazeboを用いた、振子（制御入力無し）シミュレーション

.. code:: shell

    roslaunch mylaunch.launch


memo
----

xacroをurdfに変換

.. code:: shell

    rosrun xacro xacro pendulum.xacro >pendulum.urdf

urdfをrvizで確認。

.. code:: shell

    roslaunch urdf_tutorial display.launch model:=pendulum.urdf


