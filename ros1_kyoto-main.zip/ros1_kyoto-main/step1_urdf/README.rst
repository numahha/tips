Step 1
======

* xacro ... 書くのが簡単。ros2では使えない
* urdf ... xacroを変換して作ると楽。gazeboに読ませるのはこいつ（このステップではgazeboは登場しない）。


xacroをurdfに変換

.. code:: shell

    rosrun xacro xacro armbot3.xacro >armbot3.urdf

urdfをrvizで表示。

.. code:: shell

    roslaunch urdf_tutorial display.launch model:=armbot3.urdf

* joint_state_publisherというGUIを用いて、様々な関節角度に対するリンクの運動学を簡単に表示することができる。
