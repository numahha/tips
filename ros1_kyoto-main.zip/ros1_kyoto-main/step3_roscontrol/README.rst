Step 3
======

ros_controlの公式プラグインを用いた、振子（制御入力有り）シミュレーション。

JointEffortController
---------------------

JointEffortControllerというプラグインでは、力・トルクを指定し、それをそのまま指令値として送る。
使用例は以下。

.. code:: shell

    roslaunch mylaunch.launch

別ターミナルで、トルクの値を指示するtopicを/pendulum_ns/pole_joint_controller/command宛に送る。

.. code:: shell

    rostopic pub /pendulum_ns/pole_joint_controller/command std_msgs/Float64 "data: 1.5"


今回、関節角の粘性摩擦（xacro or urdf参照）を加えているので、重力トルクと定常入力トルクが釣り合った角度で静止する。

JointPositionController
---------------------
JointPositionControllerというプラグインでは、位置を指定し、PIDフィードバック制御入力を計算して指令値として送る。
使用例は以下。

.. code:: shell

    roslaunch mylaunch2.launch

別ターミナルで、目標角度値を指示するtopicを/pendulum_ns/pole_joint_controller/command宛に送る。

.. code:: shell

    roopic pub /pendulum_ns/pole_joint_controller/command std_msgs/Float64 "data: -1."


memo
----

xacroをurdfに変換

.. code:: shell

    rosrun xacro xacro pendulum.xacro >pendulum.urdf

urdfをrvizで確認。

.. code:: shell

    roslaunch urdf_tutorial display.launch model:=pendulum.urdf

