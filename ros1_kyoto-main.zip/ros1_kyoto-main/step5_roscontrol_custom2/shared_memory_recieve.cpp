#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/stat.h>
using namespace std;


int main(){

    const string file_path_position = "/home/areyouok/data_key_positoin.dat";
    const int id_position = 50;
    const key_t key_position = ftok(file_path_position.c_str(), id_position);
    const int seg_id_position = shmget(key_position, 0, 0);

    const string file_path_imput = "/home/areyouok/data_key_imput.dat";
    const int id_imput = 40;
    const key_t key_imput = ftok(file_path_imput.c_str(), id_imput);
    const int seg_id_imput = shmget(key_imput, 0, 0);




    if(seg_id_imput == -1 || seg_id_position == -1){
        cerr << "Failed to acquire segment" << endl;
        return EXIT_FAILURE;
    }


    double* shared_memory_position
     = (double*)(shmat(seg_id_position, 0, 0));
    double* shared_memory_imput
      = (double*)(shmat(seg_id_imput, 0, 0));


    int flag = 0;
    char c;
    cout << "'q': fin   'o':input" << endl;


    double get_data = 0.0;
    double imput_data = 0.0;

    double control_data = 1.0;

    while(flag == 0){
        cin.get(c);
        if(c == 'q') flag = 1;
        else if(c == 'o') {
             std::cin >> control_data;
        }
        else printf("shared data = %f\n\n",shared_memory_position[0]);


        get_data = shared_memory_position[0];
        imput_data = (10-get_data)*control_data;
        shared_memory_imput[0] = imput_data;

        std::cout << imput_data << " " << get_data << " " << control_data << '\n';


        std::cout << "___________________________________" << std::endl;
    }



    shmdt(shared_memory_imput);
    shmdt(shared_memory_position);

    return 0;
}
