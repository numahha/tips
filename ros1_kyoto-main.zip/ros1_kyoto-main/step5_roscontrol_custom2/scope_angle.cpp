#include <iostream>
//#include <cstdio>
//#include <cstdlib>
//#include <string>
//#include <sys/types.h>
//#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/stat.h>
//#include <pthread.h>
 #include <unistd.h>
using namespace std;

pthread_mutex_t *m;
int main(){

    //char dir[255];
    //getcwd(dir,255);
    //cout << "current dir:" << dir << endl; 

    cout << getenv("HOME") << endl;

    const string data_path = "/home/areyouok/data_key.dat";
    const string mutex_path = "/home/areyouok/mutex_key.dat";
    const int data_id = 50;
    const int mutex_id = 51;

    const key_t data_key = ftok(data_path.c_str(), data_id);
    const key_t mutex_key = ftok(mutex_path.c_str(), mutex_id);

    const int seg_data_id = shmget(data_key, 0, 0);
    const int seg_mutex_id = shmget(mutex_key, 0, 0);


    cout << seg_data_id << " " << seg_mutex_id << " " << data_key <<   " " << mutex_key << endl;

    if(seg_data_id == -1 || seg_mutex_id == -1 ){
        cerr << "Failed to acquire segment " << endl;
        return EXIT_FAILURE;
    }



    string s; 
        
        double* shared_memory = (double*)(shmat(seg_data_id, 0, 0));
	m = (pthread_mutex_t *)shmat(seg_mutex_id, NULL, 0);

	pthread_mutex_lock(m);

    while(1){

	//double* shared_memory = (double*)(shmat(seg_data_id, 0, 0));
	//m = (pthread_mutex_t *)shmat(seg_mutex_id, NULL, 0);

	//pthread_mutex_lock(m);

	printf("shared data = %f\n\n",shared_memory[0]);

	//pthread_mutex_unlock(m);


	//shmdt(shared_memory);
	//shmdt(m);



     
         sleep(2);
    }

        pthread_mutex_unlock(m);


	shmdt(shared_memory);
	shmdt(m);

   
    return 0;
}
