Step 4
======

ros_controlの自作プラグインを用いた、振子（制御入力有り）シミュレーション。


パッケージの自作
---------------

effort_controllers_numaという名前のパッケージを作る。
中身は、jointPositionControllerである。
異なる点は、
ファイルの名前や参照を少々変更したことと、
ソース内にrosinfoを書き加えることにより立ち上げ時にメッセージが余分に表示されることだけである。


まず、公式に沿って、workspaceを作る。

.. code:: shell

    mkdir -p ~/catkin_ws/src
    cd ~/catkin_ws/src
    catkin_init_workspace
    echo "source ~/catkin_ws/devel/setup.bash" >> ~/.bashrc

次に、このディレクトリ内にあるeffort_controllers_numa.zipを解凍して、~/catkin_ws/src/以下に置く。
そして、次のようにインストールする。

.. code:: shell

    cd ~/catkin_ws/
    catkin_make
    source ~/.bashrc

このディレクトリ内に戻ってきて、roslaunchする。

.. code:: shell

    roslaunch mylaunch.launch

このとき、ターミナルに``This is custom plugin !''というメッセージが出ていると思う。

前述の通り、中身はjointPositionControllerなので、次のように目標角度を送ると動く。

.. code:: shell

    rostopic pub /pendulum_ns/pole_joint_controller/command std_msgs/Float64 "data: -1.0"


`公式プラグイン <https://github.com/ros-controls/ros_controllers/tree/melodic-devel/effort_controllers>`_ と見比べることにより、違いをチェックすること。


