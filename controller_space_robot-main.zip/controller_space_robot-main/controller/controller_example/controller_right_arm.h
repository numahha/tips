#ifndef SPACE_ROBOT_RIGHT_ARM_CONTROLLER_H
#define SPACE_ROBOT_RIGHT_ARM_CONTROLLER_H

#include<iostream>
#include<string>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<vector>
#include<cmath>


#include "./src/controller_arm.h"




class controller_right_arm : public controller_arm{

private:
    double K_p_0 = 15.0; //[N*m / rad]
    double K_p_1 = 15.0;
    double K_p_2 = 15.0;
    double K_d_0 = 0.15; //[N*m / (rad/s)]
    double K_d_1 = 0.15;
    double K_d_2 = 0.15;

public:
    controller_right_arm(std::vector<double> given_theta);
    ~controller_right_arm();
    void main_controller();
};




inline controller_right_arm::controller_right_arm(std::vector<double> given_theta) : controller_arm(given_theta){
    return;
}


inline void controller_right_arm::main_controller(){

    if(time_sec <= 50){ //[sec]
        target_theta[0] = 0.6;
        target_theta[1] = -1.9;
        target_theta[2] = 1.5;
    }
    else if(time_sec <= 100){
        target_theta[0] = 1.6;
        target_theta[1] = 1.9;
        target_theta[2] = -1.5;
    }
    else if(time_sec <= 150){
        target_theta[0] = 0.6;
        target_theta[1] = -1.9;
        target_theta[2] = 1.5;
    }
    else{
        target_theta[0] = 1.6;
        target_theta[1] = 1.9;
        target_theta[2] = -1.5;
    }

    torque[0] = (target_theta[0] - theta[0])*K_p_0 + (-dtheta[0])*K_d_0;
    torque[1] = (target_theta[1] - theta[1])*K_p_1 + (-dtheta[1])*K_d_1;
    torque[2] = (target_theta[2] - theta[2])*K_p_2 + (-dtheta[2])*K_d_2;

    return;
}

inline controller_right_arm::~controller_right_arm(){
    return;
}


#endif
