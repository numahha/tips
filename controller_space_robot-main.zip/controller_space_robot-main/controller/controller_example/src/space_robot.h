#ifndef SPACE_ROBOT_H
#define SPACE_ROBOT_H

#include<iostream>
#include<string>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<vector>
#include<cmath>

#include "shm_host_guest.h"

#include "../controller_left_arm.h"
#include "../controller_right_arm.h"


class space_robot{

  private:
    std::vector<double> DA_data;  // [Nm]
    std::vector<double> ENC_data; // [rad]

    int default_space_robot_control();
    shm_guest shmguest; // shared memory
    controller_left_arm* controllerA;
    controller_right_arm* controllerB;

  public:
    space_robot();
    ~space_robot();
};

#endif
