#ifndef CONTROLLER_ARM_H
#define CONTROLLER_ARM_H

#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<vector>
#include<cmath>


class controller_arm{

private:


protected:
  std::vector<double> theta;  // [rad]
  std::vector<double> dtheta; // [rad/s]
  std::vector<double> theta_old;  // [rad]
  std::vector<double> dtheta_old; // [rad/s]
  double time_sec; //[sec]
  std::vector<double> torque; // [Nm]

public:
  controller_arm(std::vector<double> given_theta);
  ~controller_arm();

  std::vector<double> target_theta;

  virtual void main_controller(){}

  void read_data(std::vector<double> given_theta, double time_now);
  std::vector<double> write_data();

};

#endif
