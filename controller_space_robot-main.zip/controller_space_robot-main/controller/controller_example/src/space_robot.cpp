#include "space_robot.h"

#include "../definition_const_data.h"

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <cmath>


#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/stat.h>

#include <time.h>
#include <chrono>
#include <thread>

#include <csignal>

#include <sys/mman.h>




void signalHandler( int signum ) {

    std::cout << "Interrupt signal (" << signum << ") received.\n";
    shm_guest shmguest;
    shmguest.shm_DA_1[0] = 0.0;
    shmguest.shm_DA_2[0] = 0.0;
    shmguest.shm_DA_3[0] = 0.0;
    exit(signum);
}



// functions for real-time control
// ref https://sites.google.com/site/roboticstools/HOME/RTM/RealTimeRTM/LinuxStandard/source?tmpl=%2Fsystem%2Fapp%2Ftemplates%2Fprint%2F&showPrintDialog=1
#ifndef NSEC_PER_SEC
#define NSEC_PER_SEC 1000000000L
#endif
static void timespec_add_ns(struct timespec *a, unsigned int ns)
{
    ns += a->tv_nsec;
    while(ns >= NSEC_PER_SEC) {
        ns -= NSEC_PER_SEC;
        a->tv_sec++;
    }
    a->tv_nsec = ns;
}
static int timespec_compare(const struct timespec *lhs, const struct timespec *rhs) {
    if (lhs->tv_sec < rhs->tv_sec)
        return -1;
    if (lhs->tv_sec > rhs->tv_sec)
        return 1;
    return lhs->tv_nsec - rhs->tv_nsec;
}













space_robot::space_robot(){

    std::cout << "space_robot() start" << '\n';

    DA_data.assign(3,0.0);
    ENC_data.assign(3,0.0);

    signal(SIGINT, signalHandler);

    space_robot::default_space_robot_control();

    return;
}




int space_robot::default_space_robot_control(){

    std::chrono::system_clock::time_point start, end, clock_start;
    clock_start =  std::chrono::system_clock::now();

    ENC_data[0] = shmguest.shm_ENC_1[0];
    ENC_data[1] = shmguest.shm_ENC_2[0];
    ENC_data[2] = shmguest.shm_ENC_3[0];

    controllerA = new controller_left_arm(ENC_data);


    long long gazebo_loop = 0, gazebo_loop_old = 0;
    gazebo_loop = shmguest.shm_loop_count[0];


    // real time setting
    #ifdef _IS_REALTIME
    struct sched_param param;
    int policy = SCHED_FIFO;
    memset(&param, 0, sizeof(param));
    param.sched_priority = sched_get_priority_max(policy);
    if (sched_setscheduler(0, policy, &param) < 0) {
      printf("sched_setscheduler: %s\n", strerror(errno));
      printf("Please check you are setting /etc/security/limits.conf\n");
      exit (EXIT_FAILURE);
    }
    if (mlockall(MCL_CURRENT|MCL_FUTURE) < 0) {
      printf("mlockall: %s\n", strerror(errno));
      exit (EXIT_FAILURE);
    }
    #endif

    struct timespec tsperiod, tsnow;
    unsigned int control_period_ns = (unsigned int) (time_duration*1000*1000*1000); // nano sec

    clock_gettime(CLOCK_MONOTONIC, &tsperiod);
    while(1){

        clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &tsperiod,0); 
        start = std::chrono::system_clock::now();

        ENC_data[0] = shmguest.shm_ENC_1[0];
        ENC_data[1] = shmguest.shm_ENC_2[0]; // shared_memory_ENC
        ENC_data[2] = shmguest.shm_ENC_3[0];


        //controll*************************************************************
        end = std::chrono::system_clock::now();
        double time_now = static_cast<double>(std::chrono::duration_cast<std::chrono::microseconds>(end - clock_start).count())/1000000.0;

        controllerA->read_data(ENC_data, time_now);
        controllerA->main_controller();
        std::vector<double> DA_torque = controllerA->write_data();


        //max limit check
        for (int j = 0; j < 3; j++) DA_data[j] = DA_torque[j];
        for (int j = 0; j < 3; j++) {
            if(abs(DA_data[j]) >= left_arm_torque_max[j]) {
                if(DA_data[j] > 0) DA_data[j] = left_arm_torque_max[j];
                else if(DA_data[j] < 0) DA_data[j] = -left_arm_torque_max[j];
            }
        }
        //*************************************************************



        shmguest.shm_DA_1[0] = DA_data[0]; //shared_memory_DA
        shmguest.shm_DA_2[0] = DA_data[1];
        shmguest.shm_DA_3[0] = DA_data[2];


        gazebo_loop_old = gazebo_loop;
        gazebo_loop = shmguest.shm_loop_count[0];

        printf("time %4.5lf   gazebo %3lld  ||  #left0: target=%3.3lf  ENC=%10.6lf | #left1: target=%3.3lf ENC=%10.6lf  |  #left2: target=%3.3lf  ENC=%10.6lf \n",
                time_now,gazebo_loop-gazebo_loop_old, controllerA->target_theta[0], ENC_data[0], controllerA->target_theta[1], ENC_data[1], controllerA->target_theta[2],ENC_data[2]);

        // set next clock time
        timespec_add_ns(&tsperiod, control_period_ns);
        clock_gettime(CLOCK_MONOTONIC, &tsnow);
        if (timespec_compare(&tsperiod, &tsnow)<0){
          printf("overruning!\n");
          tsperiod = tsnow;
          timespec_add_ns(&tsperiod, control_period_ns);
        }
        //printf("tv_sec=%ld  tv_nsec=%lf\n",tsnow.tv_sec,tsnow.tv_nsec/1000000.);
        if(time_now/1000000.0 > 120.0) break;

    } // while(1)

    //end*************************************************************
    DA_data[0] = 0.0;
    DA_data[1] = 0.0;
    DA_data[2] = 0.0;

    shmguest.shm_DA_1[0] = DA_data[0];
    shmguest.shm_DA_2[0] = DA_data[1];
    shmguest.shm_DA_3[0] = DA_data[2];

  return 0;

}


space_robot::~space_robot(){

    std::cout << "stop" << '\n';

    return;
}
