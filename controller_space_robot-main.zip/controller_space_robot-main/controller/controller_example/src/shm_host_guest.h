#ifndef SHM_HOST_GUEST_H
#define SHM_HOST_GUEST_H


#include <iostream>
#include <string>
#include <sys/shm.h>
#include <sys/stat.h>
#include <sys/ipc.h>
#include <string.h>


const int id_loop_count = 11;
const int id_ENC_1 = 51, id_DA_1 = 41;
const int id_ENC_2 = 52, id_DA_2 = 42;
const int id_ENC_3 = 53, id_DA_3 = 43;

const std::string file_name_loop_count = "loop_count.dat";
const std::string file_name_ENC_1 = "arm_LS_ENC.dat";
const std::string file_name_DA_1  = "arm_LS_DA.dat";
const std::string file_name_ENC_2 = "arm_LE_ENC.dat";
const std::string file_name_DA_2  = "arm_LE_DA.dat";
const std::string file_name_ENC_3 = "arm_LW_ENC.dat";
const std::string file_name_DA_3  = "arm_LW_DA.dat";


class shm_host{

private:
    int seg_id_loop_count;
    int seg_id_ENC_1, seg_id_DA_1;
    int seg_id_ENC_2, seg_id_DA_2;
    int seg_id_ENC_3, seg_id_DA_3;
public:
    double* shm_loop_count;
    double* shm_ENC_1;
    double* shm_ENC_2;
    double* shm_ENC_3;
    double* shm_DA_1;
    double* shm_DA_2;
    double* shm_DA_3;

    shm_host(){

        const char *home_path = std::getenv("HOME");
        std::string home_path_s = &home_path[0];

        const std::string file_path_loop_count = home_path_s + "/" + file_name_loop_count;
        const std::string file_path_ENC_1 = home_path_s + "/" + file_name_ENC_1;
        const std::string file_path_DA_1  = home_path_s + "/" + file_name_DA_1;
        const std::string file_path_ENC_2 = home_path_s + "/" + file_name_ENC_2;
        const std::string file_path_DA_2  = home_path_s + "/" + file_name_DA_2;
        const std::string file_path_ENC_3 = home_path_s + "/" + file_name_ENC_3;
        const std::string file_path_DA_3  = home_path_s + "/" + file_name_DA_3;

        FILE *fp;
        key_t key_loop_count;
        key_t key_ENC_1, key_DA_1;
        key_t key_ENC_2, key_DA_2;
        key_t key_ENC_3, key_DA_3;


        fp = fopen(file_path_loop_count.c_str(), "w");
        fclose(fp);
        key_loop_count = ftok(file_path_loop_count.c_str(), id_loop_count);
        if(key_loop_count == -1){
            std::cerr << "Failed to acquire key loop" << std::endl;
        }

        seg_id_loop_count = shmget(key_loop_count, 5*sizeof(double), 
                                   IPC_CREAT | IPC_EXCL | S_IRUSR | S_IWUSR);
        if(seg_id_loop_count == -1){
            std::cerr << "Failed to acquire segment loop" << std::endl;
        }

        shmdt(shm_loop_count);
        shm_loop_count = (double*)(shmat(seg_id_loop_count, 0, 0));
        shm_loop_count[0] = 0;


        // CH1 --------------------------------------------------------
        fp = fopen(file_path_ENC_1.c_str(), "w");
        fclose(fp);
        fp = fopen(file_path_DA_1.c_str(), "w");
        fclose(fp);
        key_ENC_1 = ftok(file_path_ENC_1.c_str(), id_ENC_1);
        key_DA_1  = ftok(file_path_DA_1.c_str(),  id_DA_1);
        if(key_ENC_1 == -1 && key_DA_1 == -1){
            std::cerr << "Failed to acquire key_1" << std::endl;
        }

        seg_id_ENC_1 = shmget(key_ENC_1, 5*sizeof(double), IPC_CREAT | IPC_EXCL | S_IRUSR | S_IWUSR);
        seg_id_DA_1  = shmget(key_DA_1,  5*sizeof(double), IPC_CREAT | IPC_EXCL | S_IRUSR | S_IWUSR);
        if(seg_id_ENC_1 == -1 && seg_id_DA_1 == -1){
            std::cerr << "Failed to acquire segment_1" << std::endl;
        }

        shmdt(shm_ENC_1);
        shmdt(shm_DA_1);
        shm_ENC_1 = (double*)(shmat(seg_id_ENC_1, 0, 0));
        shm_DA_1  = (double*)(shmat(seg_id_DA_1, 0, 0));
        shm_ENC_1[0] = 11.11;
        shm_DA_1[0]  = 0.0;

        // CH2 
        fp = fopen(file_path_ENC_2.c_str(), "w");
        fclose(fp);
        fp = fopen(file_path_DA_2.c_str(), "w");
        fclose(fp);
        key_ENC_2 = ftok(file_path_ENC_2.c_str(), id_ENC_2);
        key_DA_2  = ftok(file_path_DA_2.c_str(),  id_DA_2);
        if(key_ENC_2 == -1 && key_DA_2 == -1){
            std::cerr << "Failed to acquire key_2" << std::endl;
        }

        seg_id_ENC_2 = shmget(key_ENC_2, 5*sizeof(double), IPC_CREAT | IPC_EXCL | S_IRUSR | S_IWUSR);
        seg_id_DA_2  = shmget(key_DA_2,  5*sizeof(double), IPC_CREAT | IPC_EXCL | S_IRUSR | S_IWUSR);
        if(seg_id_ENC_2 == -1 && seg_id_DA_2 == -1){
            std::cerr << "Failed to acquire segment_2" << std::endl;
        }

        shmdt(shm_ENC_2);
        shmdt(shm_DA_2);
        shm_ENC_2 = (double*)(shmat(seg_id_ENC_2, 0, 0));
        shm_DA_2  = (double*)(shmat(seg_id_DA_2, 0, 0));
        shm_ENC_2[0] = 11.11;
        shm_DA_2[0]  = 0.0;

        // CH3 
        fp = fopen(file_path_ENC_3.c_str(), "w");
        fclose(fp);
        fp = fopen(file_path_DA_3.c_str(), "w");
        fclose(fp);
        key_ENC_3 = ftok(file_path_ENC_3.c_str(), id_ENC_3);
        key_DA_3  = ftok(file_path_DA_3.c_str(),  id_DA_3);
        if(key_ENC_3 == -1 && key_DA_3 == -1){
            std::cerr << "Failed to acquire key_3" << std::endl;
        }

        seg_id_ENC_3 = shmget(key_ENC_3, 5*sizeof(double), IPC_CREAT | IPC_EXCL | S_IRUSR | S_IWUSR);
        seg_id_DA_3  = shmget(key_DA_3,  5*sizeof(double), IPC_CREAT | IPC_EXCL | S_IRUSR | S_IWUSR);
        if(seg_id_ENC_3 == -1 && seg_id_DA_3 == -1){
            std::cerr << "Failed to acquire segment_3" << std::endl;
        }
        shmdt(shm_ENC_3);
        shmdt(shm_DA_3);
        shm_ENC_3 = (double*)(shmat(seg_id_ENC_3, 0, 0));
        shm_DA_3  = (double*)(shmat(seg_id_DA_3, 0, 0));
        shm_ENC_3[0] = 11.11;
        shm_DA_3[0]  = 0.0;

        printf("shm host constructor");
    }
    

    ~shm_host(){
        shmdt(shm_loop_count);
        shmdt(shm_DA_1);
        shmdt(shm_ENC_1);
        shmdt(shm_DA_2);
        shmdt(shm_ENC_2);
        shmdt(shm_DA_3);
        shmdt(shm_ENC_3); 

        shmctl(seg_id_loop_count, IPC_RMID, NULL);
        shmctl(seg_id_DA_1,  IPC_RMID, NULL);
        shmctl(seg_id_ENC_1, IPC_RMID, NULL);
        shmctl(seg_id_DA_2,  IPC_RMID, NULL);
        shmctl(seg_id_ENC_2, IPC_RMID, NULL);
        shmctl(seg_id_DA_3,  IPC_RMID, NULL);
        shmctl(seg_id_ENC_3, IPC_RMID, NULL);
        printf("shm host destructor");
    }
};


class shm_guest{

private:
    int seg_id_loop_count;
    int seg_id_ENC_1, seg_id_DA_1;
    int seg_id_ENC_2, seg_id_DA_2;
    int seg_id_ENC_3, seg_id_DA_3;
public:
    double* shm_loop_count;
    double* shm_ENC_1;
    double* shm_ENC_2;
    double* shm_ENC_3;
    double* shm_DA_1;
    double* shm_DA_2;
    double* shm_DA_3;

    shm_guest(){
        const char *home_path = std::getenv("HOME");
        std::string home_path_s = &home_path[0];
        const std::string file_path_loop_count = home_path_s + "/" + file_name_loop_count;
        const std::string file_path_ENC_1 = home_path_s + "/" + file_name_ENC_1;
        const std::string file_path_DA_1  = home_path_s + "/" + file_name_DA_1;
        const std::string file_path_ENC_2 = home_path_s + "/" + file_name_ENC_2;
        const std::string file_path_DA_2  = home_path_s + "/" + file_name_DA_2;
        const std::string file_path_ENC_3 = home_path_s + "/" + file_name_ENC_3;
        const std::string file_path_DA_3  = home_path_s + "/" + file_name_DA_3;

        const key_t key_loop_count = ftok(file_path_loop_count.c_str(), id_loop_count);
        const int seg_id_loop_count = shmget(key_loop_count, 0, 0);

        const key_t key_ENC_1 = ftok(file_path_ENC_1.c_str(), id_ENC_1);
        const int seg_id_ENC_1 = shmget(key_ENC_1, 0, 0);
        const key_t key_DA_1 = ftok(file_path_DA_1.c_str(), id_DA_1);
        const int seg_id_DA_1 = shmget(key_DA_1, 0, 0);

        const key_t key_ENC_2 = ftok(file_path_ENC_2.c_str(), id_ENC_2);
        const int seg_id_ENC_2 = shmget(key_ENC_2, 0, 0);
        const key_t key_DA_2 = ftok(file_path_DA_2.c_str(), id_DA_2);
        const int seg_id_DA_2 = shmget(key_DA_2, 0, 0);

        const key_t key_ENC_3 = ftok(file_path_ENC_3.c_str(), id_ENC_3);
        const int seg_id_ENC_3 = shmget(key_ENC_3, 0, 0);
        const key_t key_DA_3 = ftok(file_path_DA_3.c_str(), id_DA_3);
        const int seg_id_DA_3 = shmget(key_DA_3, 0, 0);


        if(seg_id_loop_count == -1){
            std::cerr << "Failed to acquire segment" << std::endl;
        }
        if(seg_id_DA_1 == -1 || seg_id_ENC_1 == -1){
            std::cerr << "Failed to acquire segment_1" << std::endl;
        }
        if(seg_id_DA_2 == -1 || seg_id_ENC_2 == -1){
            std::cerr << "Failed to acquire segment_2" << std::endl;
        }
        if(seg_id_DA_3 == -1 || seg_id_ENC_3 == -1){
            std::cerr << "Failed to acquire segment_3" << std::endl;
        }

        shm_loop_count = (double*)(shmat(seg_id_loop_count, 0, 0));
        shm_ENC_1 = (double*)(shmat(seg_id_ENC_1, 0, 0));
        shm_DA_1  = (double*)(shmat(seg_id_DA_1, 0, 0));
        shm_ENC_2  = (double*)(shmat(seg_id_ENC_2, 0, 0));
        shm_DA_2  = (double*)(shmat(seg_id_DA_2, 0, 0));
        shm_ENC_3  = (double*)(shmat(seg_id_ENC_3, 0, 0));
        shm_DA_3  = (double*)(shmat(seg_id_DA_3, 0, 0));
    }


};

#endif
