#include "../definition_const_data.h"
#include "controller_arm.h"

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <cmath>


controller_arm::controller_arm(std::vector<double> given_theta){

    printf("arm constructor\n");

    theta = given_theta;
    theta_old = theta;
    target_theta = theta;

    dtheta.assign(3,0.0);
    dtheta_old.assign(3,0.0);

    torque.assign(3,0.0);

    time_sec = 0.0;
}



void controller_arm::read_data(std::vector<double> given_theta, double time_now){

    time_sec = time_now; //[sec]
    theta_old = theta;   //[rad]
    theta = given_theta;
    dtheta_old = dtheta; //[rad/s]
    for (int i = 0; i < 3; i++) dtheta[i] = (theta[i] - theta_old[i])/time_duration;

    return;
}


std::vector<double> controller_arm::write_data(){

  return torque;
}




controller_arm::~controller_arm(){

  return;
}
