#include <iostream>
#include "space_robot.h"

int main(){ 

    space_robot A;

    return 0;
}
