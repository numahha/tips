#ifndef SPACE_ROBOT_LEFT_ARM_CONTROLLER_H
#define SPACE_ROBOT_LEFT_ARM_CONTROLLER_H

#include<iostream>
#include<string>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<vector>
#include<cmath>

#include "./src/controller_arm.h"

class controller_left_arm : public controller_arm{

private:
    double K_p_0 = 1.0; //[N*m / rad]
    double K_p_1 = 1.0;
    double K_p_2 = 1.0;
    double K_d_0 = 1.0; //[N*m / (rad/s)]
    double K_d_1 = 1.0;
    double K_d_2 = 1.0;
public:
    controller_left_arm(std::vector<double> given_theta);
    void controller_pid();
    void main_controller();
    ~controller_left_arm();
};


inline controller_left_arm::controller_left_arm(std::vector<double> given_theta) : controller_arm(given_theta){
     return;
}




inline void controller_left_arm::main_controller(){

    //controller_pid();

    if(time_sec <= 10){ //[sec]
        target_theta[0] = 10.0/180.0*3.141592;
        target_theta[1] = -10.0/180.0*3.141592;
        target_theta[2] = 10.0/180.0*3.141592;
        //あとで考える
    }
    else if(time_sec <= 20){
        target_theta[0] = 0.0;
        target_theta[1] = 0.0;
        target_theta[2] = 0.0;
    }
    else if(time_sec <= 30){ //[sec]
        target_theta[0] = 10.0/180.0*3.141592;
        target_theta[1] = -10.0/180.0*3.141592;
        target_theta[2] = 10.0/180.0*3.141592;
    }
    else if(time_sec <= 40){
        target_theta[0] = 0.0;
        target_theta[1] = 0.0;
        target_theta[2] = 0.0;
    }
    else if(time_sec <= 50){ //[sec]
        target_theta[0] = 10.0/180.0*3.141592;
        target_theta[1] = -10.0/180.0*3.141592;
        target_theta[2] = 10.0/180.0*3.141592;
    }
    else{
        target_theta[0] = 0.0;
        target_theta[1] = 0.0;
        target_theta[2] = 0.0;
    }

    torque[0] = (target_theta[0] - theta[0])*K_p_0 + (-dtheta[0])*K_d_0;
    torque[1] = (target_theta[1] - theta[1])*K_p_1 + (-dtheta[1])*K_d_1;
    torque[2] = (target_theta[2] - theta[2])*K_p_2 + (-dtheta[2])*K_d_2;

    //printf("%7.5lf %10.5lf %10.5lf %10.5lf\n", time_sec, -dtheta[0],-dtheta[1],-dtheta[2]);

    return;
}


inline controller_left_arm::~controller_left_arm(){

  return;
}


#endif
