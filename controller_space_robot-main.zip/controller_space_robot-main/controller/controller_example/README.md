# Controllerの例


## ファイル説明

コントローラーを編集
- 右手のコントローラ　controller_right_arm.h　controller_left_arm.cpp  
- 左手のコントローラ　controller_left_arm.h    controller_right_arm.cpp
- 定数の定義　　　　　definition_const_data.h  
./src/は触らなくていい

## PD制御の実装例

'''
void controller_left_arm::controller_pid(){




      if(time_sec <= 10){ //[sec]
          target_theta[0] = 20.0/180.0*3.141592;
          target_theta[1] = -20.0/180.0*3.141592;
          target_theta[2] = 20.0/180.0*3.141592;

      }else if(time_sec <= 20){
          target_theta[0] = 0.0;
          target_theta[1] = 0.0;
          target_theta[2] = 0.0;

      }else if(time_sec <= 30){ //[sec]
          target_theta[0] = 20.0/180.0*3.141592;
          target_theta[1] = -20.0/180.0*3.141592;
          target_theta[2] = 20.0/180.0*3.141592;

      }else if(time_sec <= 40){
          target_theta[0] = 0.0;
          target_theta[1] = 0.0;
          target_theta[2] = 0.0;

      }else if(time_sec <= 50){ //[sec]
          target_theta[0] = 20.0/180.0*3.141592;
          target_theta[1] = -20.0/180.0*3.141592;
          target_theta[2] = 20.0/180.0*3.141592;

      }else{
          target_theta[0] = 0.0;
          target_theta[1] = 0.0;
          target_theta[2] = 0.0;

      }




      torque[0] = (target_theta[0] - theta[0])*K_p_0 + (-dtheta[0])*K_d_0;
      torque[1] = (target_theta[1] - theta[1])*K_p_1 + (-dtheta[1])*K_d_1;
      torque[2] = (target_theta[2] - theta[2])*K_p_2 + (-dtheta[2])*K_d_2;




    return;
}

'''


## 起動方法

1. 実機／シミュレータを立ち上げて繋ぐ。
space_robot_hardware/space_robot_simulatorを参照。

2.  このプログラムをコンパイルand実行

'''
$ make clean
$ make
$ ./main
'''

