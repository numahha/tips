#ifndef _INC_MATRIX_VECTOR_OPERATION
#define _INC_MATRIX_VECTOR_OPERATION

#include "general_type.h"

void showMatrix3x3(  char matrixNameToDisplay_input[20] ,TypedefMatrix3x3 matrix_input );
void showVector3(  char vectorNameToDisplay_input[20] ,TypedefVector3 vector_input );
void copyMatrix3x3( TypedefMatrix3x3 matrix_input, TypedefMatrix3x3 matrix_output );
void copyVector3( TypedefVector3 vector_input, TypedefVector3 vector_output );
void getZeroVector3( TypedefVector3 vector_output );
void getZeroMatrix3x3( TypedefMatrix3x3 matrix_output );
void getIdentityMatrix3x3( TypedefMatrix3x3 matrix_output );
void addMatrix3x3(  TypedefMatrix3x3 matrix1_input ,  TypedefMatrix3x3 matrix2_input , TypedefMatrix3x3 matrix_output );
void subtractMatrix3x3(  TypedefMatrix3x3 matrix1_input ,  TypedefMatrix3x3 matrix2_input , TypedefMatrix3x3 matrix_output );
void multiplyMatrix3x3(  TypedefMatrix3x3 matrix1_input ,  TypedefMatrix3x3 matrix2_input , TypedefMatrix3x3 matrix_output );
void transposeMatrix3x3(  TypedefMatrix3x3 matrix_input , TypedefMatrix3x3 matrix_output );
double getDeterminantOfMatrix3x3(  TypedefMatrix3x3 matrix_input );
void inverseMatrix3x3(  TypedefMatrix3x3 matrix_input , TypedefMatrix3x3 matrix_output );
void addVector3(  TypedefVector3 vector1_input ,  TypedefVector3 vector2_input , TypedefVector3 vector_output );
void subtractVector3(  TypedefVector3 vector1_input ,  TypedefVector3 vector2_input , TypedefVector3 vector_output );
double dotProductVector3(  TypedefVector3 vector1_input ,  TypedefVector3 vector2_input );
void crossProductVector3(  TypedefVector3 vector1_input,  TypedefVector3 vector2_input , TypedefVector3 vector_output );
void multiplyMatrix3x3Vector3(  TypedefMatrix3x3 matrix_input ,  TypedefVector3 vector_input , TypedefVector3 vector_output );
void getDiagonalVector3FromMatrix3x3( TypedefMatrix3x3 matrix_input, TypedefVector3 vector_output );
void exteriorProductMatrix3x3FromVector3(  TypedefVector3 vector_input, TypedefMatrix3x3 matrix_output );
double getEuclideanNormOfVector3( TypedefVector3 vector_input );
void getRotationMatrixAround_X_axisFromAngle( double angle_input, TypedefMatrix3x3 rotationMatrix_output );
void getRotationMatrixAround_Y_axisFromAngle( double angle_input, TypedefMatrix3x3 rotationMatrix_output );
void getRotationMatrixAround_Z_axisFromAngle( double angle_input, TypedefMatrix3x3 rotationMatrix_output );
void getRotationEulerMatrixFromAngleVector( char rotateMode_input[3], TypedefVector3 angleVector_input, TypedefMatrix3x3 rotationMatrix_output );


#endif
