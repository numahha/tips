#ifndef _INC_SPLINE
#define _INC_SPLINE	

#define SPLINESTRUCT_COEFFICIENT_SIZE 6
#include <math.h>
#include "general_type.h"

struct SplineStruct1Dimension
{
	//--------------- public variable ----------------
    	// -------------initial value -----------------

		// initial time
    	double t_s;

		// initial data, derivative of data and the second derivative of data
    	double x_s;
    	double dx_s;
    	double ddx_s;

    	// ---------------final value ---------------------
		// final time
    	double t_f;

		// final data, derivative of data and the second derivative of data
    	double x_f;
    	double dx_f;
    	double ddx_f; 
	
	//--------------- private variable ----------------
    // coefficient
    double coefficient[SPLINESTRUCT_COEFFICIENT_SIZE];

};

struct SplineStructVector3
{
	//--------------- public variable ----------------
    	// -------------initial value -----------------

		// initial time
    	double t_s;

		// initial data, derivative of data and the second derivative of data
    	TypedefVector3 x_s;
    	TypedefVector3 dx_s;
    	TypedefVector3 ddx_s;

    	// ---------------final value ---------------------
		// final time
    	double t_f;

		// final data, derivative of data and the second derivative of data
    	TypedefVector3 x_f;
    	TypedefVector3 dx_f;
    	TypedefVector3 ddx_f; 
		
    //--------------- private variable ----------------
    // coefficient
    struct SplineStruct1Dimension splineStruct1Dimension[3];

};

void initial1DimensionSpline( struct SplineStruct1Dimension *splineStruct_return );
void get1DimensionSplineData( struct SplineStruct1Dimension *splineStruct_input , double time_input, double *splineData_output );
void get1DimensionSplineDataDot( struct SplineStruct1Dimension *splineStruct_input , double time_input, double *splineDataDot_output );						  
void get1DimensionSplineDataDotDot( struct SplineStruct1Dimension *splineStruct_input , double time_input, double *splineDataDotDot_output );
void get1DimensionSplineDataDotDotDot( struct SplineStruct1Dimension *splineStruct_input , double time_input, double *splineDataDotDotDot_output );

void initialVector3Spline( struct SplineStructVector3 *splineStruct_return );
void getVector3SplineData( struct SplineStructVector3 *splineStruct_input , double time_input, TypedefVector3 splineData_output ); 
void getVector3SplineDataDot( struct SplineStructVector3 *splineStruct_input , double time_input, TypedefVector3 splineDataDot_output ); 
void getVector3SplineDataDotDot( struct SplineStructVector3 *splineStruct_input , double time_input, TypedefVector3 splineDataDotDot_output );						 
void getVector3SplineDataDotDotDot( struct SplineStructVector3 *splineStruct_input , double time_input, TypedefVector3 splineDataDotDotDot_output );

#endif


