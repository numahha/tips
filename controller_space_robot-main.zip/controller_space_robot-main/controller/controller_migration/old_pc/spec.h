/*  FILE NAME [spec.h]
 *
 *  This file is based on [specForSlave.h], which is under three directries
 *  	
 *  	/home/vxworks/vw/usr/junya/dsp/Slave/common ,
 *      /c/program/robot/matsuyama/common
 *  	and /c/program/robot/takata/common
 *
 *  	on SUN sparc 10.
 *  
 *  This header file is programmed for the Robot Manipulator.
 *
 *  ch1 -> Shoulder of Left Arm:   
 *  ch2 ->    Elbow of Left Arm:   
 *  ch3 ->    Wrist of Left Arm:   
 *  ch4 -> Shoulder of Right Arm:  
 *  ch5 ->    Elbow of Right Arm:  
 *  ch6 ->    Wrist of Right Arm:  
 *  ch7 ->   Finger of Right Arm:
 *         
 *  Arranged by Takayuki Kondo
 *  Feb.6th 2006
 */

//----------------begin 2006/07/07 modified by Takayuki Kondo----------------
//	1. Link lengths.
//		1.1 I changed the names L1, L2, L3 to L11, L12, L13 for left links.
//		1.2 I added new names L21, L22, L23 for right links.
//
//----------------end 2006/07/07 modified by Takayuki Kondo----------------

//----------------begin 2006/09/20 modified by Takayuki Kondo----------------
//	1. DA channel
//		DA_CHANNEL1 to DA_CHANNEL16 correspond to channel 0 to 15 of DA.
//	2. Encoder Counter channel
//		CNT_CHANNEL1 to CNT_CHANNEL16 correspond to channel 0 to 15 of Encoder counter.
//
//----------------end 2006/09/20 modified by Takayuki Kondo----------------

//----------------begin 2006/10/03 modified by Takayuki Kondo----------------
//	1. AD channel
//		AD_CHANNEL1 to AD_CHANNEL16 correspond to channel 0 to 15 of AD.
//
//----------------end 2006/10/03 modified by Takayuki Kondo----------------

//----------------begin 2007/09/28 modified by Takayuki Kondo---------------------
//	1. I changed some names of variables.
//		1. L11, L12, L13 ---> L21, L21, L23   (L11, L12, L13 will be used for right arm, L21, L21, L23 for left)
//
//----------------end 2007/09/28 modified by Takayuki Kondo---------------------


#if	!defined(__SPEC_H)
#define	__SPEC_H

#define  PI        	3.14159265358979  /* M_PI : defined in <math.h>*/
#define  LARGE_ENOUGH	(M_PI/4)
#define  halfPI    	1.5708
#define  LINK_NUM  	3 /* the number of links on one Arm.  */
#define  ARM_NUM   	1 /* the number of Arms on Robot Manipulator. */
#define  JOINT_NUM	(ARM_NUM * LINK_NUM) /* the number of joints on dual arms. */
/* 
 * #define  CAM_NUM   	2
 */
#define  CH_NUM    	(ARM_NUM * LINK_NUM) /* the number of channels. */
#define  CNT_NUM   	(ARM_NUM * LINK_NUM) /* the number of channels for encoder part on PCI board. */
#define  DA_NUM    	(ARM_NUM * LINK_NUM) /* the number of channels for DA part on PCI board. */
#define  AD_NUM    	(ARM_NUM * LINK_NUM) /* the number of channels for AD part on PCI board. */
/*
 * #define  UNIT_NUM  	4
 */
#define  R_NUM     	3   /* the  number of position orientaion variable */


	/* Angle[rad], [deg] */
#define  RAD_TO_DEG   	(180.0 / PI) /* radian to degree */
#define  DEG_TO_RAD   	(PI / 180.0) /* degree to radian */

	/*  Mass [kg]  */
#define  m1        2.9609
#define  m2        2.2507
#define  m3        1.3873
#define  m4        1.950

	/*  Inertia moment [kg-m^2]  */
#define  I1        0.14336
#define  I2        0.067405
#define  I3        0.003262
#define  I4        0.0196

//--------begin modified by Takayuki Kondo 07/10/12-------------------
//--------begin deleted by Takayuki Kondo 07/10/12--------------------
	/*  Length [m]  */
//right manipulator on the space robot
//#define  L11        0.320
//#define  L12        0.260
//#define  L13        0.118

//left maniulator on the space robot
//#define  L21        0.320
//#define  L22        0.260
//#define  L23        0.118
//--------end deleted by Takayuki Kondo 07/10/12----------------------

	/*  Length [m]  */
//right manipulator on the space robot
#define  L11        0.322
#define  L12        0.262
#define  L13        0.119

//left maniulator on the space robot
#define  L21        0.322
#define  L22        0.262
#define  L23        0.119
//--------end modidfied by Takayuki Kondo 07/10/12--------------------

#define  L4        0.150	/*  half length of truss member  */
#define  SHOULDER_WIDTH  0.440

	/*  Center of Mass [m]  */
#define  Lg1x      0.1822
#define  Lg1y      0.0
#define  Lg2x      0.1316
#define  Lg2y      0.0
#define  Lg3x      0.0310
#define  Lg3y      0.0
#define  Lg4x      0.0
#define  Lg4y      0.0

	/*  Memory Board Adress  */
/*
#define  MEMBD_ADR        0x10000000
#define  MEMBD_ADR_ROBOT  0x10100000
#define  MEMBD_ADR_END    0x11000000
#define  MEMBD_ADR1       0x10100000
#define  MEMBD_ADR2       0x10200000
#define  MEMBD_ADR3       0x10300000
#define  MEMBD_ADR4       0x10400000
#define  MEMBD_ADR5       0x10500000
#define  MEMBD_ADR6       0x10600000
#define  MEMBD_ADR7       0x10700000
#define  MEMBD_ADR8       0x10800000
#define  MEMBD_ADR9       0x10900000
 */

	/* Sampling Time */
#define  SAMPLING_TIME                  0.001 /* [s] */
/* #define  SAMPLING_TIME_IN_IMAGE_PLANE   0.033 */

//------- begin added by Kohei Okamoto 08/01/11 -----------------
#define  UPDATE_RATE			0.001 /* [s] */ 
#define  BODY_SAMPLING_TIME		0.087 /* [s] */ 

#define  VISION_TIME_RATE		0.1105 /* [s] */ 
//------- end added by Kohei Okamoto 08/01/11 -------------------


	/* encoder counter resolution */
#define	 ENC_RES	1000.0	// encoder resolution is 1000.0.
#define  RED_GEAR_RAT	100.0	// reduction gear ratio is 100.0.
#define  MUL_ENC_RES	4.0	// multiplication of encoder resolution is 4.0.
#define	 CNT_RES	(ENC_RES * RED_GEAR_RAT * MUL_ENC_RES) // counter resolution is 400000.0.
#define  CNT_TO_RAD 	(2.0 * PI / CNT_RES)  // used to convert encoder count into angle of joints(radian). encoder resolution is 1000.0, reduction gear ratio is 100.0 and multiplication of encoder resolution is 4.0. Then actuator creates 400000 pulses per revolution.


#define CNT_CHANNEL1	0
#define CNT_CHANNEL2	1
#define CNT_CHANNEL3	2
#define CNT_CHANNEL4	3
#define CNT_CHANNEL5	4
#define CNT_CHANNEL6	5
#define CNT_CHANNEL7	6
#define CNT_CHANNEL8	7
#define CNT_CHANNEL9	8
#define CNT_CHANNEL10	9
#define CNT_CHANNEL11	10
#define CNT_CHANNEL12	11
#define CNT_CHANNEL13	12
#define CNT_CHANNEL14	13
#define CNT_CHANNEL15	14
#define CNT_CHANNEL16	15


	/* DA board & AD board. */
#define DA_VOLTAGE_MAX	10.0 /* maximum of DA voltage output. voltage range of DA part on PCI board is from -10V to 10V. */

#define DA_CHANNEL1	0
#define DA_CHANNEL2	1
#define DA_CHANNEL3	2
#define DA_CHANNEL4	3
#define DA_CHANNEL5	4
#define DA_CHANNEL6	5
#define DA_CHANNEL7	6
#define DA_CHANNEL8	7
#define DA_CHANNEL9	8
#define DA_CHANNEL10	9
#define DA_CHANNEL11	10
#define DA_CHANNEL12	11
#define DA_CHANNEL13	12
#define DA_CHANNEL14	13
#define DA_CHANNEL15	14
#define DA_CHANNEL16	15

#define AD_CHANNEL1	0
#define AD_CHANNEL2	1
#define AD_CHANNEL3	2
#define AD_CHANNEL4	3
#define AD_CHANNEL5	4
#define AD_CHANNEL6	5
#define AD_CHANNEL7	6
#define AD_CHANNEL8	7
#define AD_CHANNEL9	8
#define AD_CHANNEL10	9
#define AD_CHANNEL11	10
#define AD_CHANNEL12	11
#define AD_CHANNEL13	12
#define AD_CHANNEL14	13
#define AD_CHANNEL15	14
#define AD_CHANNEL16	15

	/* Torque [Nm] */
#define	 TORQUE_MAX	7.8 /* servo actuator:RH-14-3002-E100DO */ 
#define	 TORQUE_MAX2	2.3 /* servo actuator:RH-8-3006-E100DO */

#define	 TORQUE_VOLTAGE       (8.0/(0.6*9.80665)) /* constant value defined when the space robot system was designed, relating to a strain guage. convert torque into voltage. */
#define  TORQUE_VOLTAGE2      (8.0/(0.2*9.80665))


#define	 GIMBAL_ANGLE_MAX	1.35	/***** added by Kohei Okamoto 08/01/11 *****/

#endif
