#include <math.h>
#include "spec.h"
#include "structure.h"
#include "etc.h"
#include "direct_kinematics_3joints_manipulator.h"

struct TypedefLinkAngle getLinkAngleFromFile( char filename_input[50] )
{
	struct TypedefLinkAngle linkAngle_output;
	
	linkAngle_output.angle0_1[0] = 0;
	linkAngle_output.angle0_1[1] = 0;
	linkAngle_output.angle0_1[2] = 0;
	
	linkAngle_output.angle1_2[0] = 0;
	linkAngle_output.angle1_2[1] = 0;
	linkAngle_output.angle1_2[2] = 0;
	
	linkAngle_output.angle2_3[0] = 0;
	linkAngle_output.angle2_3[1] = 0;
	linkAngle_output.angle2_3[2] = 0;
	
	linkAngle_output.angle3_E[0] = 0;
	linkAngle_output.angle3_E[1] = 0;
	linkAngle_output.angle3_E[2] = 0;

	return linkAngle_output;
}

struct TypedefRotatingMatrix3x3 getRotatingMatricesLinkAngle( struct TypedefLinkAngle linkAngle_input, 
                                                              struct TypedefRotatingMatrix3x3 rotatingMatrix_return )
{
	getRotationEulerMatrixFromAngleVector( "zyx", linkAngle_input.angle0_1, rotatingMatrix_return.R0_1Link );
	getRotationEulerMatrixFromAngleVector( "zyx", linkAngle_input.angle1_2, rotatingMatrix_return.R1_2Link );
	getRotationEulerMatrixFromAngleVector( "zyx", linkAngle_input.angle2_3, rotatingMatrix_return.R2_3Link );
	getRotationEulerMatrixFromAngleVector( "zyx", linkAngle_input.angle3_E, rotatingMatrix_return.R3_ELink );
	return rotatingMatrix_return;
}

struct TypedefRotatingMatrix3x3 getRotatingMatrices( TypedefVector3 theta_input, struct TypedefRotatingMatrix3x3 rotatingMatrix_return )
{
	getRotationMatrixAround_Z_axisFromAngle( theta_input[0], rotatingMatrix_return.R0_1JointAngle );
	getRotationMatrixAround_Z_axisFromAngle( theta_input[1], rotatingMatrix_return.R1_2JointAngle );
	getRotationMatrixAround_Z_axisFromAngle( theta_input[2], rotatingMatrix_return.R2_3JointAngle );
	getRotationMatrixAround_Z_axisFromAngle( 	      0, rotatingMatrix_return.R3_EJointAngle );

	multiplyMatrix3x3( rotatingMatrix_return.R0_1Link, rotatingMatrix_return.R0_1JointAngle, rotatingMatrix_return.R0_1  );
	multiplyMatrix3x3( rotatingMatrix_return.R1_2Link, rotatingMatrix_return.R1_2JointAngle, rotatingMatrix_return.R1_2  );
	multiplyMatrix3x3( rotatingMatrix_return.R2_3Link, rotatingMatrix_return.R2_3JointAngle, rotatingMatrix_return.R2_3  );
	multiplyMatrix3x3( rotatingMatrix_return.R3_ELink, rotatingMatrix_return.R3_EJointAngle, rotatingMatrix_return.R3_E  );

	multiplyMatrix3x3( rotatingMatrix_return.R0_1, rotatingMatrix_return.R1_2, rotatingMatrix_return.R0_2 );
	multiplyMatrix3x3( rotatingMatrix_return.R0_2, rotatingMatrix_return.R2_3, rotatingMatrix_return.R0_3 );
	multiplyMatrix3x3( rotatingMatrix_return.R0_3, rotatingMatrix_return.R3_E, rotatingMatrix_return.R0_E );
	
	return rotatingMatrix_return;
}



struct TypedefTranslationVector3 getTranslationVectorsFromFile( char filename_input[50] )
{
	struct TypedefTranslationVector3 translationVector_return;

	translationVector_return.p0_1_0[0] = 0;
	translationVector_return.p0_1_0[1] = SHOULDER_WIDTH;
	translationVector_return.p0_1_0[2] = 0;

	translationVector_return.p1_2_1[0] = L21;
	translationVector_return.p1_2_1[1] = 0;
	translationVector_return.p1_2_1[2] = 0;

	translationVector_return.p2_3_2[0] = L22;
	translationVector_return.p2_3_2[1] = 0;
	translationVector_return.p2_3_2[2] = 0;

	translationVector_return.p3_E_3[0] = L23;
	translationVector_return.p3_E_3[1] = 0;
	translationVector_return.p3_E_3[2] = 0;

	return translationVector_return;
}


struct TypedefTranslationVector3 getTranslationVectors( struct TypedefRotatingMatrix3x3 rotatingMatrix_input, 
                                                        struct TypedefTranslationVector3 translationVector_return )
{	
	multiplyMatrix3x3Vector3( rotatingMatrix_input.R0_1, translationVector_return.p1_2_1, translationVector_return.p0_2_1 );
	multiplyMatrix3x3Vector3( rotatingMatrix_input.R0_2, translationVector_return.p2_3_2, translationVector_return.p0_3_2 );
	multiplyMatrix3x3Vector3( rotatingMatrix_input.R0_3, translationVector_return.p3_E_3, translationVector_return.p0_E_3 ); 

	addVector3( translationVector_return.p0_1_0, translationVector_return.p0_2_1, translationVector_return.p0_2_0 );
	addVector3( translationVector_return.p0_2_0, translationVector_return.p0_3_2,	translationVector_return.p0_3_0 );
	addVector3( translationVector_return.p0_3_0, translationVector_return.p0_E_3,	translationVector_return.p0_E_0 );
	
	subtractVector3( translationVector_return.p0_E_0, translationVector_return.p0_1_0, translationVector_return.p0_E_1 );
	subtractVector3( translationVector_return.p0_E_0, translationVector_return.p0_2_0, translationVector_return.p0_E_2 );

	return translationVector_return;
}

void directKinematics3JointsManipulator(struct TypedefManipulator *manipulator2)
{
	//----------------------------------------------------------
	// 1 only once at first ------------------------------------
	//----------------------------------------------------------

		//1.1.1) read constant angles defined by links
		//    2) read constant translation vectors defined by link parameters
		manipulator2->linkAngle         = getLinkAngleFromFile("abcdefg");
		manipulator2->translationVector = getTranslationVectorsFromFile( "hijklmn" );

		//1.2 calculate constant rotating matrices with angles defined by links
		manipulator2->rotatingMatrix = getRotatingMatricesLinkAngle( manipulator2->linkAngle, manipulator2->rotatingMatrix );


	//------------------------------------------------------
	// 3 should be calculated every sampling time ----------
	//------------------------------------------------------
		//2.1.1) calculate rotating matrices
		//    2) calculate translation vectors relative to the coordinate_0
		manipulator2->rotatingMatrix    = getRotatingMatrices( manipulator2->joint.theta, manipulator2->rotatingMatrix );
		manipulator2->translationVector = getTranslationVectors( manipulator2->rotatingMatrix, manipulator2->translationVector );

		//2.2 calculate transposed jacobian matrix
		  getTransposedJacobian(manipulator2->joint.theta, L21, L22, L23, manipulator2->transposedJacobianMatrix );

		//2.3 calculate manipulation variables
		manipulator2->manipulationVariable.y[0] = manipulator2->translationVector.p0_E_0[0];
		manipulator2->manipulationVariable.y[1] = manipulator2->translationVector.p0_E_0[1];
		manipulator2->manipulationVariable.y[2] = manipulator2->joint.theta[0] + manipulator2->joint.theta[1] + manipulator2->joint.theta[2];

}
