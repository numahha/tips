#ifndef _INC_ETC
#define _INC_ETC

void getDividedDifference( double function1_input , double function2_input , double x1_input , double x2_input , double *difference_return );
void getJointAngularVelocity( TypedefVector3 theta_input , TypedefVector3 theta_previous_input , double samplingTime_input , TypedefVector3 dTheta_output );
void getManipulationVariableVelocity( TypedefVector3 y_input , TypedefVector3 y_previous_input , double samplingTime_input , TypedefVector3 dY_output );
void getTransposedJacobian( TypedefVector3 theta_input, double link1_input, double link2_input, double link3_input, TypedefMatrix3x3 transposedJacobianMatrix_return );
void getInversedJacobian( TypedefVector3 theta_input, double link1_input, double link2_input, double link3_input, TypedefMatrix3x3 inversedJacobianMatrix_return );
void inverseKinematicsForLeftArm( TypedefVector3 y_input , TypedefVector3 theta_output );
void transferJointTorqueToForceAtEndEffector(TypedefVector3 torque_input, 
                                             TypedefMatrix3x3 transposedJacobianMatrix_input, 
                                             TypedefVector3 force_output);

#endif
