
#ifndef _INC_GENERAL_TYPE
#define _INC_GENERAL_TYPE

typedef double TypedefVector3[3];
typedef double TypedefMatrix3x3[3][3];

#endif
