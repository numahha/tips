#ifndef _INC_LOCALPD
#define _INC_LOCALPD

void artificialPotentialMethodVector3( TypedefMatrix3x3 proportionalGainMatrix_input, 
                                       TypedefVector3 y_input, 
                                       TypedefVector3 y_desired_input, 
                                       TypedefVector3 u_output );
void localPDControlVector3( TypedefMatrix3x3 transposedJacobianMatrix_input,
			    TypedefMatrix3x3 proportionalGainMatrix_input,
			    TypedefVector3 y_input, 
			    TypedefVector3 y_desired_input,
			    TypedefMatrix3x3 derivativeGainMatrix_input,
			    TypedefVector3 dTheta_input, 
			    TypedefVector3 torque_output );

#endif

