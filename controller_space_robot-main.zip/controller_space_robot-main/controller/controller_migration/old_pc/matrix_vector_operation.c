#include <stdio.h>
#include <math.h>
#include "matrix_vector_operation.h"

void showMatrix3x3(  char matrixNameToDisplay_input[20] ,TypedefMatrix3x3 matrix_input )
{
	int i,j;
	int size = 3;
	
	printf("----- Begin %s_Matrix ------------\n",matrixNameToDisplay_input );
	for( j = 0; j < size; j ++ )
	{
		for( i = 0; i < size; i ++ ) printf( "%f   " , matrix_input[j][i]);
		printf("\n");					
	}
	printf("----- End %s_Matrix --------------\n",matrixNameToDisplay_input );				
}


void showVector3(  char vectorNameToDisplay_input[20] , TypedefVector3 vector_input )
{
	int j;
	int size = 3;
	printf("----- Begin %s_Vector ------------\n",vectorNameToDisplay_input );
	for( j = 0; j < size; j ++ ) printf( "%f \n" , vector_input[j]);
	printf("----- End %s_Vector --------------\n",vectorNameToDisplay_input );
}




void copyMatrix3x3( TypedefMatrix3x3 matrix_input, TypedefMatrix3x3 matrix_output )
{
	int i,j;
	int size = 3;
	for( j = 0; j < size; j++ )
		for( i = 0; i < size; i++ )
		matrix_output[j][i] = matrix_input[j][i];

}


void copyVector3( TypedefVector3 vector_input, TypedefVector3 vector_output )
{
	int j;
	int size = 3;
	for( j = 0; j < size; j++ )
		vector_output[j] = vector_input[j];	
}


void getZeroVector3( TypedefVector3 vector_output )
{
	int j;
	int size = 3;
	for( j = 0; j < size; j++ )
		vector_output[j] = 0;		
}




void getZeroMatrix3x3( TypedefMatrix3x3 matrix_output )
{
	
	int i,j;
	int size = 3;
	for( j = 0; j < size; j++ )
		for( i = 0; i < size; i++ )
		matrix_output[j][i] = 0;
}



void getIdentityMatrix3x3( TypedefMatrix3x3 matrix_output )
{
	
	int i;
	int size = 3;
		
	getZeroMatrix3x3( matrix_output );		
	for( i = 0; i < size; i++ )	
		matrix_output[i][i] = 1;
}



void addMatrix3x3(  TypedefMatrix3x3 matrix1_input ,  TypedefMatrix3x3 matrix2_input , TypedefMatrix3x3 matrix_output )
{
	int i,j;
	int size = 3;

	for( j = 0; j < size; j ++ )
		for( i = 0; i < size; i ++ )		
			matrix_output[j][i] = matrix1_input[j][i] + matrix2_input[j][i];
}


void subtractMatrix3x3(  TypedefMatrix3x3 matrix1_input ,  TypedefMatrix3x3 matrix2_input , TypedefMatrix3x3 matrix_output )
{
	int i,j;
	int size = 3;	
	
	for( j = 0; j < size; j ++ )
		for( i = 0; i < size; i ++ )		
			matrix_output[j][i] = matrix1_input[j][i] - matrix2_input[j][i];
}


void multiplyMatrix3x3(  TypedefMatrix3x3 matrix1_input ,  TypedefMatrix3x3 matrix2_input , TypedefMatrix3x3 matrix_output )
{
	int h,i,j;
	int size = 3;
	
	TypedefMatrix3x3 bufferMatrix;
	double *matrix1_inputPtr;
	double *matrix2_inputPtr;
	double *matrix_outputPtr;
	
	matrix1_inputPtr = &matrix1_input[0][0];
	matrix2_inputPtr = &matrix2_input[0][0];
	matrix_outputPtr = &matrix_output[0][0];
	
	
	// check that input and output are the same or not
	if(  ( matrix1_inputPtr == matrix_outputPtr) ||  (matrix2_inputPtr == matrix_outputPtr) )
	{

		for( j = 0; j < size; j ++ )
			for( i = 0; i < size; i ++ )
			{
				bufferMatrix[j][i] = 0;			
				for( h = 0; h < size; h++ ) bufferMatrix[j][i] +=  matrix1_input[j][h]*matrix2_input[h][i]; 
			}
		
		// copy the result from buffer to output		
		for( j = 0; j < size; j ++ )
			for( i = 0; i < size; i ++ )		
				matrix_output[j][i] = bufferMatrix[j][i];
	}
	else		
	{		
		for( j = 0; j < size; j ++ )
			for( i = 0; i < size; i ++ )
			{
				matrix_output[j][i] = 0;			
				for( h = 0; h < size; h++ ) matrix_output[j][i] +=  matrix1_input[j][h]*matrix2_input[h][i]; 
			}
	}	

}


void transposeMatrix3x3(  TypedefMatrix3x3 matrix_input , TypedefMatrix3x3 matrix_output )
{
	int i,j;
	int size = 3;
		
	TypedefMatrix3x3 bufferMatrix;
	double *matrix_inputPtr;
	double *matrix_outputPtr;
	
	matrix_inputPtr = &matrix_input[0][0];
	matrix_outputPtr = &matrix_output[0][0];
		
	// check that input and output are the same variable or not
	if(  matrix_inputPtr == matrix_outputPtr )  
	{
		for( j = 0; j < size; j ++ )
			for( i = 0; i < size; i ++ )		
				bufferMatrix[j][i] = matrix_input[i][j];
		
		// copy the result from buffer to output	
		for( j = 0; j < size; j ++ )
			for( i = 0; i < size; i ++ )		
				matrix_output[j][i] = bufferMatrix[j][i];
	}
	else
	{		
		for( j = 0; j < size; j ++ )
			for( i = 0; i < size; i ++ )		
				matrix_output[j][i] = matrix_input[i][j];
	}					
}



double getDeterminantOfMatrix3x3(  TypedefMatrix3x3 matrix_input )
{
	double buffer[3];

	
	buffer[0] = matrix_input[0][0]*matrix_input[1][1]*matrix_input[2][2] - matrix_input[2][1]*matrix_input[1][2]*matrix_input[0][0];
	buffer[1] = matrix_input[0][1]*matrix_input[1][2]*matrix_input[2][0] - matrix_input[2][2]*matrix_input[1][0]*matrix_input[0][1];
	buffer[2] = matrix_input[0][2]*matrix_input[1][0]*matrix_input[2][1] - matrix_input[2][0]*matrix_input[1][1]*matrix_input[0][2];
	
	return 	buffer[0]+buffer[1]+buffer[2];

}


void inverseMatrix3x3(  TypedefMatrix3x3 matrix_input , TypedefMatrix3x3 matrix_output )
{
	int j,i;
	int size = 3;
	
	TypedefMatrix3x3 bufferMatrix;
	double *matrix_inputPtr;
	double *matrix_outputPtr;
	
	double det = getDeterminantOfMatrix3x3( matrix_input );
	
	matrix_inputPtr = &matrix_input[0][0];
	matrix_outputPtr = &matrix_output[0][0];
		
	// check that input and output are the same variable or not
	if(  matrix_inputPtr == matrix_outputPtr )  
	{
		bufferMatrix[0][0] = ( matrix_input[1][1]*matrix_input[2][2] - matrix_input[1][2]*matrix_input[2][1] )/det;
		bufferMatrix[0][1] = ( matrix_input[0][2]*matrix_input[2][1] - matrix_input[0][1]*matrix_input[2][2] )/det;		
		bufferMatrix[0][2] = ( matrix_input[0][1]*matrix_input[1][2] - matrix_input[0][2]*matrix_input[1][1] )/det;
		bufferMatrix[1][0] = ( matrix_input[1][2]*matrix_input[2][0] - matrix_input[1][0]*matrix_input[2][2] )/det;
		bufferMatrix[1][1] = ( matrix_input[0][0]*matrix_input[2][2] - matrix_input[0][2]*matrix_input[2][0] )/det;
		bufferMatrix[1][2] = ( matrix_input[0][2]*matrix_input[1][0] - matrix_input[0][0]*matrix_input[1][2] )/det;
		bufferMatrix[2][0] = ( matrix_input[1][0]*matrix_input[2][1] - matrix_input[1][1]*matrix_input[2][0] )/det;
		bufferMatrix[2][1] = ( matrix_input[0][1]*matrix_input[2][0] - matrix_input[0][0]*matrix_input[2][1] )/det;
		bufferMatrix[2][2] = ( matrix_input[0][0]*matrix_input[1][1] - matrix_input[0][1]*matrix_input[1][0] )/det;
		
		// copy the result from buffer to output	
		for( j = 0; j < size; j ++ )
			for( i = 0; i < size; i ++ )		
				matrix_output[j][i] = bufferMatrix[j][i];						
	}
	else
	{	
		matrix_output[0][0] = ( matrix_input[1][1]*matrix_input[2][2] - matrix_input[1][2]*matrix_input[2][1] )/det;
		matrix_output[0][1] = ( matrix_input[0][2]*matrix_input[2][1] - matrix_input[0][1]*matrix_input[2][2] )/det;		
		matrix_output[0][2] = ( matrix_input[0][1]*matrix_input[1][2] - matrix_input[0][2]*matrix_input[1][1] )/det;
		matrix_output[1][0] = ( matrix_input[1][2]*matrix_input[2][0] - matrix_input[1][0]*matrix_input[2][2] )/det;
		matrix_output[1][1] = ( matrix_input[0][0]*matrix_input[2][2] - matrix_input[0][2]*matrix_input[2][0] )/det;
		matrix_output[1][2] = ( matrix_input[0][2]*matrix_input[1][0] - matrix_input[0][0]*matrix_input[1][2] )/det;
		matrix_output[2][0] = ( matrix_input[1][0]*matrix_input[2][1] - matrix_input[1][1]*matrix_input[2][0] )/det;
		matrix_output[2][1] = ( matrix_input[0][1]*matrix_input[2][0] - matrix_input[0][0]*matrix_input[2][1] )/det;
		matrix_output[2][2] = ( matrix_input[0][0]*matrix_input[1][1] - matrix_input[0][1]*matrix_input[1][0] )/det;
	}

}




void addVector3(  TypedefVector3 vector1_input ,  TypedefVector3 vector2_input , TypedefVector3 vector_output )
{
	int j;
	int size = 3;
	
	for( j = 0; j < size; j ++ ) 
		vector_output[j] =  vector1_input[j] + vector2_input[j]; 
}


void subtractVector3(  TypedefVector3 vector1_input ,  TypedefVector3 vector2_input , TypedefVector3 vector_output )
{
	int j;
	int size = 3;
	
	for( j = 0; j < size; j ++ ) 
		vector_output[j] =  vector1_input[j] - vector2_input[j]; 
}


double dotProductVector3(  TypedefVector3 vector1_input ,  TypedefVector3 vector2_input )
{
	int j;
	int size = 3;
	double dotProduct_output;
	dotProduct_output = 0;
		
	for( j = 0; j < size; j ++ ) 
		dotProduct_output +=  vector1_input[j] * vector2_input[j]; 
	
	return dotProduct_output;	
}




void crossProductVector3(  TypedefVector3 vector1_input,  TypedefVector3 vector2_input , TypedefVector3 vector_output )
{
	TypedefMatrix3x3 exteriorProductMatrix;	
	exteriorProductMatrix3x3FromVector3( vector1_input , exteriorProductMatrix );	
	multiplyMatrix3x3Vector3( exteriorProductMatrix , vector2_input ,vector_output );
}




void multiplyMatrix3x3Vector3(  TypedefMatrix3x3 matrix_input ,  TypedefVector3 vector_input , TypedefVector3 vector_output )
{
	int i,j;
	int size = 3;

	TypedefVector3 bufferVector;
	
	double *vector_inputPtr;
	double *vector_outputPtr;
	
	vector_inputPtr = &vector_input[0];
	vector_outputPtr = &vector_output[0];
		
	// check that input and output are the same variable or not
	if(  vector_inputPtr == vector_outputPtr )  
	{	
		for( j = 0; j < size; j ++ )
		{
			bufferVector[j] = 0;
			for( i = 0; i < size; i ++ )		
				bufferVector[j] +=  matrix_input[j][i]*vector_input[i]; 
		}			

		
		// copy the result from buffer to output	
		for( i = 0; i < size; i ++ )		
			vector_output[i] = bufferVector[i];
	}
	else
	{	
		for( j = 0; j < size; j ++ )
		{
			vector_output[j] = 0;
			for( i = 0; i < size; i ++ )		
				vector_output[j] +=  matrix_input[j][i]*vector_input[i]; 
		}	
	
	}	
}



void getDiagonalVector3FromMatrix3x3( TypedefMatrix3x3 matrix_input, TypedefVector3 vector_output )
{
	int i;
	int size = 3;
	
	for( i = 0; i < size; i++ ) vector_output[i] = matrix_input[i][i];
	
}


void exteriorProductMatrix3x3FromVector3(  TypedefVector3 vector_input, TypedefMatrix3x3 matrix_output )
{
	matrix_output[0][0] = 0;	 				matrix_output[0][1] = -vector_input[2];			matrix_output[0][2] = vector_input[1];
	matrix_output[1][0] = vector_input[2];	 	matrix_output[1][1] = 0;						matrix_output[1][2] = -vector_input[0];
	matrix_output[2][0] = -vector_input[1];	 	matrix_output[2][1] = vector_input[0];			matrix_output[2][2] = 0;
}


double getEuclideanNormOfVector3( TypedefVector3 vector_input )
{
	double dotProduct;
	dotProduct = dotProductVector3( vector_input , vector_input );
	
	return sqrt( dotProduct );
}



void getRotationMatrixAround_X_axisFromAngle( double angle_input, TypedefMatrix3x3 rotationMatrix_output )
{
	rotationMatrix_output[0][0] = 1;		rotationMatrix_output[0][1] = 0;						rotationMatrix_output[0][2] = 0;
	rotationMatrix_output[1][0] = 0;		rotationMatrix_output[1][1] = cos(angle_input);			rotationMatrix_output[1][2] = -sin(angle_input);	
	rotationMatrix_output[2][0] = 0;		rotationMatrix_output[2][1] = sin(angle_input);			rotationMatrix_output[2][2] = cos(angle_input);	
}


void getRotationMatrixAround_Y_axisFromAngle( double angle_input, TypedefMatrix3x3 rotationMatrix_output )
{
	rotationMatrix_output[0][0] = cos(angle_input);		rotationMatrix_output[0][1] = 0;			rotationMatrix_output[0][2] = sin(angle_input);
	rotationMatrix_output[1][0] = 0;					rotationMatrix_output[1][1] = 1;			rotationMatrix_output[1][2] = 0;	
	rotationMatrix_output[2][0] = -sin(angle_input);	rotationMatrix_output[2][1] = 0;			rotationMatrix_output[2][2] = cos(angle_input);	
}

void getRotationMatrixAround_Z_axisFromAngle( double angle_input, TypedefMatrix3x3 rotationMatrix_output )
{
	rotationMatrix_output[0][0] = cos(angle_input);		rotationMatrix_output[0][1] = -sin(angle_input);		rotationMatrix_output[0][2] = 0;
	rotationMatrix_output[1][0] = sin(angle_input);		rotationMatrix_output[1][1] = cos(angle_input);			rotationMatrix_output[1][2] = 0;	
	rotationMatrix_output[2][0] = 0;					rotationMatrix_output[2][1] = 0;						rotationMatrix_output[2][2] = 1;	
}


void getRotationEulerMatrixFromAngleVector( char rotateMode_input[3], TypedefVector3 angleVector_input, TypedefMatrix3x3 rotationMatrix_output )
{
	int i;
	
	TypedefMatrix3x3 rotateMatrix;
	
	getIdentityMatrix3x3( rotationMatrix_output );
	
	for( i = 0; i < 3; i++ )
	{			
		switch (rotateMode_input[i])
		{
			case 'x':
				{
					getRotationMatrixAround_X_axisFromAngle( angleVector_input[i], rotateMatrix );
					multiplyMatrix3x3( rotationMatrix_output , rotateMatrix, rotationMatrix_output ); 									
				}
				break;
				
			case 'X':
				{
					getRotationMatrixAround_X_axisFromAngle( angleVector_input[i], rotateMatrix );
					multiplyMatrix3x3( rotationMatrix_output , rotateMatrix, rotationMatrix_output ); 									
				}
				break;				
				
			case 'y':
				{
					getRotationMatrixAround_Y_axisFromAngle( angleVector_input[i], rotateMatrix );
					multiplyMatrix3x3( rotationMatrix_output , rotateMatrix, rotationMatrix_output ); 									

				}
				break;
				
			case 'Y':
				{
					getRotationMatrixAround_Y_axisFromAngle( angleVector_input[i], rotateMatrix );
					multiplyMatrix3x3( rotationMatrix_output , rotateMatrix, rotationMatrix_output ); 									

				}
				break;				
				
			case 'z':
				{
					getRotationMatrixAround_Z_axisFromAngle( angleVector_input[i], rotateMatrix );
					multiplyMatrix3x3( rotationMatrix_output , rotateMatrix, rotationMatrix_output ); 									

				}
				break;	
						
			case 'Z':
				{
					getRotationMatrixAround_Z_axisFromAngle( angleVector_input[i], rotateMatrix );
					multiplyMatrix3x3( rotationMatrix_output , rotateMatrix, rotationMatrix_output ); 									

				}
				break;												
	
			default : printf("Error in getRotationEulerMatrixFromAngleVector()");
		}
	
	}
	

}
