#ifndef _INC_STRUCTURE
#define _INC_STRUCTURE

#include "general_type.h"

struct TypedefRotatingMatrix3x3
{
	TypedefMatrix3x3  R0_1;
	TypedefMatrix3x3  R1_2;
	TypedefMatrix3x3  R2_3;
	TypedefMatrix3x3  R3_E;

	TypedefMatrix3x3  R0_1Link;
	TypedefMatrix3x3  R1_2Link;
	TypedefMatrix3x3  R2_3Link;
	TypedefMatrix3x3  R3_ELink;

	TypedefMatrix3x3  R0_1JointAngle;
	TypedefMatrix3x3  R1_2JointAngle;
	TypedefMatrix3x3  R2_3JointAngle;
	TypedefMatrix3x3  R3_EJointAngle;
	
	TypedefMatrix3x3  R0_2;
	TypedefMatrix3x3  R0_3;
	TypedefMatrix3x3  R0_E;
};

struct TypedefTranslationVector3
{
	TypedefVector3  p0_1_0;
	TypedefVector3  p1_2_1;
	TypedefVector3  p2_3_2;
	TypedefVector3  p3_E_3;

	TypedefVector3  p0_2_1;
	TypedefVector3  p0_3_2;
	TypedefVector3  p0_E_3;
	
	TypedefVector3  p0_2_0;
	TypedefVector3  p0_3_0;
	TypedefVector3  p0_E_0;
		
	TypedefVector3  p0_E_1;
	TypedefVector3  p0_E_2;
};

struct TypedefLinkAngle
{
	TypedefVector3  angle0_1;	//radian should be used
	TypedefVector3  angle1_2;
	TypedefVector3  angle2_3;
	TypedefVector3  angle3_E;
};

struct TypedefJointStruct
{
	// joint angle[rad]
	TypedefVector3  theta;			// joint angles ["theta1", "theta2", "theta3"]
	TypedefVector3  theta_previous;		// previous joint angles
	TypedefVector3  theta_error;		// error of joint angle
	TypedefVector3  theta_sum_error;	// the sum of error of joint angles
	TypedefVector3  theta_desired;		// desired joint angles
	
	// joint angular angle[rad/s]
	TypedefVector3  dTheta;			// joint angular velocities ["dTheta1", "dTheta2", "dTheta3"]
	TypedefVector3  dTheta_desired;         // desired joint angular velocities
	
	
	// channel number on joint
	unsigned short  da_channel[3];	// DA channel
	unsigned short  ad_channel[3];	// AD channel
	unsigned short  cnt_channel[3];	// Encoder Counter channel
	
	// DA
	TypedefVector3  da_torque;	// joint torque[Nm]
	TypedefVector3  da_data;	// joint da output
	
	// AD
	long  ad_data[3];		// joint AD input
	long  ad_data_offset[3];	// joint AD input Offset
	TypedefVector3  ad_torque;	// measured joint torque by AD[Nm]
	TypedefVector3  ad_average_torque;	// averaged joint AD torque[Nm]
	
	// torque_error = ad_torque - da_torque
	TypedefVector3  torque_error;	// error between AD torque and DA torque[Nm]
	
	// CNT (encoder counter)
	long  cnt_data[3];	// joint Encoder count
};

struct TypedefFingerStruct
{
	unsigned short  da_channel;
};



struct TypedefManipulationVariableStruct
{
	// manipulation variables[rad/sec] 
	// [position "x", position "y", hand orientation "alpha" ]
	TypedefVector3  y;		// manipulation variables
	TypedefVector3  y_previous;		// previous manipulation variables
	TypedefVector3  y_initial;	// initial manipulation variables
	TypedefVector3  y_final;	// final manipulation variables
	TypedefVector3  y_desired;	// desired manipulation variables
	TypedefVector3  y_error;	// errors between manipulation variables and desired ones
	
	TypedefVector3 dY;			// manipulation variables velocities
	TypedefVector3 dY_desired;	// desired manipulation variables velocities
	TypedefVector3 dY_error;	// errors between manipulation variables velocities and desired ones
	
	// forces and torque worked by Evironment at end-effector
	// [force directed to X_0-axis"f_x"[N], force directed to Y_0-axis"f_y"[N], torque around Z_0-axis"f_theta"[Nm]]
	TypedefVector3  da_force;	// DA forces and torque
	TypedefVector3  ad_force;	// AD forces and torque
	
	// forces and torque working to environment at end-effector
	// [force directed to X_0-axis"f_x"[N], force directed to Y_0-axis"f_y"[N], torque around Z_0-axis"f_theta"[Nm]]
	TypedefVector3  da_force_ex;	  // da_force_external = - da_force
	TypedefVector3  ad_force_ex;	  // ad_force_external = - ad_force
};



struct TypedefManipulator
{
	struct TypedefRotatingMatrix3x3   rotatingMatrix;
	struct TypedefTranslationVector3  translationVector;
	struct TypedefLinkAngle           linkAngle;
	
	struct TypedefJointStruct                 joint;
	struct TypedefFingerStruct                finger;
	struct TypedefManipulationVariableStruct  manipulationVariable;
	
	// transposed jacobian
	TypedefMatrix3x3  transposedJacobianMatrix;
	// inversed jacobian
	TypedefMatrix3x3  inversedJacobianMatrix;
	
	double t;
        int datafile_flag;
        int task_num;
        int task_information_flag;
};


struct TypedefAirpadStruct
{
	unsigned short  da_channel;
};

struct TypedefCMGStruct
{
	unsigned short  da_channel;
	
	double	gimbalTheta;
	double	gimbalTheta_previous;
	double	dGimbalTheta;
	double	dGimbalTheta_ordered;
	
	double	torque;
};

struct TypedefThrusterStruct
{
	unsigned short  da_channel[2];
};


struct TypedefMainbodyStruct
{
	struct TypedefAirpadStruct     airpad;
	struct TypedefCMGStruct        cmg;
	struct TypedefThrusterStruct   thruster;
	
	TypedefVector3  r;
	TypedefVector3  r_previous;
	TypedefVector3  r_desired;
	TypedefVector3  r_error;
	TypedefVector3  dr;
	TypedefVector3  dr_desired;
	TypedefVector3  dr_error;

	TypedefVector3  g;
		
	double	phi;
	double	phi_previous;
	double	phi_desired;
	double	phi_error;
	double	dPhi;
	double	dPhi_desired;
	double	dPhi_error;

	double	t;
	double	t_vis;	
};

#endif
