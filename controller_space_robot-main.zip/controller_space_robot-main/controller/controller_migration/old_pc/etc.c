#include <math.h>
#include "general_type.h"
#include "matrix_vector_operation.h"
#include "spec.h"
#include "etc.h"

void getDividedDifference( double function1_input , double function2_input , double x1_input , double x2_input , double *difference_return )
{
	*difference_return = (function1_input - function2_input)/(x1_input - x2_input);
}


void getJointAngularVelocity( TypedefVector3 theta_input , TypedefVector3 theta_previous_input , double samplingTime_input , TypedefVector3 dTheta_output )
{
	int i;
	double size = 3;
	double theta_difference;
	
	for(i=0;i<size;i++){
		theta_difference = theta_input[i] - theta_previous_input[i];
		if (fabs(theta_difference) < LARGE_ENOUGH ){
			getDividedDifference( theta_input[i] , theta_previous_input[i] , samplingTime_input , 0 , &dTheta_output[i] );
		}else{
			if( theta_difference > 0 ){
				dTheta_output[i] = LARGE_ENOUGH / samplingTime_input;
			}else{
				dTheta_output[i] = - LARGE_ENOUGH / samplingTime_input;
			}
		}
	}
}

void getManipulationVariableVelocity( TypedefVector3 y_input , TypedefVector3 y_previous_input , double samplingTime_input , TypedefVector3 dY_output )
{
	int i;
	double size = 3;
	
	for(i=0;i<size;i++){
		getDividedDifference( y_input[i] , y_previous_input[i] , samplingTime_input , 0 , &dY_output[i] );
	}
}


void getTransposedJacobian( TypedefVector3 theta_input , 
                            double link1_input , 
			    double link2_input , 
			    double link3_input , 
			    TypedefMatrix3x3 transposedJacobianMatrix_return )
//-----INPUT----------------------------
// arg1. joint angles
// arg2. length of link1
// arg3. length of link2
// arg4. length of link3
//----OUTPUT----------------------------
// arg5. transposed jacobian
//--------------------------------------
{
	TypedefMatrix3x3 jacobianMatrix_temp; // matrix to keep jacobian matrix temporarily
	
	double  theta1   = theta_input[0];
	double  theta12  = theta1  + theta_input[1];
	double  theta123 = theta12 + theta_input[2];

	// Initialize jacobian matrix
	getZeroMatrix3x3( transposedJacobianMatrix_return );

	// calculate the elements of jacobian matrix
	jacobianMatrix_temp[0][0] = -(link1_input * sin(theta1) + link2_input * sin(theta12) + link3_input * sin(theta123));
	jacobianMatrix_temp[1][0] =  (link1_input * cos(theta1) + link2_input * cos(theta12) + link3_input * cos(theta123));
	jacobianMatrix_temp[2][0] =   1.0;

	jacobianMatrix_temp[0][1] = -(link2_input * sin(theta12) + link3_input * sin(theta123));
	jacobianMatrix_temp[1][1] =  (link2_input * cos(theta12) + link3_input * cos(theta123));
	jacobianMatrix_temp[2][1] =   1.0;

	jacobianMatrix_temp[0][2] = - link3_input * sin(theta123);
	jacobianMatrix_temp[1][2] =   link3_input * cos(theta123);
	jacobianMatrix_temp[2][2] =   1.0;
	
	// transpose jacobian matrix
	transposeMatrix3x3( jacobianMatrix_temp , transposedJacobianMatrix_return );
	
}

void getInversedJacobian(  TypedefVector3 theta_input ,
			 double link1_input ,
			 double link2_input ,
			 double link3_input ,
			 TypedefMatrix3x3 inversedJacobianMatrix_return	)
{
		TypedefMatrix3x3 jacobianMatrix_temp; // matrix to keep jacobian matrix temporarily
	
	double  theta1   = theta_input[0];
	double  theta12  = theta1  + theta_input[1];
	double  theta123 = theta12 + theta_input[2];

	// Initialize jacobian matrix
	getZeroMatrix3x3( inversedJacobianMatrix_return );

	// calculate the elements of jacobian matrix
	jacobianMatrix_temp[0][0] = -(link1_input * sin(theta1) + link2_input * sin(theta12) + link3_input * sin(theta123));
	jacobianMatrix_temp[1][0] =  (link1_input * cos(theta1) + link2_input * cos(theta12) + link3_input * cos(theta123));
	jacobianMatrix_temp[2][0] =   1.0;

	jacobianMatrix_temp[0][1] = -(link2_input * sin(theta12) + link3_input * sin(theta123));
	jacobianMatrix_temp[1][1] =  (link2_input * cos(theta12) + link3_input * cos(theta123));
	jacobianMatrix_temp[2][1] =   1.0;

	jacobianMatrix_temp[0][2] = - link3_input * sin(theta123);
	jacobianMatrix_temp[1][2] =   link3_input * cos(theta123);
	jacobianMatrix_temp[2][2] =   1.0;
	
	// Inverse jacobian matrix
	inverseMatrix3x3( jacobianMatrix_temp , inversedJacobianMatrix_return );	
}

void inverseKinematicsForLeftArm( TypedefVector3 y_input , TypedefVector3 theta_output )
{
	double angle1, angle2, angle3;
	double z, w;	//(z, w) is position of end of Link12 on coordinate_11.
	
	double a;
	double b;
	
	// origin shift : coordinate_0 (X_0,Y_0,Z_0) to coordinate_11 (X_11,Y_11,Z_11)
	z = y_input[0] - L13*cos(y_input[2]);
	w = y_input[1] - L13*sin(y_input[2]) - SHOULDER_WIDTH;
	
	a = sqrt(z*z+w*w);
	b = (L11*L11 + a*a - L12*L12)/(2*a);
	
	angle1 = acos(b/L11);
	angle2 = acos((a-b)/L12);
	angle3 = atan(w/z);
	
	theta_output[0] = angle1 + angle3;
	theta_output[1] = -(angle1 + angle2);
	theta_output[2] = y_input[2] - theta_output[0] - theta_output[1];
	
	//theta_output[0] = - angle1 + angle3;
	//theta_output[1] = angle1 + angle2;
	//theta_output[2] = y_input[2] - theta_output[0] - theta_output[1];
}


void transferJointTorqueToForceAtEndEffector(TypedefVector3 torque_input, 
                                             TypedefMatrix3x3 transposedJacobianMatrix_input, 
                                             TypedefVector3 force_output)
{
	TypedefMatrix3x3 inverseTransposedJacobianMatrix;
	
	// 1. calculate invese of transposed Jacobian Matrix
	inverseMatrix3x3( transposedJacobianMatrix_input, inverseTransposedJacobianMatrix );
	
	// 2. calculate f_x, f_y and f_theta(forces and toruqe at end-effector) from joint torques.
	multiplyMatrix3x3Vector3( inverseTransposedJacobianMatrix, torque_input, force_output );
}
