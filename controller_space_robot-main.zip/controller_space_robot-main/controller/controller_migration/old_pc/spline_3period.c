#include <math.h>
#include "general_type.h"
#include "spline.h"
#include "spline_3period.h"

void initial1DimensionSpline3Period( struct Spline3PeriodStruct1Dimension *splineStruct_return )
{
	double t_s   = splineStruct_return->t_s;
	double x_s   = splineStruct_return->x_s;

	double t_f   = splineStruct_return->t_f;
	double x_f   = splineStruct_return->x_f;
	
	double parameter = splineStruct_return->parameter;
	
	double delta;
	if(parameter < PARAMETER_MIN){
		delta = (t_f-t_s)/PARAMETER_MIN;
	}else if(parameter < PARAMETER_MAX){
		delta = (t_f-t_s)/parameter;
	}else{
		delta = (t_f-t_s)/PARAMETER_MAX;
	}
	
	// 1. acceleration period
	splineStruct_return->periodStruct[0].t_s   = t_s;
	splineStruct_return->periodStruct[0].x_s   = x_s;
	splineStruct_return->periodStruct[0].dx_s  = 0;
	splineStruct_return->periodStruct[0].ddx_s = 0;

	splineStruct_return->periodStruct[0].t_f   = t_s+2*delta;
	splineStruct_return->periodStruct[0].x_f   = (x_f-x_s)/(t_f-t_s-2*delta)*delta+x_s;
	splineStruct_return->periodStruct[0].dx_f  = (x_f-x_s)/(t_f-t_s-2*delta);
	splineStruct_return->periodStruct[0].ddx_f = 0;
	
	// 2. constant velocity period
	splineStruct_return->periodStruct[1].t_s   = t_s+2*delta;
	splineStruct_return->periodStruct[1].x_s   = (x_f-x_s)/(t_f-t_s-2*delta)*delta+x_s;
	splineStruct_return->periodStruct[1].dx_s  = (x_f-x_s)/(t_f-t_s-2*delta);
	splineStruct_return->periodStruct[1].ddx_s = 0;

	splineStruct_return->periodStruct[1].t_f   = t_f-2*delta;
	splineStruct_return->periodStruct[1].x_f   = (x_f-x_s)/(t_f-t_s-2*delta)*(t_f-t_s-3*delta)+x_s;
	splineStruct_return->periodStruct[1].dx_f  = (x_f-x_s)/(t_f-t_s-2*delta);
	splineStruct_return->periodStruct[1].ddx_f = 0;

	// 3. deceleration period
	splineStruct_return->periodStruct[2].t_s   = t_f-2*delta;
	splineStruct_return->periodStruct[2].x_s   = (x_f-x_s)/(t_f-t_s-2*delta)*(t_f-t_s-3*delta)+x_s;
	splineStruct_return->periodStruct[2].dx_s  = (x_f-x_s)/(t_f-t_s-2*delta);
	splineStruct_return->periodStruct[2].ddx_s = 0;

	splineStruct_return->periodStruct[2].t_f   = t_f;
	splineStruct_return->periodStruct[2].x_f   = x_f;
	splineStruct_return->periodStruct[2].dx_f  = 0;
	splineStruct_return->periodStruct[2].ddx_f = 0;


	// coefficient
	initial1DimensionSpline( &splineStruct_return->periodStruct[0] );
	initial1DimensionSpline( &splineStruct_return->periodStruct[1] );
	initial1DimensionSpline( &splineStruct_return->periodStruct[2] );
}


void get1DimensionSpline3PeriodData( struct Spline3PeriodStruct1Dimension *splineStruct_input , double time_input, double *splineData_output )
{
	double t_s = splineStruct_input->periodStruct[0].t_s;
	double t_f = splineStruct_input->periodStruct[2].t_f;
	double t = time_input;
	double splineData;
	
	double parameter = splineStruct_input->parameter;
	
	double delta;
	if(parameter < PARAMETER_MIN){
		delta = (t_f-t_s)/PARAMETER_MIN;
	}else if(parameter < PARAMETER_MAX){
		delta = (t_f-t_s)/parameter;
	}else{
		delta = (t_f-t_s)/PARAMETER_MAX;
	}
		
	if(t < (t_s+2*delta)){
		get1DimensionSplineData( &splineStruct_input->periodStruct[0] , t, &splineData );
	}else if(t < (t_f-2*delta)){
		get1DimensionSplineData( &splineStruct_input->periodStruct[1] , t, &splineData );
	}else if(t <= t_f){
		get1DimensionSplineData( &splineStruct_input->periodStruct[2] , t, &splineData );
	}else{
		splineData = splineStruct_input->periodStruct[2].x_f;
	}
	
	*splineData_output = splineData;
}


void get1DimensionSpline3PeriodDataDot( struct Spline3PeriodStruct1Dimension *splineStruct_input , double time_input, double *splineDataDot_output )
{
	double t_s = splineStruct_input->periodStruct[0].t_s;
	double t_f = splineStruct_input->periodStruct[2].t_f;
	double t = time_input;
	double splineDataDot;
	
	double parameter = splineStruct_input->parameter;
	
	double delta;
	if(parameter < PARAMETER_MIN){
		delta = (t_f-t_s)/PARAMETER_MIN;
	}else if(parameter < PARAMETER_MAX){
		delta = (t_f-t_s)/parameter;
	}else{
		delta = (t_f-t_s)/PARAMETER_MAX;
	}
		
	if(t < (t_s+2*delta)){
		get1DimensionSplineDataDot( &splineStruct_input->periodStruct[0] , t, &splineDataDot );
	}else if(t < (t_f-2*delta)){
		get1DimensionSplineDataDot( &splineStruct_input->periodStruct[1] , t, &splineDataDot );
	}else if(t <= t_f){
		get1DimensionSplineDataDot( &splineStruct_input->periodStruct[2] , t, &splineDataDot );
	}else{
		splineDataDot = splineStruct_input->periodStruct[2].dx_f;
	}
	
	*splineDataDot_output = splineDataDot;
}


void get1DimensionSpline3PeriodDataDotDot( struct Spline3PeriodStruct1Dimension *splineStruct_input , double time_input, double *splineDataDotDot_output )
{
	double t_s = splineStruct_input->periodStruct[0].t_s;
	double t_f = splineStruct_input->periodStruct[2].t_f;
	double t = time_input;
	double splineDataDotDot;
	
	double parameter = splineStruct_input->parameter;
	
	double delta;
	if(parameter < PARAMETER_MIN){
		delta = (t_f-t_s)/PARAMETER_MIN;
	}else if(parameter < PARAMETER_MAX){
		delta = (t_f-t_s)/parameter;
	}else{
		delta = (t_f-t_s)/PARAMETER_MAX;
	}
		
	if(t < (t_s+2*delta)){
		get1DimensionSplineDataDotDot( &splineStruct_input->periodStruct[0] , t, &splineDataDotDot );
	}else if(t < (t_f-2*delta)){
		get1DimensionSplineDataDotDot( &splineStruct_input->periodStruct[1] , t, &splineDataDotDot );
	}else if(t <= t_f){
		get1DimensionSplineDataDotDot( &splineStruct_input->periodStruct[2] , t, &splineDataDotDot );
	}else{
		splineDataDotDot = splineStruct_input->periodStruct[2].ddx_f;
	}
	
	*splineDataDotDot_output = splineDataDotDot;
}






void initialVector3Spline3Period( struct Spline3PeriodStructVector3 *splineStruct_return )
{
	int i;
	int size = 3;
	
	struct Spline3PeriodStructVector3 *spline3PeriodStructVector3;
	spline3PeriodStructVector3 = splineStruct_return;
	
		

	// seperate 3 dimension of splineStructVector3 to splineStruct1Dimension
	for( i = 0; i < size; i++ )
	{
		spline3PeriodStructVector3->spline3PeriodStruct1Dimension[i].t_s   = spline3PeriodStructVector3->t_s;
		spline3PeriodStructVector3->spline3PeriodStruct1Dimension[i].x_s   = spline3PeriodStructVector3->x_s[i];

		spline3PeriodStructVector3->spline3PeriodStruct1Dimension[i].t_f   = spline3PeriodStructVector3->t_f;
		spline3PeriodStructVector3->spline3PeriodStruct1Dimension[i].x_f   = spline3PeriodStructVector3->x_f[i];
		
		spline3PeriodStructVector3->spline3PeriodStruct1Dimension[i].parameter = spline3PeriodStructVector3->parameter;
	}
	

	// calculate spline coefficient all of 3 component
	for( i = 0; i < size; i++ )	
		initial1DimensionSpline3Period( &spline3PeriodStructVector3->spline3PeriodStruct1Dimension[i] );
	
}


void getVector3Spline3PeriodData( struct Spline3PeriodStructVector3 *splineStruct_input , double time_input, TypedefVector3 splineData_output )
{
	int i;
	int size = 3;
	
	double splineData;
		
	for( i = 0; i < size; i++ )
	{
		get1DimensionSpline3PeriodData( &splineStruct_input->spline3PeriodStruct1Dimension[i] , time_input, &splineData );
		splineData_output[i] = splineData;
	}																		

}


void getVector3Spline3PeriodDataDot( struct Spline3PeriodStructVector3 *splineStruct_input , double time_input, TypedefVector3 splineDataDot_output )
{
	int i;
	int size = 3;
	
	double splineDataDot;
		
	for( i = 0; i < size; i++ )
	{
		get1DimensionSpline3PeriodDataDot( &splineStruct_input->spline3PeriodStruct1Dimension[i] , time_input, &splineDataDot );
		splineDataDot_output[i] = splineDataDot;
	}																		

}


void getVector3Spline3PeriodDataDotDot( struct Spline3PeriodStructVector3 *splineStruct_input , double time_input, TypedefVector3 splineDataDotDot_output )
{
	int i;
	int size = 3;
	
	double splineDataDotDot;
		
	for( i = 0; i < size; i++ )
	{
		get1DimensionSpline3PeriodDataDotDot( &splineStruct_input->spline3PeriodStruct1Dimension[i] , time_input, &splineDataDotDot );
		splineDataDotDot_output[i] = splineDataDotDot;
	}

}
