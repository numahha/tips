#include <math.h>
#include "general_type.h"
#include "matrix_vector_operation.h"
#include "localPD.h"

void artificialPotentialMethodVector3( TypedefMatrix3x3 proportionalGainMatrix_input, TypedefVector3 y_input, TypedefVector3 y_desired_input, TypedefVector3 u_output )
{
	double alpha1;
	double alpha2;
	double alpha3;
	double threshold1 = 0.035;
	double threshold2 = 0.035;
	double threshold3 = 0.035;
	
	TypedefVector3 gain;
	TypedefVector3 y_error;
	double euclideanNorm;
	
	
	getDiagonalVector3FromMatrix3x3( proportionalGainMatrix_input, gain );
	alpha1 = gain[0] * threshold1;
	alpha2 = gain[1] * threshold2;
	alpha3 = gain[2] * threshold3;
	
	subtractVector3( y_input , y_desired_input , y_error );
	euclideanNorm = getEuclideanNormOfVector3( y_error );

	if( euclideanNorm > threshold1 ){
		u_output[0] = alpha1 * y_error[0] / euclideanNorm;
	}else{
		u_output[0] = alpha1 * y_error[0] / threshold1;
	}
	
	if( euclideanNorm > threshold2 ){
		u_output[1] = alpha2 * y_error[1] / euclideanNorm;
	}else{
		u_output[1] = alpha2 * y_error[1] / threshold2;
	}

	if( euclideanNorm > threshold3 ){
		u_output[2] = alpha3 * y_error[2] / euclideanNorm;
	}else{
		u_output[2] = alpha3 * y_error[2] / threshold3;
	}
}


void localPDControlVector3( TypedefMatrix3x3 transposedJacobianMatrix_input,
			    TypedefMatrix3x3 proportionalGainMatrix_input,
			    TypedefVector3 y_input, 
			    TypedefVector3 y_desired_input,
			    TypedefMatrix3x3 derivativeGainMatrix_input,
			    TypedefVector3 dTheta_input, 
			    TypedefVector3 torque_output )
//-----INPUT----------------------------
// arg1. transposed jacobian matrix  
// arg2. proportional gain matrix
// arg3. manipulation variables
// arg4. desired manipulation variables
// arg5. derivative gain matrix 
// arg6. joint angular velocity
//----OUTPUT----------------------------
// arg7. toruqes
//--------------------------------------
{
	// vector used only in this function for caluculation
	TypedefVector3   vector1;
	TypedefVector3   vector2;
	TypedefVector3   vector3;
	TypedefVector3   zeroVector;

	// "u" output of artificial potential method
	TypedefVector3   u;

	// calculate all vectors and matrices used in localPD control equation.
	artificialPotentialMethodVector3( proportionalGainMatrix_input, y_input, y_desired_input, u );

	// calculate the first term "J^T u" and the second term "K_D dTheta".
	multiplyMatrix3x3Vector3( transposedJacobianMatrix_input, u, vector1 );
	multiplyMatrix3x3Vector3( derivativeGainMatrix_input, dTheta_input, vector2 );

	// tau = - J^T * u - K_D * dTheta
	addVector3( vector1, vector2, vector3 );
	getZeroVector3( zeroVector );
	subtractVector3( zeroVector, vector3, torque_output );
}
