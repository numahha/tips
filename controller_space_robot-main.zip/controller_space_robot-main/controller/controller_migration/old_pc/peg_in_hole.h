// file name :  peg_in_hole.h
// written by Takayuki Kondo 2006/10/24
//
// The purpose is for using on RTLinux.
// This is written in C language.

//----------------begin 2007/09/28 modified by Takayuki Kondo---------------------
//	1. I changed some names of variables.
//		1. struct TypedefManipulator manipulator1 ---> manipulator2  (1 for right arm, 2 for left arm)
//
//----------------end 2007/09/28 modified by Takayuki Kondo---------------------


#ifndef _INC_PEG_IN_HOLE
#define _INC_PEG_IN_HOLE

#include "general_type.h"
//#define M_PI	3.14159265358979
//#define ZERO	1.0e-8

#define OTSUBO_FLAG 0

#define TSA_GAIN_SHOULDER 5.0
#define TSA_GAIN_ELBOW    5.0
#define TSA_GAIN_WRIST    2.0


#define Y_1	 10
#define Y_2	 7
#define Y_3	 11
#define FORCE_1  3
#define FORCE_2  5
#define FORCE_3  5


#ifdef ALL_STATE_NUM
#undef ALL_STATE_NUM
#endif
#ifdef ACTION_NUM
#undef ACTION_NUM
#endif


#define STATE_NUM    (Y_1*Y_2*Y_3*FORCE_1*FORCE_2*FORCE_3)
#define ALL_STATE_NUM (STATE_NUM+2)
#define ACTION_NUM   6
#define S_DIMENSION  6

#define WY_1      0.001
#define WY_2      0.001
#define WY_3      (0.5/180.0*M_PI)
#define WFORCE_1  1.5
#define WFORCE_2  1.0
#define WFORCE_3  0.3

#define L_ENDEFFECTOR_PEGEDGE   0.05   // Length from End-effector coordinate to Edge point of peg 

#define ORIGIN_Y_1       0.500
#define ORIGIN_Y_2       0.540
#define ORIGIN_Y_3       0.0

#define Y_1_MIN      (ORIGIN_Y_1 - WY_1)
#define Y_2_MIN      (ORIGIN_Y_2 - 0.5*(Y_2-1)*WY_2)
#define Y_3_MIN      (ORIGIN_Y_3 - 0.5*(Y_3-1)*WY_3)
#define FORCE_1_MIN  (0.0)
#define FORCE_2_MIN  (-0.5*(FORCE_2-1)*WFORCE_2)
#define FORCE_3_MIN  (-0.5*(FORCE_3-1)*WFORCE_3)

#define Y_1_MAX      (Y_1_MIN + WY_1*(Y_1 - 1))
#define Y_2_MAX      (Y_2_MIN + WY_2*(Y_2 - 1))
#define Y_3_MAX      (Y_3_MIN + WY_3*(Y_3 - 1))
#define FORCE_1_MAX  ( FORCE_1_MIN + (FORCE_1-1)*WFORCE_1 )
#define FORCE_2_MAX  (0.5*(FORCE_2-1)*WFORCE_2)
#define FORCE_3_MAX  (0.5*(FORCE_3-1)*WFORCE_3)


#define MINY_1       (Y_1_MIN - WY_1 / 2.0)
#define MINY_2       (Y_2_MIN - WY_2 / 2.0)
#define MINY_3       (Y_3_MIN - WY_3 / 2.0)
#define MINFORCE_1   (FORCE_1_MIN - WFORCE_1 / 2.0)
#define MINFORCE_2   (FORCE_2_MIN - WFORCE_2 / 2.0)
#define MINFORCE_3   (FORCE_3_MIN - WFORCE_3 / 2.0)

#define MAXY_1       (Y_1_MAX + WY_1 / 2.0)
#define MAXY_2       (Y_2_MAX + WY_2 / 2.0)
#define MAXY_3       (Y_3_MAX + WY_3 / 2.0)
#define MAXFORCE_1   (FORCE_1_MAX + WFORCE_1 / 2.0)
#define MAXFORCE_2   (FORCE_2_MAX + WFORCE_2 / 2.0)
#define MAXFORCE_3   (FORCE_3_MAX + WFORCE_3 / 2.0)

#ifdef GAMMA 
#undef GAMMA
#endif

#ifdef EPSILON
#undef EPSILON
#endif

#define GAMMA	 0.0			/* Step-size parameter */
#define COST	 1.0			/* Cost */
#define ALPHA	 1.0			/* Discount-rate parameter */
#define EPSILON	 0.0			/* epsilon */
#define MAX_STEP 50                     /* the maximum number of steps */
//#define MAX_STEP 3


#ifdef INIT_X
#undef INIT_X
#endif
#ifdef INIT_Y
#undef INIT_Y
#endif
#ifdef INIT_Z
#undef INIT_Z
#endif

#define INIT_X  ( ORIGIN_Y_1 - WY_1   )
#define INIT_Y  ( ORIGIN_Y_2 + 2*WY_2 ) //-2//2
#define INIT_Z  ( ORIGIN_Y_3 - 2*WY_3 ) //-3//-2




#define MEAN_X    0
#define MEAN_Y    0
#define MEAN_Z    0
#define SIGMA_X  (0.75*0.001)
#define SIGMA_Y  (0.75*0.001)
#define SIGMA_Z  (0.5*PI/180)

//-----------------------------------------------------------------------
//----------Structure----------------------------------------------------
//-----------------------------------------------------------------------
struct PegInHoleStructure{
	int step;
	int goal_flag;
	long s_i;
	long s_iPlus1;
	int  s_i_element[S_DIMENSION];
	int  s_iPlus1_element[S_DIMENSION];
	int  u_k;
	double Q[ACTION_NUM];
	
	TypedefVector3 y_i;
	TypedefVector3 force_i;
	TypedefVector3 y_iPlus1;
	TypedefVector3 force_iPlus1;

	TypedefVector3 y;
	TypedefVector3 force;
	
	TypedefVector3 y_d_i;
	TypedefVector3 y_d_iPlus1;

  double localPD_t_s;
  
  TypedefVector3 error;
  int task_num;
  int datafile_flag;

};


struct PegInHoleNominalStateStructure{
	int step;
	int goal_flag;
	long s_i;
	long s_iPlus1;
	int  s_i_element[S_DIMENSION];
	int  s_iPlus1_element[S_DIMENSION];
	int  u_k;
	double Q;

	TypedefVector3 y_i;
	TypedefVector3 force_i;
	TypedefVector3 y_iPlus1;
	TypedefVector3 force_iPlus1;

	TypedefVector3 y;
	TypedefVector3 force;
	
	TypedefVector3 y_d_i;
	TypedefVector3 y_d_iPlus1;
	
	TypedefVector3 error;
};

struct CMD_STRUCT_PIH{

  int task_termination_flag;

  int control_init_flag;
  int learning_init_flag;

  int control_flag;
  int learning_flag;

  long s_i;
  int u_k;
  long s_j;
  int greedy_action;

  double Q[6];

};



//--------begin modified 2007/02/17 by Takayuki Kondo---------------
// 1. I added a function which set count number on encoder counter.
//	1.1) 
//
//--------end modified 2007/02/17 by Takayuki Kondo-----------------


//-----------------------------------------------------------------------
//-----------Prototype declaration---------------------------------------
//-----------------------------------------------------------------------
int positionAndPostureAtCenterOfStateForPegInHole(void);
int initialPositionAndPostureForPegInHole(double *random_number_sequence_input, int input_num);
int squarePegInHole(double *random_number_sequence_input, 
                    double *sharedQ1_return, 
		    double *Q1_return);

int test_program_rtlinux( double *random_number_sequence_input, 
			  double *sharedQ1_return, 
			  double *Q1_return,
			  struct CMD_STRUCT_PIH *cmd );

int insertPeg(void);

int PegInHoleController(double yx_input, 
                        double yy_input, 
		        double yt_input, 
		        double *random_number_sequence_input, 
		        double *sharedQ_return, 
		        double *Q_return);



int PointToPointControlWithLocalPDControl(struct SplineStructVector3 splineVector3_input, 
					  TypedefMatrix3x3 localPDProportionalGainMatrix_input, 
					  TypedefMatrix3x3 localPDDerivativeGainMatrix_input, 
					  struct TypedefManipulator *manipulator2_return );


void rtlinuxRandomNumberGenerator(double *random_number_sequence_input, double *random_number_output);


void checkOutOfStateSpace(TypedefVector3 y_input, int out_flag_output[]);
//void checkGoalState(TypedefVector3 y_input, int *goal_flag_output);
void checkGoalState(TypedefVector3 y_input, int s_i_element_input[], int *goal_flag_output);

void checkSettlingCondition( int t_input, int t_f_input, TypedefVector3 dTheta_input, int *settling_flag_return);


void continuousStateToDiscreteState(TypedefVector3 y_input, TypedefVector3 force_input, long *s_i_output, int s_i_element_output[] );
void discreteStateToContinuousState( int s_i_element_input[], TypedefVector3 y_output, TypedefVector3 force_output );

void greedy(long s_i_input, double *Q_input, double *random_number_sequence_input, int *u_greedy_output);
void epsilon_greedy(double epsilon_input, long s_input, double *Q_input, double *random_number_sequence_input, int *u_output);
void actionToNextManipulationVariable(TypedefVector3 y_d_i_input, int u_input, TypedefVector3 y_d_iPlus1_output );
//void limiter_QL(TypedefVector3 y_input, TypedefVector3 force_return, TypedefVector3 torque_return);

void boxrnd( double mean_input, double sigma_input, double *random_number_sequence_input, double *x_output );
void getManipulationVariableWithError( TypedefVector3 y_input, 
                                       TypedefVector3 error_input, 
				       TypedefVector3 yWithE_output );

void getManipulationVariableWithoutError( TypedefVector3 yWithE_input, 
                                          TypedefVector3 error_input, 
					  TypedefVector3 y_output );

void getForcesAndTorqueWithError( TypedefVector3 f_input, 
				  TypedefVector3 error_input, 
				  TypedefVector3 fWithE_output );

void getForcesAndTorqueWithoutError( TypedefVector3 fWithE_input, 
				     TypedefVector3 error_input, 
				     TypedefVector3 fWithoutE_output );

void actionToNextManipulationVariableWithError( TypedefVector3 y_d_i_input, 
                                                int u_input, 
						TypedefVector3 error_input, 
						TypedefVector3 y_d_iPlus1_output );

int squarePegInHoleWithError( double *random_number_sequence_input, 
                              double *sharedQ1_return, 
		              double *Q1_return );

int checkPegInHoleWithError( double *random_number_sequence_input, 
                             double *sharedQ1_return,
                             double *Q1_return );

int getEncoderCountNumberOnThreeJoints( void );
int setEncoderCountNumberOnThreeJoints( void );


void getTransposedJacobianWithPegContactPoint2( TypedefVector3 theta_input , 
                            double link1_input , 
			    double link2_input , 
			    double link3_input , 
			    TypedefVector3 l_ce_input,
			    TypedefMatrix3x3 transposedJacobianMatrix_return );


void frictionIdentificationFromPegToHole( const int input_num );

#endif
