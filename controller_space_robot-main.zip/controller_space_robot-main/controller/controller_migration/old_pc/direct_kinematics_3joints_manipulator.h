#ifndef _INC_DIRECT_KINEMATICS_3JOINTS_MANIPULATOR
#define _INC_DIRECT_KINEMATICS_3JOINTS_MANIPULATOR

#include "general_type.h"
#include "matrix_vector_operation.h"


struct TypedefLinkAngle getLinkAngleFromFile( char filename_input[50] );
struct TypedefRotatingMatrix3x3 getRotatingMatricesLinkAngle( struct TypedefLinkAngle linkAngle_input, 
                                                              struct TypedefRotatingMatrix3x3 rotatingMatrix_return );
struct TypedefRotatingMatrix3x3 getRotatingMatrices( TypedefVector3 theta_input, struct TypedefRotatingMatrix3x3 rotatingMatrix_return );
struct TypedefTranslationVector3 getTranslationVectorsFromFile( char filename_input[50] );
struct TypedefTranslationVector3 getTranslationVectors( struct TypedefRotatingMatrix3x3 rotatingMatrix_input, 
                                                        struct TypedefTranslationVector3 translationVector_return );
void directKinematics3JointsManipulator(struct TypedefManipulator *manipulator1);


#endif
