#ifndef _INC_SPLINE_3PERIOD
#define _INC_SPLINE_3PERIOD

#include <math.h>
#include "general_type.h"
#include "spline.h"


#define PARAMETER_MIN 15.0
#define PARAMETER_MAX 30.0

struct Spline3PeriodStruct1Dimension
{
	//--------------- public variable ----------------
    	// -------------initial value ----------------
		// initial time
    		double t_s;

		// initial data
    		double x_s;

    	// ---------------final value ----------------
		// final time
    		double t_f;

		// final data
    		double x_f;

		// ----------Delta = t_f / parameter ---------
		double parameter;
	
	//--------------- private variable ---------------
		// 1. acceleration period
		// 2. constant velocity period
		// 3. deceleration period
		struct SplineStruct1Dimension periodStruct[3];

};



struct Spline3PeriodStructVector3
{
	//--------------- public variable ----------------
    	// -------------initial value -----------------

		// initial time
    		double t_s;

		// initial data
    		TypedefVector3 x_s;

    	// ---------------final value ---------------------
		// final time
    		double t_f;

		// final data
    		TypedefVector3 x_f;

		// ----------Delta = t_f / parameter ---------
		double parameter;

    //--------------- private variable ----------------
		// coefficient
		struct Spline3PeriodStruct1Dimension spline3PeriodStruct1Dimension[3];

};



// spline function for one dimension data
void initial1DimensionSpline3Period( struct Spline3PeriodStruct1Dimension *splineStruct_return );
void get1DimensionSpline3PeriodData( struct Spline3PeriodStruct1Dimension *splineStruct_input , double time_input, double *splineData_output );
void get1DimensionSpline3PeriodDataDot( struct Spline3PeriodStruct1Dimension *splineStruct_input , double time_input, double *splineDataDot_output );
void get1DimensionSpline3PeriodDataDotDot( struct Spline3PeriodStruct1Dimension *splineStruct_input , double time_input, double *splineDataDotDot_output );

// spline function for vector (3 dimension spline)
void initialVector3Spline3Period( struct Spline3PeriodStructVector3 *splineStruct_return );
void getVector3Spline3PeriodData( struct Spline3PeriodStructVector3 *splineStruct_input , double time_input, TypedefVector3 splineData_output );
void getVector3Spline3PeriodDataDot( struct Spline3PeriodStructVector3 *splineStruct_input , double time_input, TypedefVector3 splineDataDot_output );
void getVector3Spline3PeriodDataDotDot( struct Spline3PeriodStructVector3 *splineStruct_input , double time_input, TypedefVector3 splineDataDotDot_output );

#endif
