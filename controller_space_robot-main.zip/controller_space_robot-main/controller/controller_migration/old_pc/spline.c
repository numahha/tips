#include <math.h>
#include "general_type.h"
#include "spline.h"


void initial1DimensionSpline( struct SplineStruct1Dimension *splineStruct_return )
{
	double t_s = splineStruct_return->t_s;
	double x_s = splineStruct_return->x_s;
	double dx_s = splineStruct_return->dx_s;
	double ddx_s = splineStruct_return->ddx_s;

	double t_f = splineStruct_return->t_f;
	double x_f = splineStruct_return->x_f;
	double dx_f = splineStruct_return->dx_f;
	double ddx_f = splineStruct_return->ddx_f;

	
	double *coefficient;
	coefficient = splineStruct_return->coefficient; 

	coefficient[0] = x_s;
	coefficient[1] = dx_s;	
	coefficient[2] = ddx_s/2;	
	coefficient[3] = ( 20*x_f - 20*x_s - (8*dx_f + 12*dx_s)*(t_f-t_s) - (3*ddx_s - ddx_f)*pow(t_f-t_s,2) )/( 2*pow(t_f-t_s,3) );  
	coefficient[4] = ( 30*x_s - 30*x_f + (14*dx_f + 16*dx_s)*(t_f-t_s) + (3*ddx_s - 2*ddx_f)*pow(t_f-t_s,2) )/( 2*pow(t_f-t_s,4) );  
	coefficient[5] = ( 12*x_f - 12*x_s - (6*dx_f + 6*dx_s)*(t_f-t_s) - (ddx_s - ddx_f)*pow(t_f-t_s,2) )/( 2*pow(t_f-t_s,5) );  
			
}




void get1DimensionSplineData( struct SplineStruct1Dimension *splineStruct_input , double time_input, double *splineData_output )
{

	double t_s = splineStruct_input->t_s;
	double t = time_input;
	double *c;
	
	c = splineStruct_input->coefficient;

	*splineData_output = c[0]+c[1]*(t - t_s)+c[2]*pow(t-t_s,2)+c[3]*pow(t-t_s,3)+c[4]*pow(t-t_s,4)+c[5]*pow(t-t_s,5);

}


void get1DimensionSplineDataDot( struct SplineStruct1Dimension *splineStruct_input , double time_input, double *splineDataDot_output )
{

	double t_s = splineStruct_input->t_s;
	double t = time_input;
	double *c;
	
	c = splineStruct_input->coefficient;

	*splineDataDot_output = c[1]+2*c[2]*(t-t_s)+3*c[3]*pow(t-t_s,2)+4*c[4]*pow(t-t_s,3)+5*c[5]*pow(t-t_s,4);

}

void get1DimensionSplineDataDotDot( struct SplineStruct1Dimension *splineStruct_input , double time_input, double *splineDataDotDot_output )
{

	double t_s = splineStruct_input->t_s;
	double t = time_input;
	double *c;
	
	c = splineStruct_input->coefficient;

	*splineDataDotDot_output = 2*c[2]+6*c[3]*(t-t_s)+12*c[4]*pow(t-t_s,2)+20*c[5]*pow(t-t_s,3);

}


void get1DimensionSplineDataDotDotDot( struct SplineStruct1Dimension *splineStruct_input , double time_input, double *splineDataDotDotDot_output )
{
	double t_s = splineStruct_input->t_s;
	double t = time_input;
	double *c;
	
	c = splineStruct_input->coefficient;

	*splineDataDotDotDot_output = 6*c[3]+24*c[4]*(t-t_s)+60*c[5]*pow(t-t_s,2);
}





void initialVector3Spline( struct SplineStructVector3 *splineStruct_return )
{
	int i;
	int size = 3;		
	
	struct SplineStructVector3 *splineStructVector3;
	splineStructVector3 = splineStruct_return;
	
		

	// seperate 3 dimension of splineStructVector3 to splineStruct1Dimension
	for( i = 0; i < size; i++ )
	{
		splineStructVector3->splineStruct1Dimension[i].t_s = splineStructVector3->t_s;		
		splineStructVector3->splineStruct1Dimension[i].x_s = splineStructVector3->x_s[i];
		splineStructVector3->splineStruct1Dimension[i].dx_s = splineStructVector3->dx_s[i];
		splineStructVector3->splineStruct1Dimension[i].ddx_s = splineStructVector3->ddx_s[i];		

		splineStructVector3->splineStruct1Dimension[i].t_f = splineStructVector3->t_f;		
		splineStructVector3->splineStruct1Dimension[i].x_f = splineStructVector3->x_f[i];
		splineStructVector3->splineStruct1Dimension[i].dx_f = splineStructVector3->dx_f[i];
		splineStructVector3->splineStruct1Dimension[i].ddx_f = splineStructVector3->ddx_f[i];			
	}
	

	// calculate spline coefficient all of 3 component
	for( i = 0; i < size; i++ )	
		initial1DimensionSpline( &splineStructVector3->splineStruct1Dimension[i] );
	
	
	
}


			
void getVector3SplineData( struct SplineStructVector3 *splineStruct_input , double time_input, TypedefVector3 splineData_output )
{
	int i;
	int size = 3;
	
	double splineData;
		
	for( i = 0; i < size; i++ )
	{
		get1DimensionSplineData( &splineStruct_input->splineStruct1Dimension[i],time_input, &splineData );
		splineData_output[i] = splineData;
	}																		

}


void getVector3SplineDataDot( struct SplineStructVector3 *splineStruct_input , double time_input, TypedefVector3 splineDataDot_output )
{
	int i;
	int size = 3;
	
	double splineDataDot;
		
	for( i = 0; i < size; i++ )
	{
		get1DimensionSplineDataDot( &splineStruct_input->splineStruct1Dimension[i],time_input, &splineDataDot );
		splineDataDot_output[i] = splineDataDot;
	}																		

}


void getVector3SplineDataDotDot( struct SplineStructVector3 *splineStruct_input , double time_input, TypedefVector3 splineDataDotDot_output )
{
	int i;
	int size = 3;
	
	double splineDataDotDot;
		
	for( i = 0; i < size; i++ )
	{
		get1DimensionSplineDataDotDot( &splineStruct_input->splineStruct1Dimension[i],time_input, &splineDataDotDot );
		splineDataDotDot_output[i] = splineDataDotDot;
	}																		

}



void getVector3SplineDataDotDotDot( struct SplineStructVector3 *splineStruct_input , double time_input, TypedefVector3 splineDataDotDotDot_output )
{
	int i;
	int size = 3;
	
	double splineDataDotDotDot;
		
	for( i = 0; i < size; i++ )
	{
		get1DimensionSplineDataDotDotDot( &splineStruct_input->splineStruct1Dimension[i],time_input, &splineDataDotDotDot );
		splineDataDotDotDot_output[i] = splineDataDotDotDot;
	}																		

}
