#include <iostream>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <cmath>


#include "definition_const_data.h"

/*
 This is a modification of Task-command 400 used in the old robot control PC (build upon RT-Linux).

 Specifically, it is a modification of
   "int positionAndPostureAtCenterOfStateForPegInHole(d)" in "/home/space_robot/usr/kondo/task/peg_in_hole/peg_in_hole.c",
   which uses 
   "void localPDcontrolWithSplineVector3()" in "/home/space_robot/common/control_with_spline/control_with_spline.c",
   where these paths are in the old robot control PC.
*/


#include "old_pc/general_type.h"
#include "old_pc/matrix_vector_operation.h"
#include "old_pc/spec.h"
#include "old_pc/structure.h"
#include "old_pc/spline.h"
#include "old_pc/direct_kinematics_3joints_manipulator.h"
#include "old_pc/localPD.h"
#include "old_pc/etc.h"
#include "old_pc/peg_in_hole.h"

#include "controller_left_arm.h"

controller_left_arm::controller_left_arm(std::vector<double> given_theta) : controller_arm(given_theta)
{
        printf("controller_left_arm constructor\n");

	// from "/home/space_robot/usr/kondo/task/peg_in_hole/peg_in_hole.c"
        int i;
	//1 Measure joint angle by Encoder counter
	//getJointAngle( manipulator2.joint.cnt_channel , manipulator2.joint.cnt_data , manipulator2.joint.theta ); // used by old IO
        for(i=0;i<3;i++) manipulator2.joint.theta[i] = theta[i];

	// 2 only once at first
	//2.1.1) theta_previous  = theta
	//    2) theta_desired   = theta
	//    3) theta_error	 = 0
	//    4) theta_sum_error = 0
	//    5) dTheta 	 = 0
	//    6) dTheta_desired  = dTheta
	//    7) torque 	 = 0
	//    8) da_data         = 0
	copyVector3   ( manipulator2.joint.theta , manipulator2.joint.theta_previous );
	copyVector3   ( manipulator2.joint.theta , manipulator2.joint.theta_desired );
	getZeroVector3( manipulator2.joint.theta_error );
	getZeroVector3( manipulator2.joint.theta_sum_error );
	getZeroVector3( manipulator2.joint.dTheta );
	copyVector3   ( manipulator2.joint.dTheta , manipulator2.joint.dTheta_desired );
	getZeroVector3( manipulator2.joint.da_torque );
	getZeroVector3( manipulator2.joint.ad_torque );
	getZeroVector3( manipulator2.joint.ad_average_torque ); 


	// 3 Direct Kinematics for 3joints manipulator
	directKinematics3JointsManipulator(&manipulator2);

	
	// 4 set initial data and final data of spline for localPD control
	//initial time	
	splineVector3.t_s =  manipulator2.t;
		
	//manipulation variables at the initial point
	copyVector3( manipulator2.manipulationVariable.y, splineVector3.x_s );
		
	//derivative of manipuation variables at the initial point
	getZeroVector3( splineVector3.dx_s );
		
	//second derivative of manipuation variables at the initial point
	getZeroVector3( splineVector3.ddx_s );

	//final time
	splineVector3.t_f = manipulator2.t + 5.0;

	//======================================================
	//manipulation variables at the final point
	splineVector3.x_f[0] = ORIGIN_Y_1 + WY_1;
	splineVector3.x_f[1] = ORIGIN_Y_2 - 0.0*WY_2;
	splineVector3.x_f[2] = ORIGIN_Y_3 - 0.0*WY_3;
	//======================================================

	//derivative of manipuation variables at the final point
	getZeroVector3( splineVector3.dx_f );

	//second derivative of manipuation variables at the final point	
	getZeroVector3( splineVector3.ddx_f );


	//localPDcontrolWithSplineVector3(7.0,  
	//				localPDProportionalGainMatrix,
	//				localPDDerivativeGainMatrix,
	//				&splineVector3, 
	//				&manipulator2 );


	// from "/home/space_robot/common/control_with_spline/control_with_spline.c"
	//if(t_control_input < 0)
	//	t_control_input = 0;
	//if((splineVector3_inputoutput->t_f - manipulator2_inputoutput->t) < 0)
	//	splineVector3_inputoutput->t_f = manipulator2_inputoutput->t;
	//if(t_control_input < (splineVector3_inputoutput->t_f - manipulator2_inputoutput->t))
	//	t_control_input = splineVector3_inputoutput->t_f - manipulator2_inputoutput->t;
	t_control_input = 7.0;
	if((splineVector3.t_f - manipulator2.t) < 0)
		splineVector3.t_f = manipulator2.t;
	if(t_control_input < (splineVector3.t_f - manipulator2.t))
		t_control_input = splineVector3.t_f - manipulator2.t;


	initialVector3Spline( &splineVector3 );
	local_t=0.;
  return;
}




void controller_left_arm::main_controller(){
  int i;
	// from "/home/space_robot/common/control_with_spline/control_with_spline.c"
	if(local_t < t_control_input){
		i++;
		// 1 Measure joint angle by Encoder counter
		//getJointAngle( manipulator2_inputoutput->joint.cnt_channel , 
		//               manipulator2_inputoutput->joint.cnt_data , 
		//	         manipulator2_inputoutput->joint.theta ); // used by used by old IO
		for(i=0;i<3;i++) manipulator2.joint.theta_previous[i] = manipulator2.joint.theta[i];
		for(i=0;i<3;i++) manipulator2.joint.theta[i] = theta[i];

		// 2 Direct Kinematics for 3joints manipulator
		//directKinematics3JointsManipulator(manipulator2_inputoutput);
		directKinematics3JointsManipulator(&manipulator2);
	
		// 3 calculate spline coefficients
		//if(initialVectorSpline_flag == 0){
		//	initialVector3Spline( splineVector3_inputoutput );
		//	initialVectorSpline_flag = 1;
		//} // moved to constructor
		 

		// 4 spline should be calculated every sampling time
		//if( manipulator2_inputoutput->t <= splineVector3_inputoutput->t_f )
		//	getVector3SplineData( splineVector3_inputoutput , manipulator2_inputoutput->t , manipulator2_inputoutput->manipulationVariable.y_desired ); 
		if( manipulator2.t <= splineVector3.t_f )
			getVector3SplineData( &splineVector3, manipulator2.t , manipulator2.manipulationVariable.y_desired ); 
					      

		// 5 localPD should be calculated every sampling time
		// 5.1 calculate joint angular velocity
		//getJointAngularVelocity( manipulator2_inputoutput->joint.theta , 
		//                         manipulator2_inputoutput->joint.theta_previous , 
		//			   SAMPLING_TIME , 
		//			   manipulator2_inputoutput->joint.dTheta );
		getJointAngularVelocity( manipulator2.joint.theta , 
		                         manipulator2.joint.theta_previous , 
					 time_duration, 
					 manipulator2.joint.dTheta );
		

		// 5.2 calculate joint torques by localPD control equation.
		//localPDControlVector3( manipulator2_inputoutput->transposedJacobianMatrix,
		//		       localPDProportionalGainMatrix_input,
		//		       manipulator2_inputoutput->manipulationVariable.y , 
		//		       manipulator2_inputoutput->manipulationVariable.y_desired ,
		//		       localPDDerivativeGainMatrix_input,
		//		       manipulator2_inputoutput->joint.dTheta , 
		//		       manipulator2_inputoutput->joint.da_torque );
		localPDControlVector3( manipulator2.transposedJacobianMatrix,
				       localPDProportionalGainMatrix,
				       manipulator2.manipulationVariable.y , 
				       manipulator2.manipulationVariable.y_desired ,
				       localPDDerivativeGainMatrix,
				       manipulator2.joint.dTheta , 
				       manipulator2.joint.da_torque );		

		// 6 DA OUTPUT & AD INPUT
		// 6.1 genarate DA output
		//daOutputToArmBaseFixed( manipulator2_inputoutput->joint.da_channel , 
		//                        manipulator2_inputoutput->joint.da_torque , 
		//			  manipulator2_inputoutput->joint.da_data ); // used by used by old IO
		for(i=0;i<3;i++) torque[i] = manipulator2.joint.da_torque[i];
		
		// 8 update data
		// 8.1 update time

		//manipulator2_inputoutput->t += SAMPLING_TIME;
		//t += SAMPLING_TIME;
		manipulator2.t += time_duration;
		local_t += time_duration;

		// 8.2 update previous joint angles
		//copyVector3( manipulator2_inputoutput->joint.theta, manipulator2_inputoutput->joint.theta_previous );
		copyVector3( manipulator2.joint.theta, manipulator2.joint.theta_previous );
	}
	else{
		for(i=0;i<3;i++) torque[i] = 0.;
	}
      return;
}
