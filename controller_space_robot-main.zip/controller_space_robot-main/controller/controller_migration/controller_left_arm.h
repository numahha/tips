#ifndef SPACE_ROBOT_LEFT_ARM_CONTROLLER_H
#define SPACE_ROBOT_LEFT_ARM_CONTROLLER_H

#include<iostream>
#include<string>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<vector>
#include<cmath>

#include "./src/controller_arm.h"

#include "old_pc/general_type.h"
#include "old_pc/structure.h"
#include "old_pc/spline.h"



class controller_left_arm : public controller_arm{

private:

    TypedefMatrix3x3 localPDProportionalGainMatrix = {
	{3000.0,      0,      0},
	{   0,     3000.0,    0},
	{   0,        0,    400.0},
    };
    TypedefMatrix3x3 localPDDerivativeGainMatrix = {
	{   6.0,    0,      0},
	{   0,      6.0,    0},
	{   0,      0,      6.0},
    };
    struct TypedefManipulator manipulator2;
    struct SplineStructVector3 splineVector3;
    double t_control_input;
    double local_t;

public:

    controller_left_arm(std::vector<double> given_theta);
    ~controller_left_arm();

    void main_controller();
};

inline controller_left_arm::~controller_left_arm(){
  return;
}



#endif
