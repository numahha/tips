#ifndef SPACE_ROBOT_LEFT_ARM_CONTROLLER_H
#define SPACE_ROBOT_LEFT_ARM_CONTROLLER_H

#include<iostream>
#include<string>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<vector>
#include<cmath>

#include "./src/controller_arm.h"
#include "definition_const_data.h"

class controller_left_arm : public controller_arm{

private:

public:
    controller_left_arm(std::vector<double> given_theta);
    void main_controller();
    ~controller_left_arm();
};


inline controller_left_arm::controller_left_arm(std::vector<double> given_theta) : controller_arm(given_theta){
    return;
}

inline void controller_left_arm::main_controller(){

    torque[0] = 1./torque_voltage_coeff_se;
    torque[1] = 1./torque_voltage_coeff_se;
    torque[2] = 1./torque_voltage_coeff_w;
    return;
}


inline controller_left_arm::~controller_left_arm(){
    return;
}


#endif
