# 宇宙ロボットシミュレータ

## 概要
* Gazeboを利用して、シミュレーションを行う。
* シミュレーション上での関節角度などを、共有メモリ（ENC）に書き込む。
* 共有メモリ(DA)にあるトルク指令値などを読み取り、シミュレーション上のロボットに適用する。


## 環境構築
1. ROSとGazeboのインストール
* [Install ROS1](http://wiki.ros.org/melodic/Installation/Ubuntu)
* [Install gazebo and ros_control (melodic)](http://wiki.ros.org/ros_control)

```
$ gazebo -v
Gazebo multi-robot simulator, version 9.0.0
Copyright (C) 2012 Open Source Robotics Foundation.
Released under the Apache 2 License.
http://gazebosim.org
```

2. catkinワークスペースの設定
```
$ mkdir -p ~/catkin_ws/src
$ cd ~/catkin_ws/src
$ catkin_init_workspace
$ cd ~/catkin_ws
$ catkin_make
$ echo "source ~/catkin_ws/devel/setup.bash" >> ~/.bashrc
$ source ~/.bashrc
```

3. 自作ros_controlプラグイン（Gazebo-共有メモリ間でIO情報をやり取りするように改造したもの）をインストール
```
$ cp -r ./gazebo_lib/gazebo_ros_control_uno/ ~/catkin_ws/src/gazebo_ros_control_uno/
$ cd ~/catkin_ws/
$ catkin_make 
```

4. 共有メモリの残骸（後述）を消去するコマンドを登録しておく（~/.bashrcの中に以下を書けば良い）。
```
alias gazebo_clean='for i in $(ipcs -m | grep -i " 0 " | cut -f 2 -d " "); do ipcrm -m $i; done'
```
やっている処理は、「ipcsで見れる共有メモリ情報の中から、nattachが0の行をgrepで取り出し、2列目のshmidをcutで取り出し、for文でipcrm -mを実行」


## シミュレータの起動
```
$ roslaunch mylaunch.launch
```

関節角度・角速度・トルクが全てゼロの状態からシミュレーションが始まる。
この後、別ターミナル上でControllerを立ち上げれば、Controllerを適用したシミュレーションを見ることができる。



## シミュレータの終了
1. Ctrl + cでGazeboを落とす。

2. 共有メモリ残骸の処理（これをやらないとGazeboを再起動できない）
```
$ gazebo_clean
```


## メモ
* roslaunchした時に出てくる次のメッセージを直したい（一応動くので放置）
[ERROR] [1608441950.814841975, 0.333000000]: Exception thrown while initializing controller 'pole_joint_controller'.
Could not find resource 'pole_joint' in 'hardware_interface::EffortJointInterface'.
[ERROR] [1608441950.814869802, 0.333000000]: Initializing controller 'pole_joint_controller' failed
[ERROR] [1608441951.816352, 1.325000]: Failed to load pole_joint_controller

