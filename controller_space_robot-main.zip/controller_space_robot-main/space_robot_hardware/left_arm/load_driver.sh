#!/bin/sh

modprobe cp3300
modprobe cp6204
modprobe dpg0101

expect -c "
        spawn /usr/bin/dpg0101
        expect \"Enter the model number of the product: GPG/GPH-\"
        send \"3300\n\"
        expect \"Enter the command number: \"
        send  \"98\n\"
        expect \"Enter the command number: \"
        send  \"99\n\"
        expect \"Enter the command number: \"
        send  \"98\n\"
"

echo

modprobe dpg0101

expect -c "
        spawn /usr/bin/dpg0101
        expect \"Enter the model number of the product: GPG/GPH-\"
        send \"6204\n\"
        expect \"Enter the command number: \"
        send  \"98\n\"
        expect \"Enter the command number: \"
        send  \"99\n\"
        expect \"Enter the command number: \"
        send  \"98\n\"
"
echo
echo
echo

