#ifndef DEFINITION_CONST_DATA_H
#define DEFINITION_CONST_DATA_H

#define _IS_REALTIME

//#include<iostream>
#include<vector>


const double time_duration = 0.001;  //[sec]









// servo actuator:RH-14-3002-E100DO and RH-8-3006-E100DO
const std::vector<double> left_arm_torque_max = {7.8, 7.8, 2.3}; //[Nm], 
const std::vector<double> right_arm_torque_max = {7.8, 7.8, 2.3};

const int overall_enc_resolution = 1000*100*4; // ENC_RESOLUTION * REDUCTION_RATIO * ENC_MULTIPLICATION

// トルク電圧定数（制御則によって作られるトルクを電圧に変換する定数）
const double torque_voltage_coeff_se = (8.0/(0.6*9.80665)); // [V/Nm]
const double torque_voltage_coeff_w  = (8.0/(0.2*9.80665));

#endif
