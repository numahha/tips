#include <stdio.h>
#include <math.h>
#include <string.h>

#include "definition_const_data.h"
#include "shm_host_guest.h"


// Interface drivers
#include <unistd.h>
#include "fbida.h"
#include "fbipenc.h"

// functions for real-time control
// ref https://sites.google.com/site/roboticstools/HOME/RTM/RealTimeRTM/LinuxStandard/source?tmpl=%2Fsystem%2Fapp%2Ftemplates%2Fprint%2F&showPrintDialog=1
#ifndef NSEC_PER_SEC
#define NSEC_PER_SEC 1000000000L
#endif
#include <errno.h>
#include <sys/mman.h>
#include <sched.h>
#include <time.h>
static void timespec_add_ns(struct timespec *a, unsigned int ns)
{
    ns += a->tv_nsec;
    while(ns >= NSEC_PER_SEC) {
        ns -= NSEC_PER_SEC;
        a->tv_sec++;
    }
    a->tv_nsec = ns;
}
static int timespec_compare(const struct timespec *lhs, const struct timespec *rhs) {
    if (lhs->tv_sec < rhs->tv_sec)
        return -1;
    if (lhs->tv_sec > rhs->tv_sec)
        return 1;
    return lhs->tv_nsec - rhs->tv_nsec;
}

// functions for key interruption
// ref https://www.lisz-works.com/entry/c-lang-key-interrupt
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>
int kbhit(void)
{
    struct termios oldt, newt;
    int ch;
    int oldf;

    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);

    ch = getchar();

    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);

    if (ch != EOF)
    {
        ungetc(ch, stdin);
        return 1;
    }

    return 0;
}

int isInterrupt()
{
    if ( kbhit() )
{
        if ( getchar() == 'q' )
        {
            return 1;
        }
    }
    return 0;
}


int main(){

    // scheduling for real time
    struct sched_param param;
    int policy = SCHED_FIFO;
    struct timespec tsperiod, tsnow;
    unsigned int control_period_ns = 1000*1000; // 1 mili sec = 1*1000*1000 nano sec
    // hardwareの周期は、controllerの周期と必ずしも一致しなくても良い。

    // DA
    int nRet;
    unsigned short DaData[3];
    double max_voltage=10.;
    int da_i;
    int dnum, cnum;
    DASMPLCHREQ DaSmplChReq[3];
    double da_voltage;
    double da_vec[3];

    //ENC
    unsigned long dwCounter;
    int nDevice;
    double temp_enc;
    double enc_vec[3];

    // DA
    system("clear");
    dnum = 1;
    nRet = DaOpen(dnum);
    if(nRet != DA_ERROR_SUCCESS){
        printf("Da error1: ret=%Xh\n", nRet);
        exit(EXIT_FAILURE);
    }

    for(int i=0;i<3;i++){
        DaSmplChReq[i].ulChNo = i+1;
        DaSmplChReq[i].ulRange = DA_10V; // DA range
        DaData[i] = 2048; // (2048 for 0 Voltage) = 0x0800;
        nRet = DaOutputDA( dnum, 1, &DaSmplChReq[i], &DaData[i] );
        if(nRet != DA_ERROR_SUCCESS){
            printf("Da error2: ret=%Xh\n", nRet);
            exit(EXIT_FAILURE);
        }
        if      ( DaSmplChReq[i].ulRange == DA_10V ) max_voltage=10.;
        else if ( DaSmplChReq[i].ulRange == DA_5V  ) max_voltage=5.;
        else{
            printf("Da range error\n");
            exit(EXIT_FAILURE);
        }
    }

    // ENC
    nDevice = 1;
    nRet = PencOpen(nDevice, PENC_FLAG_SHARE);
    if (nRet != PENC_ERROR_SUCCESS) {
        printf("Enc error1: ret=%Xh\n", nRet);
        exit(EXIT_FAILURE);
    }

    for(int i=0;i<3;i++){
        nRet = PencSetMode(nDevice, (i+1), 0x06, 0, 1, 0);
        if (nRet != PENC_ERROR_SUCCESS) {
            printf("Enc error2: ret=%Xh\n", nRet);
            PencClose(nDevice);
            exit(EXIT_FAILURE);
        }

        nRet = PencGetCounter(nDevice, (i+1), &dwCounter);
        if (nRet != PENC_ERROR_SUCCESS) {
            printf("Enc error3: ret=%Xh\n", nRet);
            PencClose(nDevice);
            if (nRet != PENC_ERROR_SUCCESS) exit(EXIT_FAILURE);
        }
    }


    // RT-preempt
    memset(&param, 0, sizeof(param));
    param.sched_priority = sched_get_priority_max(policy);
    if (sched_setscheduler(0, policy, &param) < 0) {
        printf("sched_setscheduler: %s\n", strerror(errno));
        printf("Please check you are setting /etc/security/limits.conf\n");
        exit (EXIT_FAILURE);
    }
    if (mlockall(MCL_CURRENT|MCL_FUTURE) < 0) {
        printf("mlockall: %s\n", strerror(errno));
        exit (EXIT_FAILURE);
    }

    // shared_memory
    shm_host* shmhost = new shm_host;
    //shm_host sshm;

    // ---------------------------------- [2] ---------------------------------------   real time loop
    printf("\nnow executing... (to finish, press 'q' or wait 120 second)\n\n");
    clock_gettime(CLOCK_MONOTONIC, &tsperiod);
    long start_sec = tsperiod.tv_sec;
    long long loop_count = 0;
    while ((start_sec+1200)>tsperiod.tv_sec ){

        clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &tsperiod,0); 

        // read enc
        for(int i=0;i<3;i++){
            nRet = PencGetCounter(nDevice, (i+1), &dwCounter);
            if (dwCounter<0x800000) temp_enc = dwCounter*(2.*M_PI/overall_enc_resolution);
            else temp_enc = (0xFFFFFF - dwCounter)*(-2.*M_PI/overall_enc_resolution);
            enc_vec[i] = temp_enc;
        }
        shmhost->shm_ENC_1[0] = enc_vec[0];  // [rad]
        shmhost->shm_ENC_2[0] = enc_vec[1];
        shmhost->shm_ENC_3[0] = enc_vec[2];

        // write da
        da_vec[0] = shmhost->shm_DA_1[0]*torque_voltage_coeff_se; // [V] = [Nm] * [V/Nm]
        da_vec[1] = shmhost->shm_DA_2[0]*torque_voltage_coeff_se;
        da_vec[2] = shmhost->shm_DA_3[0]*torque_voltage_coeff_w;
        for(int i=0;i<3;i++){
            da_voltage = da_vec[i];
            da_i = (int)(da_voltage*2048/max_voltage);
            if(da_i>2047)  da_i=2047;
            if(da_i<-2048) da_i=-2048;
            DaData[i] = 2048 + da_i;
            nRet = DaOutputDA( dnum, 1, &DaSmplChReq[i], &DaData[i] );
        }

        if (isInterrupt()) break;

        if(0==loop_count%1){
            clock_gettime(CLOCK_MONOTONIC, &tsnow);
            printf("t = %ld.%d\r\t\t",tsnow.tv_sec-start_sec,int(tsnow.tv_nsec/10000));
            printf("theta = %.1f\t%.1f\t%.1f", shmhost->shm_ENC_1[0]*180/M_PI, 
                                               shmhost->shm_ENC_2[0]*180/M_PI, 
                                               shmhost->shm_ENC_3[0]*180/M_PI);
            printf("\n");
        }
        loop_count++;

        // set next clock time
        timespec_add_ns(&tsperiod, control_period_ns);
        clock_gettime(CLOCK_MONOTONIC, &tsnow);
        if (timespec_compare(&tsperiod, &tsnow)<0){
            printf("overruning!\n");
            tsperiod = tsnow;
            timespec_add_ns(&tsperiod, control_period_ns);
        }
    }
    printf("\nfinish!\n");

  // --------------------------------------- 3 -------------------------------------------- close
   
    for(int i=0;i<3;i++){
        DaData[i] = 2048;	// (2048 for 0 Voltage)
        nRet = DaOutputDA( dnum, 1, &DaSmplChReq[i], &DaData[i] );
    }
    nRet = DaClose(dnum);

    PencClose(nDevice);
    if (nRet != PENC_ERROR_SUCCESS) exit(EXIT_FAILURE);

    delete shmhost;

    return 0;
}


 





 
