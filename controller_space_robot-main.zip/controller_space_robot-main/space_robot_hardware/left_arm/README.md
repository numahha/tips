# 宇宙ロボットハードウェア制御プログラム（左腕のみ）

## 概要
* 宇宙ロボット実験装置を利用する。
* 実験装置の関節角度などを、共有メモリ（ENC）に書き込む。
* 共有メモリ(DA)にあるトルク指令値などを読み取り、実験装置に送る。

## 環境構築

1. Interface社ボードのドライバとRT-preemptパッチを当てたカーネルをインストールする（install_interface_drivers_and rt_preempt参照）。


2. ハードウェアをつなぐ(マニュアル参照)




## 起動
1. ドライバのロード
```
$ sudo bash load_driver.sh
```




2. 本体に電源入れる。

3. 腕を伸ばしている状態から始める。

~~~

3. コントローラーを起動
新しいターミナルを開く
このディレクトリで

```
$ make clean
$ make
$ ./main
```

## メモ
load_driver.shでやっている内容は、

1.1 DAモジュールをロードする（GPG/GPH-3300でエンター→command number:99でエンターとする）
```
sudo bash /usr/src/interface/gpg3300/x86_64/linux/drivers/insda.sh
sudo bash /usr/src/interface/gpg3300/x86_64/linux/drivers/setup.sh
```
1.2 CNTモジュールをロードする（GPG/GPH-6204でエンター→command number:99でエンターとする）
```
$ sudo bash /usr/src/interface/gpg6204/x86_64/linux/drivers/inspenc.sh
$ sudo bash /usr/src/interface/gpg6204/x86_64/linux/drivers/setup.sh
```



## 調べる内容
* 制御入力をオフにして、関節角を読み取れているかどうかを見る。


## TODO
* 原点調整のとり方をいくつかの方法でやりたい。

